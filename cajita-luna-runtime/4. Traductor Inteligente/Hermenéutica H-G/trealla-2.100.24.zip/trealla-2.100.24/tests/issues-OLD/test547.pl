a :- .. = .. .
b :- ::.. .

:- initialization(listing).
