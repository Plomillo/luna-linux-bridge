:-initialization(main).

main :-
	"X".
