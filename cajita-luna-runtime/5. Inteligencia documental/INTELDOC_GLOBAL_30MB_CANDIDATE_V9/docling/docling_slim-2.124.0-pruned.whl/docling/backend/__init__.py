# SPDX-FileCopyrightText: The Docling Contributors
# SPDX-License-Identifier: MIT
