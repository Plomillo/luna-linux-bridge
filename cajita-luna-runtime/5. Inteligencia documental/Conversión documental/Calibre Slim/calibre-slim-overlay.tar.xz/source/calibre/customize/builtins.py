# License: GPLv3 Copyright: 2008, Kovid Goyal <kovid at kovidgoyal.net>

import glob
import os

from calibre.constants import numeric_version
from calibre.customize import MetadataReaderPlugin, MetadataWriterPlugin
from calibre.utils.localization import _

plugins = []


# Metadata reader plugins {{{


class ComicMetadataReader(MetadataReaderPlugin):
    name = 'Read comic metadata'
    file_types = {'cbr', 'cbz', 'cb7', 'cbc'}
    description = _('Extract cover from comic files')

    def customization_help(self, gui=False):
        return 'Read series number from volume or issue number. Default is volume, set this to issue to use issue number instead.'

    def get_metadata(self, stream, type):
        if type == 'cbc':
            from zipfile import ZipFile

            zf = ZipFile(stream)
            fcn = zf.open('comics.txt').read().decode('utf-8').splitlines()[0]
            oname = getattr(stream, 'name', None)
            stream = zf.open(fcn)
            type = fcn.split('.')[-1].lower()
            if oname:
                setattr(stream, 'name', oname)
        if hasattr(stream, 'seek') and hasattr(stream, 'tell'):
            pos = stream.tell()
            id_ = stream.read(3)
            stream.seek(pos)
            if id_ == b'Rar':
                type = 'cbr'
            elif id_.startswith(b'PK'):
                type = 'cbz'
            elif id_.startswith(b'7z'):
                type = 'cb7'
        if type == 'cbr':
            from calibre.utils.unrar import extract_cover_image
        elif type == 'cb7':
            from calibre.utils.seven_zip import extract_cover_image
        else:
            from calibre.libunzip import extract_cover_image
        from calibre.ebooks.metadata import MetaInformation

        ret = extract_cover_image(stream)
        mi = MetaInformation(None, None)
        stream.seek(0)
        if type in {'cbr', 'cbz'}:
            series_index = self.site_customization
            if series_index not in {'volume', 'issue'}:
                series_index = 'volume'
            try:
                mi.smart_update(get_comic_metadata(stream, type, series_index=series_index))
            except Exception:
                pass
        if ret is not None:
            path, data = ret
            ext = os.path.splitext(path)[1][1:]
            mi.cover_data = (ext.lower(), data)
        return mi


class CHMMetadataReader(MetadataReaderPlugin):
    name = 'Read CHM metadata'
    file_types = {'chm'}
    description = _('Read metadata from %s files') % 'CHM'

    def get_metadata(self, stream, type):
        from calibre.ebooks.chm.metadata import get_metadata

        return get_metadata(stream)


class EPUBMetadataReader(MetadataReaderPlugin):
    name = 'Read EPUB metadata'
    file_types = {'epub', 'kepub'}
    description = _('Read metadata from EPUB and KEPUB files')

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.epub import get_metadata, get_quick_metadata

        if self.quick:
            return get_quick_metadata(stream, ftype=type)
        return get_metadata(stream, ftype=type)


class FB2MetadataReader(MetadataReaderPlugin):
    name = 'Read FB2 metadata'
    file_types = {'fb2', 'fbz'}
    description = _('Read metadata from %s files') % 'FB2'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.fb2 import get_metadata

        return get_metadata(stream)


class HTMLMetadataReader(MetadataReaderPlugin):
    name = 'Read HTML metadata'
    file_types = {'html'}
    description = _('Read metadata from %s files') % 'HTML'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.html import get_metadata

        return get_metadata(stream)


class HTMLZMetadataReader(MetadataReaderPlugin):
    name = 'Read HTMLZ metadata'
    file_types = {'htmlz'}
    description = _('Read metadata from %s files') % 'HTMLZ'
    author = 'John Schember'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.extz import get_metadata

        return get_metadata(stream)


class IMPMetadataReader(MetadataReaderPlugin):
    name = 'Read IMP metadata'
    file_types = {'imp'}
    description = _('Read metadata from %s files') % 'IMP'
    author = 'Ashish Kulkarni'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.imp import get_metadata

        return get_metadata(stream)


class LITMetadataReader(MetadataReaderPlugin):
    name = 'Read LIT metadata'
    file_types = {'lit'}
    description = _('Read metadata from %s files') % 'LIT'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.lit import get_metadata

        return get_metadata(stream)


class LRFMetadataReader(MetadataReaderPlugin):
    name = 'Read LRF metadata'
    file_types = {'lrf'}
    description = _('Read metadata from %s files') % 'LRF'

    def get_metadata(self, stream, type):
        from calibre.ebooks.lrf.meta import get_metadata

        return get_metadata(stream)


class LRXMetadataReader(MetadataReaderPlugin):
    name = 'Read LRX metadata'
    file_types = {'lrx'}
    description = _('Read metadata from %s files') % 'LRX'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.lrx import get_metadata

        return get_metadata(stream)


class MOBIMetadataReader(MetadataReaderPlugin):
    name = 'Read MOBI metadata'
    file_types = {'mobi', 'prc', 'azw', 'azw3', 'azw4', 'pobi'}
    description = _('Read metadata from %s files') % 'MOBI'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.mobi import get_metadata

        return get_metadata(stream)


class ODTMetadataReader(MetadataReaderPlugin):
    name = 'Read ODT metadata'
    file_types = {'odt'}
    description = _('Read metadata from %s files') % 'ODT'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.odt import get_metadata

        return get_metadata(stream)


class DocXMetadataReader(MetadataReaderPlugin):
    name = 'Read DOCX metadata'
    file_types = {'docx'}
    description = _('Read metadata from %s files') % 'DOCX'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.docx import get_metadata

        return get_metadata(stream)


class OPFMetadataReader(MetadataReaderPlugin):
    name = 'Read OPF metadata'
    file_types = {'opf'}
    description = _('Read metadata from %s files') % 'OPF'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.opf import get_metadata

        return get_metadata(stream)[0]


class PDBMetadataReader(MetadataReaderPlugin):
    name = 'Read PDB metadata'
    file_types = {'pdb', 'updb'}
    description = _('Read metadata from %s files') % 'PDB'
    author = 'John Schember'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.pdb import get_metadata

        return get_metadata(stream)


class PDFMetadataReader(MetadataReaderPlugin):
    name = 'Read PDF metadata'
    file_types = {'pdf'}
    description = _('Read metadata from %s files') % 'PDF'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.pdf import get_metadata, get_quick_metadata

        if self.quick:
            return get_quick_metadata(stream)
        return get_metadata(stream)


class PMLMetadataReader(MetadataReaderPlugin):
    name = 'Read PML metadata'
    file_types = {'pml', 'pmlz'}
    description = _('Read metadata from %s files') % 'PML'
    author = 'John Schember'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.pml import get_metadata

        return get_metadata(stream)


class RARMetadataReader(MetadataReaderPlugin):
    name = 'Read RAR metadata'
    file_types = {'rar'}
    description = _('Read metadata from e-books in RAR archives')

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.rar import get_metadata

        return get_metadata(stream)


class RBMetadataReader(MetadataReaderPlugin):
    name = 'Read RB metadata'
    file_types = {'rb'}
    description = _('Read metadata from %s files') % 'RB'
    author = 'Ashish Kulkarni'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.rb import get_metadata

        return get_metadata(stream)


class RTFMetadataReader(MetadataReaderPlugin):
    name = 'Read RTF metadata'
    file_types = {'rtf'}
    description = _('Read metadata from %s files') % 'RTF'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.rtf import get_metadata

        return get_metadata(stream)


class SNBMetadataReader(MetadataReaderPlugin):
    name = 'Read SNB metadata'
    file_types = {'snb'}
    description = _('Read metadata from %s files') % 'SNB'
    author = 'Li Fanxi'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.snb import get_metadata

        return get_metadata(stream)


class TOPAZMetadataReader(MetadataReaderPlugin):
    name = 'Read Topaz metadata'
    file_types = {'tpz', 'azw1'}
    description = _('Read metadata from %s files') % 'MOBI'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.topaz import get_metadata

        return get_metadata(stream)


class TXTMetadataReader(MetadataReaderPlugin):
    name = 'Read TXT metadata'
    file_types = {'txt'}
    description = _('Read metadata from %s files') % 'TXT'
    author = 'John Schember'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.txt import get_metadata

        return get_metadata(stream)


class TXTZMetadataReader(MetadataReaderPlugin):
    name = 'Read TXTZ metadata'
    file_types = {'txtz'}
    description = _('Read metadata from %s files') % 'TXTZ'
    author = 'John Schember'

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.extz import get_metadata

        return get_metadata(stream)


class ZipMetadataReader(MetadataReaderPlugin):
    name = 'Read ZIP metadata'
    file_types = {'zip', 'oebzip'}
    description = _('Read metadata from e-books in ZIP archives')

    def get_metadata(self, stream, type):
        from calibre.ebooks.metadata.zip import get_metadata

        return get_metadata(stream)


plugins += [x for x in list(locals().values()) if isinstance(x, type) and x.__name__.endswith('MetadataReader') and bool(getattr(x, 'file_types', set()) & {'pdf', 'epub', 'txt', 'html', 'xhtml'})]

# }}}

# Metadata writer plugins {{{


class EPUBMetadataWriter(MetadataWriterPlugin):
    name = 'Set EPUB metadata'
    file_types = {'epub', 'kepub'}
    description = _('Set metadata in EPUB and KEPUB files')

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.epub import set_metadata

        q = self.site_customization or ''
        set_metadata(
            stream,
            mi,
            apply_null=self.apply_null,
            force_identifiers=self.force_identifiers,
            ftype=type,
            add_missing_cover='disable-add-missing-cover' != q or type == 'kepub',
        )

    def customization_help(self, gui=False):
        h = 'disable-add-missing-cover'
        if gui:
            h = '<i>' + h + '</i>'
        return _('Enter {0} below to have the EPUB metadata writer plugin not add cover images to EPUB files that have no existing cover image.').format(h)


class FB2MetadataWriter(MetadataWriterPlugin):
    name = 'Set FB2 metadata'
    file_types = {'fb2', 'fbz'}
    description = _('Set metadata in %s files') % 'FB2'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.fb2 import set_metadata

        set_metadata(stream, mi, apply_null=self.apply_null)


class HTMLZMetadataWriter(MetadataWriterPlugin):
    name = 'Set HTMLZ metadata'
    file_types = {'htmlz'}
    description = _('Set metadata from %s files') % 'HTMLZ'
    author = 'John Schember'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.extz import set_metadata

        set_metadata(stream, mi)


class LRFMetadataWriter(MetadataWriterPlugin):
    name = 'Set LRF metadata'
    file_types = {'lrf'}
    description = _('Set metadata in %s files') % 'LRF'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.lrf.meta import set_metadata

        set_metadata(stream, mi)


class MOBIMetadataWriter(MetadataWriterPlugin):
    name = 'Set MOBI metadata'
    file_types = {'mobi', 'prc', 'azw', 'azw3', 'azw4'}
    description = _('Set metadata in %s files') % 'MOBI'
    author = 'Marshall T. Vandegrift'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.mobi import set_metadata

        set_metadata(stream, mi)


class PDBMetadataWriter(MetadataWriterPlugin):
    name = 'Set PDB metadata'
    file_types = {'pdb'}
    description = _('Set metadata from %s files') % 'PDB'
    author = 'John Schember'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.pdb import set_metadata

        set_metadata(stream, mi)


class PDFMetadataWriter(MetadataWriterPlugin):
    name = 'Set PDF metadata'
    file_types = {'pdf'}
    description = _('Set metadata in %s files') % 'PDF'
    author = 'Kovid Goyal'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.pdf import set_metadata

        set_metadata(stream, mi)


class RTFMetadataWriter(MetadataWriterPlugin):
    name = 'Set RTF metadata'
    file_types = {'rtf'}
    description = _('Set metadata in %s files') % 'RTF'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.rtf import set_metadata

        set_metadata(stream, mi)


class TOPAZMetadataWriter(MetadataWriterPlugin):
    name = 'Set TOPAZ metadata'
    file_types = {'tpz', 'azw1'}
    description = _('Set metadata in %s files') % 'TOPAZ'
    author = 'Greg Riker'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.topaz import set_metadata

        set_metadata(stream, mi)


class TXTZMetadataWriter(MetadataWriterPlugin):
    name = 'Set TXTZ metadata'
    file_types = {'txtz'}
    description = _('Set metadata from %s files') % 'TXTZ'
    author = 'John Schember'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.extz import set_metadata

        set_metadata(stream, mi)


class ODTMetadataWriter(MetadataWriterPlugin):
    name = 'Set ODT metadata'
    file_types = {'odt'}
    description = _('Set metadata from %s files') % 'ODT'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.odt import set_metadata

        return set_metadata(stream, mi)


class DocXMetadataWriter(MetadataWriterPlugin):
    name = 'Set DOCX metadata'
    file_types = {'docx'}
    description = _('Set metadata from %s files') % 'DOCX'

    def set_metadata(self, stream, mi, type):
        from calibre.ebooks.metadata.docx import set_metadata

        return set_metadata(stream, mi)


plugins += [x for x in list(locals().values()) if isinstance(x, type) and x.__name__.endswith('MetadataWriter') and bool(getattr(x, 'file_types', set()) & {'pdf', 'epub', 'txt'})]

# }}}

# Conversion plugins {{{
from calibre.ebooks.conversion.plugins.epub_input import EPUBInput
from calibre.ebooks.conversion.plugins.epub_output import EPUBOutput
from calibre.ebooks.conversion.plugins.html_input import HTMLInput
from calibre.ebooks.conversion.plugins.oeb_output import OEBOutput
from calibre.ebooks.conversion.plugins.pdf_input import PDFInput
from calibre.ebooks.conversion.plugins.pdf_output import PDFOutput
from calibre.ebooks.conversion.plugins.txt_input import TXTInput

# HTML is an internal dependency of the upstream TXT conversion pipeline; the public wrapper rejects HTML input.
# OEB is internal to the upstream conversion pipeline, never exposed as an output.
plugins += [EPUBInput, PDFInput, TXTInput, HTMLInput, EPUBOutput, PDFOutput, OEBOutput]
# }}}


# Profiles {{{
from calibre.customize.profiles import InputProfile, OutputProfile

plugins += [InputProfile, OutputProfile]
# }}}







if __name__ == '__main__':
    # Test load speed
    import subprocess
    import textwrap

    try:
        subprocess.check_call([
            'python',
            '-c',
            textwrap.dedent(
                '''
        import init_calibre

        def doit():
            import calibre.customize.builtins as b

        def show_stats():
            from pstats import Stats
            s = Stats('/tmp/calibre_stats')
            s.sort_stats('cumulative')
            s.print_stats(30)

        import cProfile
        cProfile.run('doit()', '/tmp/calibre_stats')
        show_stats()

        '''
            ),
        ])
    except subprocess.CalledProcessError:
        raise SystemExit(1)
    try:
        subprocess.check_call([
            'python',
            '-c',
            textwrap.dedent(
                '''
        import time, sys, init_calibre  # ruff: ignore[unused-import]
        st = time.time()
        import calibre.customize.builtins
        t = time.time() - st
        ret = 0

        for x in ('lxml', 'calibre.ebooks.BeautifulSoup', 'uuid',
            'calibre.utils.terminal', 'calibre.utils.img', 'PIL', 'Image',
            'sqlite3', 'mechanize', 'httplib', 'xml', 'inspect', 'urllib',
            'calibre.utils.date', 'calibre.utils.config', 'platform',
            'calibre.utils.zipfile', 'calibre.utils.formatter',
        ):
            if x in sys.modules:
                ret = 1
                print(x, 'has been loaded by a plugin')
        if ret:
            print('\\nA good way to track down what is loading something is to run'
            ' python -c "import init_calibre; import calibre.customize.builtins"')
            print()
        print('Time taken to import all plugins: %.2f'%t)
        sys.exit(ret)

        '''
            ),
        ])
    except subprocess.CalledProcessError:
        raise SystemExit(1)
