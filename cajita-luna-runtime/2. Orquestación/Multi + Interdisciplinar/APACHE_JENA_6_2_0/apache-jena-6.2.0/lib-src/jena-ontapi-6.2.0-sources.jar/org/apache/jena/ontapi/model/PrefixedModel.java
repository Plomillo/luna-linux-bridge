/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 *   SPDX-License-Identifier: Apache-2.0
 */

package org.apache.jena.ontapi.model;

import org.apache.jena.shared.PrefixMapping;

import java.util.Map;

/**
 * A technical interface that describes model prefix operations.
 * Contains overridden methods inherited from {@link PrefixMapping}.
 *
 * @param <R> - subtype of {@link PrefixMapping}, the type to return
 */
interface PrefixedModel<R extends PrefixMapping> extends PrefixMapping {

    @Override
    R setNsPrefix(String prefix, String uri);

    @Override
    R removeNsPrefix(String prefix);

    @Override
    R clearNsPrefixMap();

    @Override
    R setNsPrefixes(PrefixMapping other);

    @Override
    R setNsPrefixes(Map<String, String> map);

    @Override
    R withDefaultMappings(PrefixMapping map);

    @Override
    R lock();
}
