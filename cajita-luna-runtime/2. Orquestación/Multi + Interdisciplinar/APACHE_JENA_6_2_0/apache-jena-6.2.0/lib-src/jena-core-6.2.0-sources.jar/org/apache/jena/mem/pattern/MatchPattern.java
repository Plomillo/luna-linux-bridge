/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 *   SPDX-License-Identifier: Apache-2.0
 */

package org.apache.jena.mem.pattern;

/**
 * Categorizes a triple-match pattern by which of the subject, predicate and
 * object slots are concrete and which are wildcards (i.e. {@code Node.ANY}
 * or {@code null}).
 * <p>
 * The eight enum values cover every possible combination. Triple-store
 * implementations dispatch on this enum to pick the most efficient lookup
 * path for each kind of pattern (e.g. a fully concrete {@link #SUB_PRE_OBJ}
 * is answered directly from the triple set, while a partially open pattern
 * such as {@link #ANY_PRE_OBJ} is answered through an index intersection).
 *
 * @see PatternClassifier
 */
public enum MatchPattern {
    /**
     * Match a triple with a concrete subject, predicate and object.
     */
    SUB_PRE_OBJ,
    /**
     * Match a triple with a concrete subject and predicate, and a wildcard object.
     */
    SUB_PRE_ANY,
    /**
     * Match a triple with a concrete subject and object, and a wildcard predicate.
     */
    SUB_ANY_OBJ,
    /**
     * Match a triple with a concrete subject, and wildcard predicate and object.
     */
    SUB_ANY_ANY,
    /**
     * Match a triple with a concrete predicate and object, and a wildcard subject.
     */
    ANY_PRE_OBJ,
    /**
     * Match a triple with a concrete predicate, and wildcard subject and object.
     */
    ANY_PRE_ANY,
    /**
     * Match a triple with a concrete object, and wildcard subject and predicate.
     */
    ANY_ANY_OBJ,
    /**
     * Match a triple with a wildcard subject, predicate and object.
     */
    ANY_ANY_ANY
}
