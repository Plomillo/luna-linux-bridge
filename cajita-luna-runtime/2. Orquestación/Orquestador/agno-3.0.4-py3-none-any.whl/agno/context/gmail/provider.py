"""
Gmail Context Provider
======================

Read/write Gmail access via two tools:

- ``query_<id>`` — natural-language email reads (search, threads,
  message details, labels).
- ``update_<id>`` — natural-language writes (drafts, send, reply,
  label management).

Separate sub-agents keep each scope narrow. Reads get search and
message tools; writes get compose plus lookup tools.

**Auth methods:**

1. Service Account + domain-wide delegation (headless):
   - Set ``GOOGLE_SERVICE_ACCOUNT_FILE`` and ``GOOGLE_DELEGATED_USER``
   - Gmail requires ``delegated_user`` because service accounts have no inbox

2. OAuth (interactive, for personal Gmail):
   - Set ``GOOGLE_CLIENT_ID``, ``GOOGLE_CLIENT_SECRET``, ``GOOGLE_PROJECT_ID``
   - Opens browser on first use, caches token to ``gmail_token.json``
   - On headless servers pass ``auth=AuthConfig(interactive=False)`` (or set
     ``GOOGLE_OAUTH_NONINTERACTIVE=1``): expired credentials then raise a clear
     error instead of blocking on a browser that never opens
"""

from __future__ import annotations

import asyncio
from os import getenv
from typing import TYPE_CHECKING

from agno.agent import Agent
from agno.context._utils import answer_from_run
from agno.context.google import validate_google_credentials
from agno.context.mode import ContextMode
from agno.context.provider import Answer, ContextProvider, Status
from agno.run import RunContext
from agno.tools.google.gmail import GmailTools

if TYPE_CHECKING:
    from agno.models.base import Model
    from agno.tools.google.auth import AuthConfig


DEFAULT_READ_INSTRUCTIONS = """\
You answer questions by searching and reading Gmail.

## Behavior

- **Pick the right tool for the intent:**
  - Recent inbox → `get_latest_emails`
  - From specific sender → `get_emails_from_user`
  - Unread only → `get_unread_emails`
  - Full-text search → `search_emails` (see toolkit for query syntax)
  - Thread context → `get_emails_by_thread`
- **Cite results.** Include message IDs and quote subject/sender so the
  user can reference messages later.

**Read-only.** No sending, drafting, or modifying messages.
"""

DEFAULT_WRITE_INSTRUCTIONS = """\
You manage Gmail — searching, reading, and composing emails.

## Behavior

- **Search for context.** If replying, find the thread first to
  understand the conversation before composing.
- **Verify recipients.** If the user says "email Alice", search recent
  emails from/to Alice to confirm the correct address.

## Safety

- **Draft by default.** Create drafts unless user explicitly says "send".
- **Never archive or delete** without explicit user confirmation.
"""


class GmailContextProvider(ContextProvider):
    """Gmail context for agents via service account or OAuth.

    ``write_tools`` swaps the write sub-agent's toolset (default: a
    write-scoped ``GmailTools``). ``mode=ContextMode.tools`` is a
    read-only surface and deliberately ignores ``write_tools``.
    """

    def __init__(
        self,
        *,
        # Unified auth config (preferred — enables DB storage + scope aggregation)
        auth: AuthConfig | None = None,
        # Service account auth (legacy — use auth= instead)
        service_account_path: str | None = None,
        delegated_user: str | None = None,
        # OAuth auth (browser flow, legacy — use auth= instead)
        credentials_path: str | None = None,  # OAuth client config (client_id/secret JSON)
        token_path: str | None = None,  # Cached user tokens after consent
        id: str = "gmail",
        name: str = "Gmail",
        read_instructions: str | None = None,
        write_instructions: str | None = None,
        write_tools: list | None = None,
        mode: ContextMode = ContextMode.default,
        model: Model | None = None,
        query_timeout: float | None = None,
        read: bool = True,
        write: bool = False,
        stream_sub_agent_events: bool = True,
    ) -> None:
        super().__init__(
            id=id,
            name=name,
            mode=mode,
            model=model,
            query_timeout=query_timeout,
            read=read,
            write=write,
            stream_sub_agent_events=stream_sub_agent_events,
        )

        # Store auth config for toolkit creation
        self._auth = auth
        self.write_tools = write_tools
        if write_tools is not None and not write:
            from agno.utils.log import log_warning

            log_warning(
                f"{type(self).__name__}: write_tools was provided but write=False, so the update tool is not "
                "exposed and the injected toolset is never used. Pass write=True to enable it."
            )

        # Resolve auth at init — fail fast if misconfigured
        self._sa_path = service_account_path or getenv("GOOGLE_SERVICE_ACCOUNT_FILE")
        self._credentials_path = credentials_path
        self._token_path = token_path or "gmail_token.json"
        self._delegated_user: str | None = None

        if self._sa_path:
            self._delegated_user = delegated_user or getenv("GOOGLE_DELEGATED_USER")
            if not self._delegated_user:
                raise ValueError(
                    "GmailContextProvider requires delegated_user with service account. "
                    "Gmail service accounts must impersonate a user via domain-wide delegation. "
                    "Set GOOGLE_DELEGATED_USER or pass delegated_user parameter."
                )

        self._read_instructions = read_instructions if read_instructions is not None else DEFAULT_READ_INSTRUCTIONS
        self._write_instructions = write_instructions if write_instructions is not None else DEFAULT_WRITE_INSTRUCTIONS
        self._read_toolkit: GmailTools | None = None
        self._write_toolkit: GmailTools | None = None
        self._read_agent: Agent | None = None
        self._write_agent: Agent | None = None

    def status(self) -> Status:
        return validate_google_credentials(
            provider_id=self.id,
            sa_path=self._sa_path,
            token_path=self._token_path,
            delegated_user=self._delegated_user,
            auth=self._auth,
        )

    async def astatus(self) -> Status:
        return await asyncio.to_thread(self.status)

    def query(self, question: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(self._ensure_read_agent().run(question, **kwargs))

    async def aquery(self, question: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(await self._ensure_read_agent().arun(question, **kwargs))

    def update(self, instruction: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(self._ensure_write_agent().run(instruction, **kwargs))

    async def aupdate(self, instruction: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(await self._ensure_write_agent().arun(instruction, **kwargs))

    def instructions(self) -> str:
        if self.mode == ContextMode.tools:
            return f"`{self.name}`: raw Gmail tools (read-only). Tool names may collide with other providers."
        tools = [self.query_tool_name]
        if self.write:
            tools.append(self.update_tool_name)
        return f"`{self.name}`: {', '.join(f'`{t}`' for t in tools)} for email operations."

    def _default_tools(self) -> list:
        return self._read_write_tools()

    def _all_tools(self) -> list:
        return [self._ensure_read_toolkit()]

    def _ensure_read_toolkit(self) -> GmailTools:
        if self._read_toolkit is None:
            self._read_toolkit = self._build_read_toolkit()
        return self._read_toolkit

    def _ensure_write_toolkit(self) -> GmailTools:
        if self._write_toolkit is None:
            self._write_toolkit = self._build_write_toolkit()
        return self._write_toolkit

    async def _aget_query_agent(self, run_context):
        return self._ensure_read_agent()

    async def _aget_update_agent(self, run_context):
        return self._ensure_write_agent()

    def _ensure_read_agent(self) -> Agent:
        if self._read_agent is None:
            self._read_agent = Agent(
                id=f"{self.id}_read",
                name=f"{self.name} (read)",
                model=self.model,
                instructions=self._read_instructions,
                tools=[self._ensure_read_toolkit()],
                markdown=True,
            )
        return self._read_agent

    def _ensure_write_agent(self) -> Agent:
        if self._write_agent is None:
            tools = self.write_tools if self.write_tools is not None else [self._ensure_write_toolkit()]
            self._write_agent = Agent(
                id=f"{self.id}_write",
                name=f"{self.name} (write)",
                model=self.model,
                instructions=self._write_instructions,
                tools=tools,
                markdown=True,
            )
        return self._write_agent

    def _build_read_toolkit(self) -> GmailTools:
        return GmailTools(
            auth=self._auth,
            service_account_path=self._sa_path,
            delegated_user=self._delegated_user,
            credentials_path=self._credentials_path,
            token_path=self._token_path,
            scopes=["https://www.googleapis.com/auth/gmail.readonly"],
            # Disable write operations (these default to True)
            mark_email_as_read=False,
            mark_email_as_unread=False,
            star_email=False,
            unstar_email=False,
            create_draft_email=False,
            send_email=False,
            send_email_reply=False,
            apply_label=False,
            remove_label=False,
            delete_custom_label=False,
            update_draft=False,
        )

    def _build_write_toolkit(self) -> GmailTools:
        return GmailTools(
            auth=self._auth,
            service_account_path=self._sa_path,
            delegated_user=self._delegated_user,
            credentials_path=self._credentials_path,
            token_path=self._token_path,
            scopes=[
                "https://www.googleapis.com/auth/gmail.modify",
                "https://www.googleapis.com/auth/gmail.compose",
            ],
            # Disable bulk read tools (write agent has minimal lookup)
            get_latest_emails=False,
            get_emails_from_user=False,
            get_unread_emails=False,
            get_starred_emails=False,
            get_emails_by_context=False,
            get_emails_by_date=False,
            get_emails_by_thread=False,
            list_drafts=False,
            get_draft=False,
            delete_custom_label=False,
        )
