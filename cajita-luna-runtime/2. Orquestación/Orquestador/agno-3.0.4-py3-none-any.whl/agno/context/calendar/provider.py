"""
Google Calendar Context Provider
================================

Read/write Calendar access via two tools:

- ``query_<id>`` — natural-language calendar reads (list events,
  check availability, find free slots).
- ``update_<id>`` — natural-language writes (create, update, delete
  events).

Separate sub-agents keep each scope narrow. Reads get list/search
tools; writes get CRUD plus lookup tools.

**Auth methods:**

1. Service Account + domain-wide delegation (headless):
   - Set ``GOOGLE_SERVICE_ACCOUNT_FILE`` and optionally ``GOOGLE_DELEGATED_USER``
   - Without ``delegated_user``, operates on the service account's own calendar

2. OAuth (interactive, for personal Calendar):
   - Set ``GOOGLE_CLIENT_ID``, ``GOOGLE_CLIENT_SECRET``, ``GOOGLE_PROJECT_ID``
   - Opens browser on first use, caches token to ``calendar_token.json``
   - On headless servers pass ``auth=AuthConfig(interactive=False)`` (or set
     ``GOOGLE_OAUTH_NONINTERACTIVE=1``): expired credentials then raise a clear
     error instead of blocking on a browser that never opens
"""

from __future__ import annotations

import asyncio
from os import getenv
from typing import TYPE_CHECKING

from agno.agent import Agent
from agno.context._utils import answer_from_run
from agno.context.google import validate_google_credentials
from agno.context.mode import ContextMode
from agno.context.provider import Answer, ContextProvider, Status
from agno.run import RunContext
from agno.tools.google.calendar import GoogleCalendarTools

if TYPE_CHECKING:
    from agno.models.base import Model
    from agno.tools.google.auth import AuthConfig


DEFAULT_READ_INSTRUCTIONS = """\
You answer questions by searching and reading Google Calendar.

## Behavior

- **Ask for timezone** if not obvious from context. Return times in the
  user's local timezone, not UTC.
- **Cite results.** Include event IDs and `htmlLink` so the user can
  reference or open events later.

**Read-only.** No creating, updating, or deleting events.
"""

DEFAULT_WRITE_INSTRUCTIONS = """\
You manage Google Calendar — searching, reading, and modifying events.

## Safety

- **Confirm ambiguous requests.** If the user says "move my meeting"
  but has multiple meetings, ask which one.
- **Confirm timezone** when creating events if not explicit.
- **Confirm before deleting**, especially for recurring events.
  For recurring events, clarify: delete this instance or all future?
"""


class GoogleCalendarContextProvider(ContextProvider):
    """Google Calendar context for agents via service account or OAuth.

    ``write_tools`` swaps the write sub-agent's toolset (default: a
    write-scoped ``GoogleCalendarTools``). ``mode=ContextMode.tools`` is
    a read-only surface and deliberately ignores ``write_tools``.
    """

    def __init__(
        self,
        *,
        # Unified auth config (preferred — enables DB storage + scope aggregation)
        auth: AuthConfig | None = None,
        # Service account auth (legacy — use auth= instead)
        service_account_path: str | None = None,
        delegated_user: str | None = None,
        # OAuth auth (browser flow, legacy — use auth= instead)
        credentials_path: str | None = None,  # OAuth client config (client_id/secret JSON)
        token_path: str | None = None,  # Cached user tokens after consent
        calendar_id: str = "primary",
        id: str = "calendar",
        name: str = "Calendar",
        read_instructions: str | None = None,
        write_instructions: str | None = None,
        write_tools: list | None = None,
        mode: ContextMode = ContextMode.default,
        model: Model | None = None,
        query_timeout: float | None = None,
        read: bool = True,
        write: bool = False,
        stream_sub_agent_events: bool = True,
    ) -> None:
        super().__init__(
            id=id,
            name=name,
            mode=mode,
            model=model,
            query_timeout=query_timeout,
            read=read,
            write=write,
            stream_sub_agent_events=stream_sub_agent_events,
        )

        # Store auth config for toolkit creation
        self._auth = auth
        self.write_tools = write_tools
        if write_tools is not None and not write:
            from agno.utils.log import log_warning

            log_warning(
                f"{type(self).__name__}: write_tools was provided but write=False, so the update tool is not "
                "exposed and the injected toolset is never used. Pass write=True to enable it."
            )

        self._sa_path = service_account_path or getenv("GOOGLE_SERVICE_ACCOUNT_FILE")
        self._credentials_path = credentials_path
        self._token_path = token_path or "calendar_token.json"
        self._calendar_id = calendar_id
        # Calendar does NOT require delegated_user — SA can use its own calendar
        self._delegated_user = delegated_user or getenv("GOOGLE_DELEGATED_USER") if self._sa_path else None

        self._read_instructions = read_instructions if read_instructions is not None else DEFAULT_READ_INSTRUCTIONS
        self._write_instructions = write_instructions if write_instructions is not None else DEFAULT_WRITE_INSTRUCTIONS
        self._read_toolkit: GoogleCalendarTools | None = None
        self._write_toolkit: GoogleCalendarTools | None = None
        self._read_agent: Agent | None = None
        self._write_agent: Agent | None = None

    def status(self) -> Status:
        return validate_google_credentials(
            provider_id=self.id,
            sa_path=self._sa_path,
            token_path=self._token_path,
            delegated_user=self._delegated_user,
            auth=self._auth,
        )

    async def astatus(self) -> Status:
        return await asyncio.to_thread(self.status)

    def query(self, question: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(self._ensure_read_agent().run(question, **kwargs))

    async def aquery(self, question: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(await self._ensure_read_agent().arun(question, **kwargs))

    def update(self, instruction: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(self._ensure_write_agent().run(instruction, **kwargs))

    async def aupdate(self, instruction: str, *, run_context: RunContext | None = None) -> Answer:
        kwargs = self._run_kwargs_for_sub_agent(run_context)
        return answer_from_run(await self._ensure_write_agent().arun(instruction, **kwargs))

    def instructions(self) -> str:
        if self.mode == ContextMode.tools:
            return f"`{self.name}`: raw Calendar tools (read-only). Tool names may collide with other providers."
        tools = [self.query_tool_name]
        if self.write:
            tools.append(self.update_tool_name)
        return f"`{self.name}`: {', '.join(f'`{t}`' for t in tools)} for calendar operations."

    def _default_tools(self) -> list:
        return self._read_write_tools()

    def _all_tools(self) -> list:
        return [self._ensure_read_toolkit()]

    def _ensure_read_toolkit(self) -> GoogleCalendarTools:
        if self._read_toolkit is None:
            self._read_toolkit = self._build_read_toolkit()
        return self._read_toolkit

    def _ensure_write_toolkit(self) -> GoogleCalendarTools:
        if self._write_toolkit is None:
            self._write_toolkit = self._build_write_toolkit()
        return self._write_toolkit

    async def _aget_query_agent(self, run_context):
        return self._ensure_read_agent()

    async def _aget_update_agent(self, run_context):
        return self._ensure_write_agent()

    def _ensure_read_agent(self) -> Agent:
        if self._read_agent is None:
            self._read_agent = Agent(
                id=f"{self.id}_read",
                name=f"{self.name} (read)",
                model=self.model,
                instructions=self._read_instructions,
                tools=[self._ensure_read_toolkit()],
                markdown=True,
            )
        return self._read_agent

    def _ensure_write_agent(self) -> Agent:
        if self._write_agent is None:
            tools = self.write_tools if self.write_tools is not None else [self._ensure_write_toolkit()]
            self._write_agent = Agent(
                id=f"{self.id}_write",
                name=f"{self.name} (write)",
                model=self.model,
                instructions=self._write_instructions,
                tools=tools,
                markdown=True,
            )
        return self._write_agent

    def _build_read_toolkit(self) -> GoogleCalendarTools:
        return GoogleCalendarTools(
            auth=self._auth,
            service_account_path=self._sa_path,
            delegated_user=self._delegated_user,
            credentials_path=self._credentials_path,
            token_path=self._token_path,
            calendar_id=self._calendar_id,
            scopes=["https://www.googleapis.com/auth/calendar.readonly"],
            # Disable write operations (these default to True)
            create_event=False,
            update_event=False,
            delete_event=False,
        )

    def _build_write_toolkit(self) -> GoogleCalendarTools:
        return GoogleCalendarTools(
            auth=self._auth,
            service_account_path=self._sa_path,
            delegated_user=self._delegated_user,
            credentials_path=self._credentials_path,
            token_path=self._token_path,
            calendar_id=self._calendar_id,
            scopes=["https://www.googleapis.com/auth/calendar"],
            # Disable bulk read tools — keep find_available_slots for scheduling
            fetch_all_events=False,
            get_event_attendees=False,
        )
