import asyncio
import contextlib
from contextlib import asynccontextmanager
from functools import partial
from os import getenv
from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Literal, Optional, Set, Union
from uuid import uuid4

from fastapi import APIRouter, FastAPI, HTTPException
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from httpx import HTTPStatusError
from rich import box
from rich.panel import Panel
from starlette.requests import Request

from agno.agent import Agent, AgentFactory, RemoteAgent
from agno.agent.protocol import AgentProtocol
from agno.agents.base import BaseExternalAgent
from agno.db.base import AsyncBaseDb, BaseDb
from agno.job_queue import QueueConfig
from agno.knowledge.knowledge import Knowledge
from agno.media.storage.base import AsyncMediaStorage, MediaStorage
from agno.os.config import (
    AgentOSConfig,
    AuthorizationConfig,
    DatabaseConfig,
    EvalsConfig,
    EvalsDomainConfig,
    KnowledgeConfig,
    KnowledgeDatabaseConfig,
    KnowledgeDomainConfig,
    KnowledgeInstanceConfig,
    LearningConfig,
    LearningDomainConfig,
    MCPConfig,
    MemoryConfig,
    MemoryDomainConfig,
    MetricsConfig,
    MetricsDomainConfig,
    SessionConfig,
    SessionDomainConfig,
    TracesConfig,
    TracesDomainConfig,
)
from agno.os.event_streams import BaseEventStream, set_event_stream
from agno.os.interfaces.base import BaseInterface
from agno.os.job_queue import apply_queue_config, queue_lifespan
from agno.os.router import get_base_router, get_info_router, get_websocket_router
from agno.os.routers.agents import get_agent_router
from agno.os.routers.approvals import get_approval_router
from agno.os.routers.components import get_components_router
from agno.os.routers.database import get_database_router
from agno.os.routers.evals import get_eval_router
from agno.os.routers.health import get_health_router
from agno.os.routers.home import get_home_router
from agno.os.routers.job_queue import get_queue_router
from agno.os.routers.knowledge import get_knowledge_router
from agno.os.routers.learnings import get_learnings_router
from agno.os.routers.media import get_media_router
from agno.os.routers.memory import get_memory_router
from agno.os.routers.metrics import get_metrics_router
from agno.os.routers.registry import get_registry_router
from agno.os.routers.schedules import get_schedule_router
from agno.os.routers.service_accounts import get_service_accounts_router
from agno.os.routers.session import get_session_router
from agno.os.routers.teams import get_team_router
from agno.os.routers.traces import get_traces_router
from agno.os.routers.workflows import get_workflow_router
from agno.os.settings import AgnoAPISettings
from agno.os.utils import (
    _generate_knowledge_id,
    collect_components_from_os,
    collect_mcp_tools_from_registry,
    collect_mcp_tools_from_team,
    collect_mcp_tools_from_workflow,
    find_conflicting_routes,
    flatten_routes,
    load_yaml_config,
    resolve_origins,
    setup_tracing_for_os,
    update_cors_middleware,
)
from agno.registry import Registry
from agno.remote.base import RemoteDb, RemoteKnowledge
from agno.team import RemoteTeam, Team, TeamFactory
from agno.utils.log import log_debug, log_error, log_info, log_warning
from agno.utils.string import generate_id, generate_id_from_name
from agno.workflow import RemoteWorkflow, Workflow, WorkflowFactory

if TYPE_CHECKING:
    # Typed for static checkers only -- fastmcp is an optional extra, so importing it at
    # runtime here would break `import agno.os` when the extra is not installed.
    from fastmcp.server.auth import AuthProvider


@asynccontextmanager
async def mcp_lifespan(_, mcp_tools):
    """Manage MCP connection lifecycle inside a FastAPI app"""
    for tool in mcp_tools:
        await tool.connect()

    yield

    for tool in mcp_tools:
        await tool.close()


@asynccontextmanager
async def http_client_lifespan(_):
    """Manage httpx client lifecycle for proper connection pool cleanup."""
    from agno.utils.http import aclose_default_clients

    yield

    await aclose_default_clients()


@asynccontextmanager
async def agent_os_telemetry_lifespan(_, agent_os: "AgentOS"):
    """Emit launch telemetry after the serving worker has started.

    Best-effort: a telemetry failure (including a failed import of the
    telemetry client) must not stop the server from starting.
    """
    try:
        from agno.api.os import OSLaunch, log_os_telemetry

        log_os_telemetry(launch=OSLaunch(os_id=agent_os.id, data=agent_os._get_telemetry_data()))
    except Exception as e:
        log_debug(f"Could not send AgentOS launch telemetry: {type(e).__name__}")
    yield


async def _drain_cancel_persist_tasks(timeout: float = 30.0) -> None:
    """Await in-flight cancel-persist writes before databases close on shutdown."""
    from agno.agent._run import _background_tasks as agent_tasks
    from agno.team._run import _background_tasks as team_tasks
    from agno.workflow.workflow import _workflow_background_tasks as workflow_tasks

    # Re-snapshot until the sets drain (a disconnect handled mid-shutdown can schedule
    # another persist), bounded by timeout so it never hangs shutdown.
    deadline = asyncio.get_running_loop().time() + timeout
    while True:
        pending = {t for t in (*agent_tasks, *team_tasks, *workflow_tasks) if not t.done()}
        if not pending:
            return
        remaining = deadline - asyncio.get_running_loop().time()
        if remaining <= 0:
            # Cancel stragglers NOW, while the pool is still open, so their
            # CancelledError handlers can persist a terminal status. Without
            # this they are cancelled at loop teardown - AFTER _close_databases
            # - and their persists silently hit a closed pool.
            log_warning(
                f"Drain timeout: cancelling {len(pending)} background task(s) so terminal "
                "statuses persist before database shutdown"
            )
            for task in pending:
                task.cancel()
            with contextlib.suppress(Exception):
                await asyncio.wait(pending, timeout=5.0)
            return
        await asyncio.wait(pending, timeout=remaining)


def _error_body(detail: str, exc: BaseException) -> Dict[str, Any]:
    """Build the JSON error body, carrying the error's identity when the exception has one.

    ``AgnoError`` subclasses (and ``AgnoHTTPException``, which wraps them) expose ``error_id``
    and a type so clients can branch on the kind of failure rather than on ``detail`` text.
    """
    body: Dict[str, Any] = {"detail": detail}
    error_id = getattr(exc, "error_id", None)
    if error_id:
        body["error_id"] = error_id
        body["error_type"] = getattr(exc, "error_type", None) or getattr(exc, "type", None)
    return body


@asynccontextmanager
async def db_lifespan(app: FastAPI, agent_os: "AgentOS"):
    """Initializes databases in the event loop and closes them on shutdown."""
    if agent_os.auto_provision_dbs:
        agent_os._initialize_sync_databases()
        await agent_os._initialize_async_databases()

    yield

    # Let in-flight cancel-persist tasks finish writing before the pool closes
    await _drain_cancel_persist_tasks()
    await agent_os._close_databases()


@asynccontextmanager
async def scheduler_lifespan(app: FastAPI, agent_os: "AgentOS"):
    """Start and stop the scheduler poller."""
    from agno.scheduler import ScheduleExecutor, SchedulePoller

    if agent_os._scheduler_base_url is None:
        log_info(
            "scheduler_base_url not set, using default http://127.0.0.1:7777. "
            "If your server is running on a different port, set scheduler_base_url to match."
        )
    base_url = agent_os._scheduler_base_url or "http://127.0.0.1:7777"
    internal_token = agent_os._internal_service_token
    if internal_token is None:
        raise ValueError("internal_service_token must be set when scheduler is enabled")

    executor = ScheduleExecutor(
        base_url=base_url,
        internal_service_token=internal_token,
    )
    poller = SchedulePoller(
        db=agent_os.db,
        executor=executor,
        poll_interval=agent_os._scheduler_poll_interval,
    )

    app.state.scheduler_executor = executor
    app.state.scheduler_poller = poller
    await poller.start()

    yield

    await poller.stop()


def _combine_app_lifespans(lifespans: list) -> Any:
    """Combine multiple FastAPI app lifespan context managers into one."""
    if len(lifespans) == 1:
        return lifespans[0]

    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def combined_lifespan(app):
        async def _run_nested(index: int):
            if index >= len(lifespans):
                yield
                return

            async with lifespans[index](app):
                async for _ in _run_nested(index + 1):
                    yield

        async for _ in _run_nested(0):
            yield

    return combined_lifespan


def _get_disabled_feature_router(prefix: str, tag: str, requires: str) -> APIRouter:
    """Return a stub router that returns 503 for a feature that requires a missing dependency."""
    detail = f"{tag} not available: pass a `{requires}` to AgentOS to enable this feature."
    router = APIRouter(tags=[tag])
    feature = prefix.strip("/").replace("/", "_")

    # Register each method separately with a unique operation_id to avoid duplicates
    for method in ["GET", "POST", "PUT", "PATCH", "DELETE"]:

        @router.api_route(prefix, methods=[method], operation_id=f"disabled_{feature}_{method.lower()}")
        async def _disabled() -> None:
            raise HTTPException(status_code=503, detail=detail)

    # Catch-all sub-path route — hidden from schema
    @router.api_route(
        f"{prefix}/{{path:path}}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False
    )
    async def _disabled_subpath() -> None:
        raise HTTPException(status_code=503, detail=detail)

    return router


class AgentOS:
    def __init__(
        self,
        id: Optional[str] = None,
        name: Optional[str] = None,
        description: Optional[str] = None,
        version: Optional[str] = None,
        db: Optional[Union[BaseDb, AsyncBaseDb]] = None,
        checkpoint: Optional[Literal["runs", "tool-batch", "tools"]] = None,
        agents: Optional[List[Union[Agent, RemoteAgent, AgentProtocol, AgentFactory]]] = None,
        teams: Optional[List[Union[Team, RemoteTeam, TeamFactory]]] = None,
        workflows: Optional[List[Union[Workflow, RemoteWorkflow, WorkflowFactory]]] = None,
        knowledge: Optional[List[Knowledge]] = None,
        interfaces: Optional[List[BaseInterface]] = None,
        a2a_interface: bool = False,
        authorization: bool = False,
        authorization_config: Optional[AuthorizationConfig] = None,
        cors_allowed_origins: Optional[List[str]] = None,
        media_storage: Optional[Union[MediaStorage, AsyncMediaStorage]] = None,
        config: Optional[Union[str, AgentOSConfig]] = None,
        settings: Optional[AgnoAPISettings] = None,
        lifespan: Optional[Any] = None,
        mcp: Optional[Union[bool, MCPConfig]] = None,
        mcp_server: Optional[Union[bool, MCPConfig]] = None,
        mcp_auth: Optional["AuthProvider"] = None,
        base_app: Optional[FastAPI] = None,
        on_route_conflict: Literal["preserve_agentos", "preserve_base_app", "error"] = "preserve_agentos",
        tracing: bool = False,
        auto_provision_dbs: bool = True,
        run_hooks_in_background: bool = False,
        queue: Optional[QueueConfig] = None,
        event_stream: Optional[BaseEventStream] = None,
        telemetry: bool = True,
        registry: Optional[Registry] = None,
        scheduler: bool = False,
        scheduler_poll_interval: int = 15,
        scheduler_base_url: Optional[str] = None,
        internal_service_token: Optional[str] = None,
    ):
        """Initialize AgentOS.

        Args:
            id: Unique identifier for this AgentOS instance
            name: Name of the AgentOS instance
            description: Description of the AgentOS instance
            version: Version of the AgentOS instance
            db: Default database for the AgentOS instance. Agents, teams and workflows with no db will use this one.
            checkpoint: Default checkpoint level for agents in this AgentOS. Agents without their own
                checkpoint setting inherit this one. One of "runs", "tool-batch", "tools".
                None means no OS-level default; each agent falls
                back to "runs" at first-run time.
            agents: List of agents to include in the OS
            teams: List of teams to include in the OS
            workflows: List of workflows to include in the OS
            knowledge: List of knowledge bases to include in the OS
            interfaces: List of interfaces to include in the OS
            a2a_interface: Whether to expose the OS agents and teams in an A2A server
            config: Configuration file path or AgentOSConfig instance
            settings: API settings for the OS
            lifespan: Optional lifespan context manager for the FastAPI app
            mcp: Serve the OS over MCP (Model Context Protocol) at ``/mcp``. Pass
                ``True`` for the default surface (all default tools), or an
                ``MCPConfig`` to expose agents/teams/workflows as individual tools:
                its ``tools=[...]`` takes components, ``component.as_tool(name=...,
                description=...)`` markers, and custom callables; ``default_tools``
                and ``include_tags``/``exclude_tags`` scope the default surface.
            mcp_server: Deprecated alias for ``mcp``, still accepted; passing both with
                different values is an error.
            mcp_auth: An ``AuthProvider`` object that owns authentication for the MCP
                endpoint (OAuth for connector clients like claude.ai and ChatGPT). Use
                ``AgentOSBuiltinAuth.from_env()`` (from ``agno.os``) for the built-in
                authorization server — it binds to this AgentOS's Postgres db — or an
                external provider such as WorkOS ``AuthKitProvider`` for bring-your-own.
                When set, fastmcp serves the provider's discovery/OAuth routes and the 401
                challenge on the MCP surface, agno bridges the verified identity into the
                tool layer, and the provider is composed with the service-account verifier
                and the existing JWT config so ``agno_pat_`` and agno-JWT bearers keep
                working. Requires the MCP server to be enabled via ``mcp``.
                When unset, the existing PAT/JWT path is unchanged.
            base_app: Optional base FastAPI app to use for the AgentOS. All routes and middleware will be added to this app.
            on_route_conflict: What to do when a route conflict is detected in case a custom base_app is provided.
            auto_provision_dbs: Whether to automatically provision databases
            authorization: Whether to enable authorization
            authorization_config: Configuration for the authorization middleware
            cors_allowed_origins: List of allowed CORS origins (will be merged with default Agno domains)
            media_storage: Backend the media routes read stored media from. Defaults to the first
                one configured on an agent, team or workflow.
            tracing: If True, enables OpenTelemetry tracing for all agents and teams in the OS
            run_hooks_in_background: If True, run agent/team pre/post hooks as FastAPI background tasks (non-blocking)
            queue: Configuration for the AgentOS job queue (QueueConfig). Background runs
                execute through it today; it is not a message-broker integration.
                background=True runs are accepted immediately as PENDING and execute under
                queue.max_concurrency per replica (shared across agents, teams and workflows;
                enforced per event loop, so process-wide in the standard deployment). Runs beyond
                the cap wait in line and can still be cancelled while waiting. 0 or below disables
                capping. Setting queue.redis (URL or RedisCoordination) additionally enables
                BOTH cross-container transports for background runs, built from shared clients:
                distributed cancellation (control in) and the Redis event stream (events out), so
                cancel and /resume work from any replica. Process-global: last setter wins if
                multiple AgentOS instances configure it, and None leaves the current process
                settings untouched (concurrency falls back to the AGNO_BACKGROUND_MAX_CONCURRENCY
                env var or the default of 32).
            event_stream: Explicit event stream override (granular escape hatch). Takes
                precedence over the stream queue.redis would configure. Defaults to the
                in-memory stream when neither is set.
            telemetry: Whether to enable telemetry
            registry: Optional registry to use for the AgentOS
            scheduler: Whether to enable the cron scheduler
            scheduler_poll_interval: Seconds between scheduler poll cycles (default: 15)
            scheduler_base_url: Base URL for scheduler HTTP calls (default: http://127.0.0.1:7777)
            internal_service_token: Token for scheduler-to-OS auth (auto-generated if not provided)
        """
        if not agents and not workflows and not teams and not knowledge and not db:
            raise ValueError("Either agents, teams, workflows, knowledge bases or a database must be provided.")

        self.config = load_yaml_config(config) if isinstance(config, str) else config

        self.agents: Optional[List[Union[Agent, RemoteAgent, AgentProtocol, AgentFactory]]] = agents
        self.teams: Optional[List[Union[Team, RemoteTeam, TeamFactory]]] = teams
        self.workflows: Optional[List[Union[Workflow, RemoteWorkflow, WorkflowFactory]]] = workflows
        self.a2a_interface = a2a_interface
        self.knowledge = knowledge
        self.settings: AgnoAPISettings = settings or AgnoAPISettings()
        self.auto_provision_dbs = auto_provision_dbs
        self._app_set = False

        if base_app:
            self.base_app: Optional[FastAPI] = base_app
            self._app_set = True
            self.on_route_conflict = on_route_conflict
        else:
            self.base_app = None
            self._app_set = False
            self.on_route_conflict = on_route_conflict

        self.interfaces = interfaces or []

        self.name = name

        self.id = id
        if not self.id:
            self.id = generate_id(self.name) if self.name else str(uuid4())

        self.version = version
        self.description = description
        self.db = db
        self.checkpoint = checkpoint

        self.telemetry = telemetry
        self.tracing = tracing

        self.mcp_config: Optional[MCPConfig] = None
        # ``mcp_server`` is the deprecated alias for ``mcp``.
        if mcp is not None and mcp_server is not None and mcp != mcp_server:
            raise ValueError(
                "AgentOS() got both mcp= and its deprecated alias mcp_server= with different values; pass only mcp=."
            )
        self.mcp = mcp if mcp is not None else (mcp_server if mcp_server is not None else False)
        self.mcp_auth: Optional["AuthProvider"] = mcp_auth
        # Resolved lazily (and once): the MultiAuth-wrapped provider handed to FastMCP.
        self._resolved_mcp_auth: Optional["AuthProvider"] = None
        if self.mcp_auth is not None and not self.mcp:
            raise ValueError("AgentOS(mcp_auth=...) requires the MCP server: pass mcp=True or an MCPConfig.")
        self.lifespan = lifespan

        self.registry = registry
        # Knowledge mirrored into the registry by a sync (component-owned
        # instances collected for name resolution) is not a knowledge-route
        # source; anything else on the registry list the user put there -- at
        # construction or later via add_knowledge -- and feeds the routes on
        # every (re)sync. Provenance lives on the Registry itself (marked at
        # mirror time, never snapshotted), because a registry can be shared
        # between AgentOS instances: another OS's mirror must not look
        # user-registered here.

        # RBAC
        self.authorization = authorization
        self.authorization_config = authorization_config

        # CORS configuration - merge user-provided origins with defaults from settings
        self.cors_allowed_origins = resolve_origins(cors_allowed_origins, self.settings.cors_origin_list)
        self.media_storage = media_storage

        # If True, run agent/team hooks as FastAPI background tasks
        self.run_hooks_in_background = run_hooks_in_background

        # Queue configuration. None keeps the process defaults (env var or
        # library default for the concurrency cap, in-memory transports).
        # queue.redis wires the cross-container transports over the process
        # defaults only; the explicit event_stream parameter is applied first
        # and survives the wiring regardless of its type.
        self.queue = queue

        # Event stream FIRST: the coordination wiring below only replaces the
        # never-explicitly-set defaults and warns on asymmetric transports - it
        # must see the user's explicit stream, or the one split-Redis config it
        # exists to catch (custom stream on Redis A, wired cancellation on
        # Redis B) never warns.
        if event_stream is not None:
            set_event_stream(event_stream)

        if queue is not None:
            apply_queue_config(queue)

        # Scheduler configuration
        self._scheduler_enabled = scheduler
        self._scheduler_poll_interval = scheduler_poll_interval
        self._scheduler_base_url = scheduler_base_url
        if self._scheduler_enabled and not internal_service_token:
            import secrets

            internal_service_token = secrets.token_urlsafe(32)
        self._internal_service_token = internal_service_token

        # Shared verifier for service account tokens (agno_pat_...), created lazily
        # when a db is available. One instance per AgentOS so the failed-lookup
        # limiter and last_used_at throttle are shared across the REST and MCP apps.
        self._service_account_verifier: Optional[Any] = None

        # Client-side MCP: the MCPTools connections that agents/teams/workflows in this
        # AgentOS consume (collected so their lifecycles are managed in the app lifespan).
        # Unrelated to ``mcp=``, which SERVES this AgentOS as an MCP server at /mcp.
        self.mcp_tools: List[Any] = []
        self._mcp_app: Optional[Any] = None
        # Guards get_app() idempotency when a base_app is supplied (that path mutates
        # the caller's app in place, so preparing twice would double routes/lifespans).
        self._base_app_prepared: bool = False

        self._initialize_agents()
        self._initialize_teams()
        self._initialize_workflows()

        # Populate registry with code-defined agents/teams
        self._populate_registry()
        self._warn_on_foreign_studio_registries()
        self._populate_registry_managers()

        # Discover knowledge instances and mirror them into the registry so that
        # GET /registry?resource_type=knowledge is consistent right after construction
        # (not only after get_app()/resync()).
        self._auto_discover_knowledge_instances()
        self._populate_registry_knowledge()

        # Collect models, tools, dbs and vector dbs from the agent/team/workflow tree
        self._populate_registry_components()

        # Track MCP tools declared on the registry so they connect in the same
        # lifespan as agent/team/workflow MCP tools (e.g. for components created
        # from registry tools via StudioTools)
        collect_mcp_tools_from_registry(self.registry, self.mcp_tools)

        # Check for duplicate IDs
        self._raise_if_duplicate_ids()

        if self.tracing:
            self._setup_tracing()

    @property
    def mcp(self) -> bool:
        """Whether the MCP server is enabled. Assigning an ``MCPConfig`` enables
        the server and stores the config on ``mcp_config``, matching the constructor."""
        return self._mcp_enabled

    @mcp.setter
    def mcp(self, value: Union[bool, MCPConfig]) -> None:
        if isinstance(value, MCPConfig):
            self._mcp_enabled = True
            self.mcp_config = value
        else:
            import collections.abc

            # A dict here is always a mistake: bool(dict) would enable the server while
            # silently discarding every setting in it -- including authorize.
            if isinstance(value, collections.abc.Mapping):
                raise TypeError(
                    "AgentOS.mcp takes True/False or an MCPConfig instance; got a dict. "
                    "Pass MCPConfig(**your_dict) -- a plain dict would enable the server "
                    "but silently discard its settings, including authorize."
                )
            self._mcp_enabled = bool(value)

    @property
    def mcp_server(self) -> bool:
        """Deprecated alias for ``mcp``."""
        return self.mcp

    @mcp_server.setter
    def mcp_server(self, value: Union[bool, MCPConfig]) -> None:
        self.mcp = value

    def _add_agent_os_to_lifespan_function(self, lifespan):
        """
        Inspect a lifespan function and wrap it to pass agent_os if it accepts it.

        Returns:
            A wrapped lifespan that passes agent_os if the lifespan function expects it.
        """
        # Getting the actual function inside the lifespan
        lifespan_function = lifespan
        if hasattr(lifespan, "__wrapped__"):
            lifespan_function = lifespan.__wrapped__

        try:
            from inspect import signature

            # Inspecting the lifespan function signature to find its parameters
            sig = signature(lifespan_function)
            params = list(sig.parameters.keys())

            # If the lifespan function expects the 'agent_os' parameter, add it
            if "agent_os" in params:
                return partial(lifespan, agent_os=self)
            else:
                return lifespan

        except (ValueError, TypeError):
            return lifespan

    def resync(self, app: FastAPI) -> None:
        """Resync the AgentOS to discover, initialize and configure: agents, teams, workflows, databases and knowledge bases."""
        self._initialize_agents()
        self._initialize_teams()
        self._initialize_workflows()

        # Populate registry with code-defined agents/teams
        self._populate_registry()
        self._warn_on_foreign_studio_registries()
        self._populate_registry_managers()

        # Check for duplicate IDs
        self._raise_if_duplicate_ids()
        self._auto_discover_databases()
        self._auto_discover_media_storage()
        self._auto_discover_knowledge_instances()
        self._populate_registry_knowledge()

        # Collect models, tools, dbs and vector dbs from the agent/team/workflow tree
        self._populate_registry_components()

        # Track MCP tools declared on the registry
        collect_mcp_tools_from_registry(self.registry, self.mcp_tools)

        # Reuse the already-started MCP app. Its BUILTIN tools close over this AgentOS
        # instance and resolve component ids at call time, so components added since
        # construction are runnable through them without a rebuild. EXPOSED tools
        # (MCPConfig.tools) are registered on the FastMCP server when the app is built:
        # an exposure added after boot appears in tools/list only after a restart --
        # and under default_tools=False it is unreachable over MCP until then (the
        # riding continue_run/cancel_run are bounded to the components published at
        # build time).
        # Building a fresh app here cannot fix that: it would mount one whose
        # StreamableHTTP lifespan never runs, so every /mcp request would 500.
        if self.mcp and self._mcp_app is None:
            try:
                from agno.os.mcp import get_mcp_server
            except ImportError as e:
                raise ImportError(
                    "`fastmcp` not installed. It is required for `mcp=True`. "
                    "Please install it using `pip install fastmcp`."
                ) from e

            self._mcp_app = get_mcp_server(self)

        self._reprovision_routers(app=app)

    def _mount_mcp_app(self, app: FastAPI) -> None:
        """Mount the MCP app at root exactly once (idempotent across get_app/resync calls)."""
        if self._mcp_app is None:
            return
        if any(getattr(route, "app", None) is self._mcp_app for route in app.router.routes):
            return
        app.mount("/", self._mcp_app)

    def _reprovision_routers(self, app: FastAPI) -> None:
        """Re-provision all routes for the AgentOS."""
        # The home router is added by _add_built_in_routes below; adding it here too
        # would duplicate the GET / route on every resync.
        updated_routers = [
            get_session_router(dbs=self.dbs, media_storage=self.media_storage),
            get_media_router(dbs=self.dbs, media_storage=self.media_storage, settings=self.settings),
            get_memory_router(dbs=self.dbs),
            get_learnings_router(dbs=self.dbs, settings=self.settings),
            get_eval_router(
                dbs=self.dbs,
                agents=self._agents or None,  # type: ignore[arg-type]
                teams=self._teams or None,  # type: ignore[arg-type]
            ),
            get_metrics_router(dbs=self.dbs),
            get_knowledge_router(knowledge_instances=self.knowledge_instances),
            get_traces_router(dbs=self.dbs),
            get_database_router(self, settings=self.settings),
        ]
        # Routes that require a database
        if self.db is not None:
            if isinstance(self.db, BaseDb):
                updated_routers.append(get_components_router(os_db=self.db, registry=self.registry))
            else:
                updated_routers.append(_get_disabled_feature_router("/components", "Components", "sync db (BaseDb)"))
            updated_routers.append(
                get_schedule_router(
                    os_db=self.db,
                    settings=self.settings,
                    include_agents=self.agents,
                    include_teams=self.teams,
                    include_workflows=self.workflows,
                )
            )
            updated_routers.append(get_approval_router(os_db=self.db, settings=self.settings))
            updated_routers.append(get_service_accounts_router(os_db=self.db, settings=self.settings))
        else:
            for prefix, tag in [
                ("/components", "Components"),
                ("/schedules", "Schedules"),
                ("/approvals", "Approvals"),
                ("/service-accounts", "Service Accounts"),
            ]:
                updated_routers.append(_get_disabled_feature_router(prefix, tag, "db"))
        # Registry router
        if self.registry is not None:
            updated_routers.append(get_registry_router(registry=self.registry))
        else:
            updated_routers.append(_get_disabled_feature_router("/registry", "Registry", "registry"))

        # Clear all previously existing routes
        app.router.routes = [
            route
            for route in app.router.routes
            if hasattr(route, "path")
            and (
                route.path in ["/docs", "/redoc", "/openapi.json", "/docs/oauth2-redirect"]
                or route.path.startswith("/mcp")
            )
        ]

        # Add the built-in routes
        self._add_built_in_routes(app=app)

        # Add the updated routes
        for router in updated_routers:
            self._add_router(app, router)

        # Mount MCP if needed
        if self.mcp:
            self._mount_mcp_app(app)

    def _add_built_in_routes(self, app: FastAPI) -> None:
        """Add all AgentOSbuilt-in routes to the given app."""
        # Always add the home router: explicit routes win over the root MCP Mount, and
        # without it GET / falls through to the MCP app's plain-text 404.
        self._add_router(app, get_home_router(self))

        self._add_router(app, get_health_router(health_endpoint="/health"))
        self._add_router(app, get_info_router(self))
        self._add_router(app, get_base_router(self, settings=self.settings))
        self._add_router(app, get_agent_router(self, settings=self.settings, registry=self.registry))
        self._add_router(app, get_team_router(self, settings=self.settings, registry=self.registry))
        self._add_router(app, get_workflow_router(self, settings=self.settings))
        self._add_router(app, get_websocket_router(self, settings=self.settings))

        # Job queue operations surface (DLQ, requeue, stats) - only meaningful
        # when the durable queue is enabled
        if self.queue is not None and self.queue.durable:
            self._add_router(app, get_queue_router(self, settings=self.settings))
        else:
            # Parity with every other switchable feature: answer 503 naming
            # the switch instead of 404ing the whole surface
            self._add_router(app, _get_disabled_feature_router("/queue", "Queue", "queue=QueueConfig(durable=True)"))

        # Add A2A interface if relevant
        has_a2a_interface = False
        for interface in self.interfaces:
            if not has_a2a_interface and interface.__class__.__name__ == "A2A":
                has_a2a_interface = True
            interface_router = interface.get_router()
            self._add_router(app, interface_router)
        if self.a2a_interface and not has_a2a_interface:
            from agno.os.interfaces.a2a import A2A

            a2a_interface = A2A(
                agents=self._agents or None,  # type: ignore[arg-type]
                teams=self._teams or None,  # type: ignore[arg-type]
                workflows=self._workflows or None,  # type: ignore[arg-type]
            )
            self.interfaces.append(a2a_interface)
            self._add_router(app, a2a_interface.get_router())

    def _raise_if_duplicate_ids(self) -> None:
        """Check for duplicate IDs within each entity type.

        Raises:
            ValueError: If duplicate IDs are found within the same entity type
        """
        duplicate_ids: List[str] = []

        for entities in [self.agents, self.teams, self.workflows]:
            if not entities:
                continue
            seen_ids: set[str] = set()
            for entity in entities:
                entity_id = entity.id
                if entity_id is None:
                    continue
                if entity_id in seen_ids:
                    if entity_id not in duplicate_ids:
                        duplicate_ids.append(entity_id)
                else:
                    seen_ids.add(entity_id)

        if duplicate_ids:
            raise ValueError(f"Duplicate IDs found in AgentOS: {', '.join(repr(id_) for id_ in duplicate_ids)}")

    @property
    def _agents(self) -> List[Agent]:
        """Local agents only — excludes RemoteAgent and AgentFactory."""
        return [a for a in (self.agents or []) if isinstance(a, Agent)]

    @property
    def _teams(self) -> List[Team]:
        """Local teams only — excludes RemoteTeam and TeamFactory."""
        return [t for t in (self.teams or []) if isinstance(t, Team)]

    @property
    def _workflows(self) -> List[Workflow]:
        """Local workflows only — excludes RemoteWorkflow and WorkflowFactory."""
        return [w for w in (self.workflows or []) if isinstance(w, Workflow)]

    def _make_app(self, lifespan: Optional[Any] = None) -> FastAPI:
        return FastAPI(
            title=self.name or "Agno AgentOS",
            version=self.version or "1.0.0",
            description=self.description or "Your multi-agent operating system.",
            docs_url="/docs" if self.settings.docs_enabled else None,
            redoc_url="/redoc" if self.settings.docs_enabled else None,
            openapi_url="/openapi.json" if self.settings.docs_enabled else None,
            lifespan=lifespan,
        )

    def _initialize_agents(self) -> None:
        """Initialize and configure all agents for AgentOS usage."""
        # Inject db into external framework agents (not covered by self._agents)
        for entry in self.agents or []:
            if isinstance(entry, BaseExternalAgent):
                if self.db is not None and entry.db is None:
                    entry.db = self.db

        if not self._agents:
            return

        for agent in self._agents:
            # Set the default db to agents without their own
            if self.db is not None and agent.db is None:
                agent.db = self.db
            # Set the default checkpoint level on agents without their own
            if self.checkpoint is not None and agent.checkpoint is None:
                agent.checkpoint = self.checkpoint
            # Track all MCP tools to later handle their connection
            if agent.tools and isinstance(agent.tools, list):
                for tool in agent.tools:
                    # Checking if the tool is an instance of MCPTools or a subclass of it
                    if hasattr(type(tool), "__mro__"):
                        mro_names = {cls.__name__ for cls in type(tool).__mro__}
                        if "MCPTools" in mro_names:
                            if tool not in self.mcp_tools:
                                self.mcp_tools.append(tool)

            agent.initialize_agent()

            # Required for the built-in routes to work
            agent.store_events = True

            # Propagate run_hooks_in_background setting from AgentOS to agents
            agent._run_hooks_in_background = self.run_hooks_in_background

    def _initialize_teams(self) -> None:
        """Initialize and configure all teams for AgentOS usage."""
        if not self._teams:
            return

        for team in self._teams:
            # Set the default db to teams without their own
            if self.db is not None and team.db is None:
                team.db = self.db

            # Track all MCP tools recursively
            collect_mcp_tools_from_team(team, self.mcp_tools)

            team.initialize_team()

            if isinstance(team.members, list):
                for member in team.members:
                    if isinstance(member, Agent):
                        member.team_id = None
                        member.initialize_agent()
                    elif isinstance(member, Team):
                        member.initialize_team()

            # Required for the built-in routes to work
            team.store_events = True

            # Propagate run_hooks_in_background setting to team and all nested members
            team.propagate_run_hooks_in_background(self.run_hooks_in_background)

    def _initialize_workflows(self) -> None:
        """Initialize and configure all workflows for AgentOS usage."""
        if not self._workflows:
            return

        for workflow in self._workflows:
            # Set the default db to workflows without their own
            if self.db is not None and workflow.db is None:
                workflow.db = self.db

            # Track MCP tools recursively in workflow members
            collect_mcp_tools_from_workflow(workflow, self.mcp_tools)

            if not workflow.id:
                workflow.id = generate_id_from_name(workflow.name)

            # Required for the built-in routes to work
            workflow.store_events = True

            # Propagate run_hooks_in_background setting to workflow and all its step agents/teams
            workflow.propagate_run_hooks_in_background(self.run_hooks_in_background)

    def _populate_registry(self) -> None:
        """Populate the registry with code-defined agents, teams, and workflows.

        This ensures that components loaded from DB can rehydrate their
        references using code-defined components via the registry, and that
        Studio surfaces holding this registry can see everything the OS
        serves.
        """
        if self.registry is None:
            self.registry = Registry()

        # Name the db behind the component catalog outright, including when
        # there is none. A Studio toolkit given no db of its own resolves this
        # rather than guessing at the head of registry.dbs: that list is
        # whatever the component tree happened to carry, so guessing binds
        # Studio to an agent-private session db and writes the catalog where no
        # OS surface reads it.
        if self.db is not None:
            # This OS's db backs the catalog. Declared again on every run so a
            # resync, or a db swapped in place, reaches Studio too.
            #
            # A db that cannot back a synchronous catalog still gets to be the
            # one declared: declare_component_db reads it as a refusal, and a
            # refusal is the honest answer. Reaching for the registry's list
            # instead whenever this db is async or remote would put the guess
            # back exactly where this declaration removed it, and would land
            # the catalog behind the listings an OS turns off for such a db:
            # /components, and the stored half of /agents, /teams and
            # /workflows.
            self.registry.declare_component_db(self.db)
        elif not self.registry.component_db_declared:
            # With no db of its own, declare what the USER put on the registry
            # rather than a flat None. This runs before component discovery, so
            # registry.dbs can only hold dbs passed to Registry(...) at this
            # point, never an agent-private one collected from the served tree
            # - and re-running it later must not reach for that list either.
            self.registry.declare_component_db(self.registry.dbs[0] if self.registry.dbs else None)

        # The catalog db also goes first in registry.dbs, so rehydration that
        # walks the list meets it before any component-private db. Ordering is
        # a convenience here, not the contract - the declaration above is what
        # Studio resolves - so an id already taken by another db is left to
        # add_db's own duplicate-id warning rather than warned about twice.
        if self.db is not None and isinstance(self.db, BaseDb):
            existing_index = next(
                (index for index, existing in enumerate(self.registry.dbs) if existing is self.db), None
            )
            if existing_index is None:
                self.registry.add_db(self.db)
                existing_index = next(
                    (index for index, existing in enumerate(self.registry.dbs) if existing is self.db), None
                )
            if existing_index is not None and existing_index > 0:
                self.registry.dbs.insert(0, self.registry.dbs.pop(existing_index))

        if self._agents:
            existing_agents = {aid: a for a in self.registry.agents if (aid := getattr(a, "id", None)) is not None}
            for agent in self._agents:
                agent_id = getattr(agent, "id", None)
                if agent_id is None:
                    continue
                existing_agent = existing_agents.get(agent_id)
                if existing_agent is not None:
                    if existing_agent is not agent:
                        log_warning(
                            f"Registry: multiple distinct agents share id '{agent_id}'. The registry keeps "
                            "the first, so Studio and registry-backed dispatch resolve that one, while "
                            "this AgentOS keeps serving the one it was constructed with over HTTP - the "
                            "same id resolves to different objects on the two surfaces. Give them "
                            "distinct ids."
                        )
                    continue
                self.registry.agents.append(agent)
                existing_agents[agent_id] = agent

        if self._teams:
            existing_teams = {tid: t for t in self.registry.teams if (tid := getattr(t, "id", None)) is not None}
            for team in self._teams:
                team_id = getattr(team, "id", None)
                if team_id is None:
                    continue
                existing_team = existing_teams.get(team_id)
                if existing_team is not None:
                    if existing_team is not team:
                        log_warning(
                            f"Registry: multiple distinct teams share id '{team_id}'. The registry keeps "
                            "the first, so Studio and registry-backed dispatch resolve that one, while "
                            "this AgentOS keeps serving the one it was constructed with over HTTP - the "
                            "same id resolves to different objects on the two surfaces. Give them "
                            "distinct ids."
                        )
                    continue
                self.registry.teams.append(team)
                existing_teams[team_id] = team

        if self._workflows:
            existing_workflows = {
                wid: w for w in self.registry.workflows if (wid := getattr(w, "id", None)) is not None
            }
            for workflow in self._workflows:
                workflow_id = getattr(workflow, "id", None)
                if workflow_id is None:
                    continue
                existing_workflow = existing_workflows.get(workflow_id)
                if existing_workflow is not None:
                    if existing_workflow is not workflow:
                        log_warning(
                            f"Registry: multiple distinct workflows share id '{workflow_id}'. The registry keeps "
                            "the first, so Studio and registry-backed dispatch resolve that one, while "
                            "this AgentOS keeps serving the one it was constructed with over HTTP - the "
                            "same id resolves to different objects on the two surfaces. Give them "
                            "distinct ids."
                        )
                    continue
                self.registry.workflows.append(workflow)
                existing_workflows[workflow_id] = workflow

    def _populate_registry_knowledge(self) -> None:
        """Add knowledge instances to the registry so stored components resolve them by name.

        Sources are the contents_db-backed instances collected by
        ``_auto_discover_knowledge_instances`` (which also feed the knowledge
        routes) plus every named instance handed to the AgentOS ``knowledge``
        param: registry resolution is by name and needs no ``contents_db``.
        Agent- and team-attached knowledge is added by the component walk in
        ``_populate_registry_components``.
        """
        if self.registry is None:
            self.registry = Registry()

        for kb in self.knowledge_instances or []:
            self.registry.add_knowledge(kb, mirrored=True)
        for kb in self.knowledge or []:
            self.registry.add_knowledge(kb, mirrored=True)

    def _iter_component_carriers(self) -> Iterator[Any]:
        """Every served component that can carry a toolkit: top-level
        agents and teams, team members recursively, and the agents/teams
        executing workflow steps (nested step containers included)."""
        seen: Set[int] = set()

        def visit(component: Any):
            if component is None or id(component) in seen:
                return
            seen.add(id(component))
            yield component
            # members may be a callable factory, which is truthy but not
            # iterable; only a materialized list can be walked, and a
            # factory cannot be called safely at construction time.
            members = getattr(component, "members", None)
            if isinstance(members, list):
                for member in members:
                    yield from visit(member)

        for top in [*self._agents, *self._teams]:
            yield from visit(top)

        def visit_steps(steps: Any):
            # steps may be a Steps container rather than a plain list --
            # WorkflowSteps accepts one at the top level, and a bare
            # container here would otherwise skip the whole subtree. A tuple
            # is a step list too, in both spellings.
            if not isinstance(steps, (list, tuple)):
                inner = getattr(steps, "steps", None)
                if steps is None or not isinstance(inner, (list, tuple)):
                    return
                steps = inner
            for step in steps:
                # Containers can reference each other; without this the
                # walk recurses until the stack dies, taking the whole
                # application down at construction time.
                if id(step) in seen:
                    continue
                # An agent or team may BE the step, with no Step wrapper
                # around it, and carries toolkits exactly like a wrapped
                # executor does. visit() records the id, which is what keeps
                # the guard above meaningful, so nothing marks it here.
                yield from visit(step)
                for attr in ("agent", "team"):
                    yield from visit(getattr(step, attr, None))
                # Every container a step can be: Loop, Parallel and
                # Condition hold steps, Condition also else_steps, Router
                # holds choices, and a nested Workflow its own step list.
                for attr in ("steps", "else_steps", "choices"):
                    yield from visit_steps(getattr(step, attr, None))
                nested = getattr(step, "workflow", None)
                if nested is not None and id(nested) not in seen:
                    seen.add(id(nested))
                    yield from visit_steps(getattr(nested, "steps", None))

        for workflow in self._workflows:
            yield from visit_steps(getattr(workflow, "steps", None))

    def _warn_on_foreign_studio_registries(self) -> None:
        """Warn when a served component carries a Studio toolkit bound to a
        different Registry than the one this OS populates.

        This is the likeliest zero-wiring mistake: StudioTools(registry=reg)
        built against one registry while AgentOS mints or holds another.
        Everything then appears to work - drafts save, publish works - but the
        OS's code-defined components are invisible to Studio, with no error
        anywhere. Adopting the tool's registry or rebinding the tool silently
        would both be surprising, so the split is loud instead.
        """
        from agno.tools.studio import StudioTools
        from agno.tools.studio_runner import StudioRunnerTools

        for component in self._iter_component_carriers():
            tools = getattr(component, "tools", None)
            # tools may be a callable factory; only a materialized list can be
            # inspected here, and a factory cannot be called safely at
            # construction time.
            if not isinstance(tools, list):
                continue
            for tool in tools:
                if not isinstance(tool, (StudioTools, StudioRunnerTools)):
                    continue
                component_label = getattr(component, "id", None) or getattr(component, "name", None)
                tool_registry = getattr(tool, "registry", None)
                if tool_registry is not None and tool_registry is not self.registry:
                    log_warning(
                        f"Component '{component_label}' carries {type(tool).__name__} bound to a different "
                        "Registry than this AgentOS populates: the OS's code-defined agents, teams, and "
                        "workflows will be invisible to it. Pass that registry to AgentOS (registry=...), "
                        "or construct the toolkit with the OS's registry."
                    )
                # No catalog db means every Studio WRITE refuses. Say so here:
                # the alternative to refusing is adopting a component-private
                # db and writing a catalog no OS surface serves, and a silent
                # success is the worse of the two failures.
                #
                # Only StudioTools: StudioRunnerTools registers no write tools
                # and lists and dispatches code-defined components perfectly
                # well with no db at all. And the question is what the TOOL
                # will resolve, which is its own registry's answer - the
                # warning above exists precisely because that can differ from
                # this OS's.
                tool_registry_db = tool_registry.resolve_component_db() if tool_registry is not None else None
                if isinstance(tool, StudioTools) and getattr(tool, "_db", None) is None and tool_registry_db is None:
                    log_warning(
                        f"Component '{component_label}' carries {type(tool).__name__} but this AgentOS has no "
                        "database that can back the component catalog, so every Studio write will answer "
                        "db_not_configured. Pass a synchronous db to AgentOS (db=...), or give the toolkit "
                        "its own (StudioTools(db=...))."
                    )

    def _populate_registry_managers(self) -> None:
        """Add memory and session summary managers from agents/teams to the registry.

        Each manager is tagged with a generated id of the form `{owner_id}__{kind}` so
        it can be looked up later. Managers are deduplicated by that id.
        """
        if self.registry is None:
            self.registry = Registry()

        registry = self.registry
        memory_by_id = {mid: m for m in registry.memory_managers if (mid := getattr(m, "id", None)) is not None}
        summary_by_id = {
            sid: s for s in registry.session_summary_managers if (sid := getattr(s, "id", None)) is not None
        }

        def _register(owner: Any, owner_type: str) -> None:
            owner_id = getattr(owner, "id", None)

            mm = getattr(owner, "memory_manager", None)
            if mm is not None:
                mm_id = getattr(mm, "id", None)
                if mm_id is not None:
                    existing = memory_by_id.get(mm_id)
                    if existing is not None:
                        if existing is not mm:
                            log_warning(
                                f"Registry: multiple distinct memory managers share id '{mm_id}'; keeping "
                                "the first. Give them distinct ids to avoid one shadowing the other."
                            )
                    else:
                        mm.owner_id = owner_id
                        mm.owner_type = owner_type
                        registry.memory_managers.append(mm)
                        memory_by_id[mm_id] = mm

            sm = getattr(owner, "session_summary_manager", None)
            if sm is not None:
                sm_id = getattr(sm, "id", None)
                if sm_id is not None:
                    existing = summary_by_id.get(sm_id)
                    if existing is not None:
                        if existing is not sm:
                            log_warning(
                                f"Registry: multiple distinct session summary managers share id '{sm_id}'; "
                                "keeping the first. Give them distinct ids to avoid one shadowing the other."
                            )
                    else:
                        sm.owner_id = owner_id
                        sm.owner_type = owner_type
                        registry.session_summary_managers.append(sm)
                        summary_by_id[sm_id] = sm

        for agent in self._agents:
            _register(agent, "agent")
        for team in self._teams:
            _register(team, "team")

    def _populate_registry_components(self) -> None:
        """Auto-populate the registry with components found in agents, teams and workflows.

        Recursively walks every agent, team and workflow (including nested teams,
        workflow steps and branch/route steps) and collects the models, tools,
        databases and vector databases they reference. This keeps the registry,
        and therefore ``GET /registry``, consistent with what is actually wired
        into the AgentOS without requiring components to be declared twice.

        The registry owns deduplication and cache invalidation (see
        ``Registry.add_*``): models/dbs/vector dbs dedupe by id/name, toolkits by
        (type, name, function set), and other callables by equality. User-provided
        registry components and instances shared across many agents are never
        duplicated, and user objects are only referenced, never mutated. The walk
        degrades gracefully: a malformed node is skipped rather than failing
        AgentOS construction.
        """
        if self.registry is None:
            self.registry = Registry()

        try:
            collect_components_from_os(self._agents, self._teams, self._workflows, self.registry)
        except Exception as e:
            log_debug(f"Registry auto-population skipped: {e}")

    def _setup_tracing(self) -> None:
        """Set up OpenTelemetry tracing for this AgentOS.

        Uses the AgentOS db if provided, otherwise falls back to the first available
        database from agents/teams/workflows.
        """
        # Use AgentOS db if explicitly provided
        if self.db is not None:
            setup_tracing_for_os(db=self.db)
            return

        # Fall back to finding the first available database
        db: Optional[Union[BaseDb, AsyncBaseDb, RemoteDb]] = None

        for agent in self._agents:
            if agent.db:
                db = agent.db
                break

        if db is None:
            for team in self._teams:
                if team.db:
                    db = team.db
                    break

        if db is None:
            for workflow in self._workflows:
                if workflow.db:
                    db = workflow.db
                    break

        if db is None:
            log_warning(
                "tracing=True but no database found. "
                "Provide 'db' parameter to AgentOS or to at least one agent/team/workflow."
            )
            return

        setup_tracing_for_os(db=db)

    def get_app(self) -> FastAPI:
        # Pick up MCP tools added to the registry after construction, before the
        # lifespan that connects them is assembled below
        collect_mcp_tools_from_registry(self.registry, self.mcp_tools)

        if self.base_app:
            fastapi_app = self.base_app

            # get_app() on a base_app mutates that app in place, so a second call (e.g. via
            # get_routes()) must not prepare it again: it would nest the combined lifespan
            # inside a new one (double db init, an orphaned MCP session manager) and mount
            # a second copy of every route.
            if self._base_app_prepared:
                return fastapi_app

            # Initialize MCP server if enabled
            if self.mcp and self._mcp_app is None:
                try:
                    from agno.os.mcp import get_mcp_server
                except ImportError as e:
                    raise ImportError(
                        "`fastmcp` not installed. It is required for `mcp=True`. "
                        "Please install it using `pip install fastmcp`."
                    ) from e

                self._mcp_app = get_mcp_server(self)

            # Collect all lifespans that need to be combined
            lifespans = []

            # The user provided lifespan
            if self.lifespan:
                # Wrap the user lifespan with agent_os parameter
                wrapped_lifespan = self._add_agent_os_to_lifespan_function(self.lifespan)
                lifespans.append(wrapped_lifespan)

            # The provided app's existing lifespan
            if fastapi_app.router.lifespan_context:
                lifespans.append(fastapi_app.router.lifespan_context)

            # The MCP tools lifespan
            if self.mcp_tools:
                lifespans.append(partial(mcp_lifespan, mcp_tools=self.mcp_tools))

            # The /mcp server lifespan
            if self.mcp and self._mcp_app:
                lifespans.append(self._mcp_app.lifespan)

            # The async database lifespan
            lifespans.append(partial(db_lifespan, agent_os=self))

            # The scheduler lifespan (after db so tables exist)
            if self._scheduler_enabled and self.db is not None:
                lifespans.append(partial(scheduler_lifespan, agent_os=self))

            # The durable job queue worker (after db so tables exist)
            if self.queue is not None and self.queue.durable:
                lifespans.append(partial(queue_lifespan, agent_os=self))

            # Launch telemetry starts here, after any pre-fork application
            # construction and after substantive worker startup lifespans.
            if self.telemetry:
                lifespans.append(partial(agent_os_telemetry_lifespan, agent_os=self))

            # The httpx client cleanup lifespan (should be last to close after other lifespans)
            lifespans.append(http_client_lifespan)

            # Combine lifespans and set them in the app
            if lifespans:
                fastapi_app.router.lifespan_context = _combine_app_lifespans(lifespans)

        else:
            lifespans = []

            # User provided lifespan
            if self.lifespan:
                lifespans.append(self._add_agent_os_to_lifespan_function(self.lifespan))

            # MCP tools lifespan
            if self.mcp_tools:
                lifespans.append(partial(mcp_lifespan, mcp_tools=self.mcp_tools))

            # MCP server lifespan (reuse an app built by an earlier get_app() call -- a
            # rebuilt one would orphan the started StreamableHTTP session manager)
            if self.mcp:
                if self._mcp_app is None:
                    try:
                        from agno.os.mcp import get_mcp_server
                    except ImportError as e:
                        raise ImportError(
                            "`fastmcp` not installed. It is required for `mcp=True`. "
                            "Please install it using `pip install fastmcp`."
                        ) from e

                    self._mcp_app = get_mcp_server(self)
                lifespans.append(self._mcp_app.lifespan)

            # Async database initialization lifespan
            lifespans.append(partial(db_lifespan, agent_os=self))  # type: ignore

            # The scheduler lifespan (after db so tables exist)
            if self._scheduler_enabled and self.db is not None:
                lifespans.append(partial(scheduler_lifespan, agent_os=self))

            # The durable job queue worker (after db so tables exist)
            if self.queue is not None and self.queue.durable:
                lifespans.append(partial(queue_lifespan, agent_os=self))

            # Launch telemetry starts here, after any pre-fork application
            # construction and after substantive worker startup lifespans.
            if self.telemetry:
                lifespans.append(partial(agent_os_telemetry_lifespan, agent_os=self))

            # The httpx client cleanup lifespan (should be last to close after other lifespans)
            lifespans.append(http_client_lifespan)

            final_lifespan = _combine_app_lifespans(lifespans) if lifespans else None
            fastapi_app = self._make_app(lifespan=final_lifespan)

        self._add_built_in_routes(app=fastapi_app)

        self._auto_discover_databases()
        self._auto_discover_media_storage()
        self._auto_discover_knowledge_instances()
        self._populate_registry_knowledge()

        # Collect models, tools, dbs and vector dbs from the agent/team/workflow tree
        self._populate_registry_components()

        routers = [
            get_session_router(dbs=self.dbs, media_storage=self.media_storage),
            get_media_router(dbs=self.dbs, media_storage=self.media_storage, settings=self.settings),
            get_memory_router(dbs=self.dbs),
            get_learnings_router(dbs=self.dbs, settings=self.settings),
            get_eval_router(
                dbs=self.dbs,
                agents=self._agents or None,  # type: ignore[arg-type]
                teams=self._teams or None,  # type: ignore[arg-type]
            ),
            get_metrics_router(dbs=self.dbs),
            get_knowledge_router(knowledge_instances=self.knowledge_instances),
            get_traces_router(dbs=self.dbs),
            get_database_router(self, settings=self.settings),
        ]
        # Routes that require a database
        if self.db is not None:
            if isinstance(self.db, BaseDb):
                routers.append(get_components_router(os_db=self.db, registry=self.registry))
            else:
                routers.append(_get_disabled_feature_router("/components", "Components", "sync db (BaseDb)"))
            routers.append(
                get_schedule_router(
                    os_db=self.db,
                    settings=self.settings,
                    include_agents=self.agents,
                    include_teams=self.teams,
                    include_workflows=self.workflows,
                )
            )
            routers.append(get_approval_router(os_db=self.db, settings=self.settings))
            routers.append(get_service_accounts_router(os_db=self.db, settings=self.settings))
        else:
            log_debug(
                "Components, Scheduler, Approval, and Service Account routers not enabled: "
                "requires a db to be provided to AgentOS"
            )
            for prefix, tag in [
                ("/components", "Components"),
                ("/schedules", "Schedules"),
                ("/approvals", "Approvals"),
                ("/service-accounts", "Service Accounts"),
            ]:
                routers.append(_get_disabled_feature_router(prefix, tag, "db"))

        # Registry router
        if self.registry is not None:
            routers.append(get_registry_router(registry=self.registry))
        else:
            log_debug("Registry router not enabled: requires a registry to be provided to AgentOS")
            routers.append(_get_disabled_feature_router("/registry", "Registry", "registry"))

        for router in routers:
            self._add_router(fastapi_app, router)

        # Mount MCP if needed
        if self.mcp:
            self._mount_mcp_app(fastapi_app)

        if not self._app_set:

            @fastapi_app.exception_handler(RequestValidationError)
            async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
                log_error(f"Validation error (422): {exc.errors()}")
                # Delegate the body to FastAPI's own handler: pydantic v2 puts the live
                # exception object in ``ctx["error"]`` for any validator that raised
                # ValueError, so the errors list must be run through ``jsonable_encoder``
                # before it can be a JSON body. Building it here by hand is what made every
                # custom validator answer 500 instead of 422.
                return await request_validation_exception_handler(request, exc)

            @fastapi_app.exception_handler(HTTPException)
            async def http_exception_handler(_, exc: HTTPException) -> JSONResponse:
                log_error(f"HTTP exception: {exc.status_code} {exc.detail}")
                return JSONResponse(
                    status_code=exc.status_code,
                    content=_error_body(str(exc.detail), exc),
                )

            @fastapi_app.exception_handler(HTTPStatusError)
            async def http_status_error_handler(_: Request, exc: HTTPStatusError) -> JSONResponse:
                status_code = exc.response.status_code
                detail = exc.response.text
                log_error(f"Downstream server returned HTTP status error: {status_code} {detail}")
                return JSONResponse(
                    status_code=status_code,
                    content={"detail": detail},
                )

            @fastapi_app.exception_handler(Exception)
            async def general_exception_handler(_: Request, exc: Exception) -> JSONResponse:
                import traceback

                log_error(f"Unhandled exception:\n{traceback.format_exc(limit=5)}")

                status_code = getattr(exc, "status_code", 500)
                # 4xx exceptions that carry their own status wrote their
                # message for the client; 5xx details must never echo
                # str(exc) - unhandled server errors are routinely store or
                # driver failures whose text carries connection strings, SQL
                # fragments, and hostnames. The full traceback is in the
                # server log above; the wire gets the exception type only.
                detail = str(exc) if status_code < 500 else f"Internal server error ({type(exc).__name__})"
                return JSONResponse(
                    status_code=status_code,
                    content=_error_body(detail, exc),
                )

        # Update CORS middleware
        update_cors_middleware(fastapi_app, self.cors_allowed_origins)  # type: ignore

        # Set agent_os_id and cors_allowed_origins on app state
        # This allows middleware (like JWT) to access these values
        fastapi_app.state.agent_os_id = self.id
        fastapi_app.state.cors_allowed_origins = self.cors_allowed_origins

        # Store internal service token for scheduler auth bypass
        if self._internal_service_token:
            fastapi_app.state.internal_service_token = self._internal_service_token

        # Install the single auth layer whenever any credential is configured. It
        # covers the REST routes and the mounted /mcp app together (one middleware on
        # the parent app), so the mounted sub-app carries no auth code of its own.
        security_key = self.settings.os_security_key if self.settings else None
        jwt_env_configured = bool(getenv("JWT_VERIFICATION_KEY") or getenv("JWT_JWKS_FILE"))
        if self.authorization:
            # Set authorization_enabled flag on settings so security key validation is skipped
            self.settings.authorization_enabled = True
            if jwt_env_configured and bool(security_key):
                log_warning(
                    "Both JWT configuration (JWT_VERIFICATION_KEY or JWT_JWKS_FILE) and OS_SECURITY_KEY are set. "
                    "With authorization=True, only JWT authorization will be used. "
                    "Consider removing OS_SECURITY_KEY from your environment."
                )

        # The verifier is the *capability* to check ``agno_pat_`` tokens and exists
        # whenever there is a db to verify against. It must be on app.state even when
        # no auth is configured here: the WS authenticate action, the REST dependency,
        # and any manually added JWTMiddleware all resolve it at request time. Whether
        # a request is *required* to authenticate is a separate policy decision -- the
        # middleware below only installs when the operator configured a base auth
        # mechanism, so a db alone never locks an instance down.
        service_account_verifier = self._get_service_account_verifier()
        if service_account_verifier is not None:
            fastapi_app.state.service_account_verifier = service_account_verifier

        auth_configured = bool(self.authorization or jwt_env_configured or security_key)
        if auth_configured:
            # In JWT mode the security key is ignored (JWT takes precedence), matching
            # get_effective_auth_mode; pass None so the middleware doesn't fall back to it.
            effective_key = None if (self.authorization or jwt_env_configured) else security_key
            self._add_auth_middleware(fastapi_app, security_key=effective_key)

        # Under mcp_auth, the OAuth flow routes must be reachable without an agno bearer.
        # AgentOS exempts them on the AuthMiddleware it installs itself, but an agno
        # JWTMiddleware installed MANUALLY on a base_app carries its own exclusions that
        # agno cannot amend. Fail fast (with the exact paths) rather than 401 connector
        # discovery. (Only agno's own AuthMiddleware is inspected; see the method docstring.)
        self._check_mcp_auth_middleware_composition(fastapi_app)

        # Add trailing slash normalization middleware
        from agno.os.middleware.trailing_slash import TrailingSlashMiddleware

        fastapi_app.add_middleware(TrailingSlashMiddleware)

        if self.base_app is not None:
            self._base_app_prepared = True

        return fastapi_app

    def _get_service_account_verifier(self) -> Optional[Any]:
        """Get (lazily creating) the verifier for service account tokens.

        Returns None when the AgentOS has no db - service accounts live in the
        AgentOS database, so there is nothing to verify against without one.
        """
        if self.db is None:
            return None
        if self._service_account_verifier is None:
            from agno.os.service_accounts import ServiceAccountVerifier

            self._service_account_verifier = ServiceAccountVerifier(
                db=self.db,
                cache_ttl_seconds=self.settings.service_account_cache_ttl_seconds,
            )
        return self._service_account_verifier

    def _get_mcp_auth_provider(self) -> Optional["AuthProvider"]:
        """The resolved fastmcp auth provider for the MCP endpoint, or None.

        Resolution (type checks, ``MultiAuth`` composition with the service-account
        verifier) happens once: ``get_mcp_server`` and the auth-middleware exemptions
        must see the same instance.
        """
        if self.mcp_auth is None:
            return None
        if self._resolved_mcp_auth is None:
            from agno.os.mcp_auth import resolve_mcp_auth

            self._resolved_mcp_auth = resolve_mcp_auth(self)
        return self._resolved_mcp_auth

    def mcp_auth_exempt_paths(self) -> List[str]:
        """The MCP OAuth routes that must be public (exempt from any auth middleware).

        When ``mcp_auth`` is set, connector clients (claude.ai, ChatGPT) hit discovery,
        ``/register``, ``/authorize``, ``/token`` and the ``/mcp`` challenge with no agno
        bearer, so those paths must not be behind the parent auth layer. AgentOS exempts
        them automatically on the middleware it installs; if you install your own JWT/auth
        middleware on a ``base_app``, pass these to its ``excluded_route_paths``. Returns
        ``[]`` when ``mcp_auth`` is unset.
        """
        provider = self._get_mcp_auth_provider()
        if provider is None:
            return []
        from agno.os.mcp_auth import mcp_auth_route_paths

        return mcp_auth_route_paths(provider)

    def _check_mcp_auth_middleware_composition(self, app: FastAPI) -> None:
        """Reject an mcp_auth deployment whose OAuth routes a manual agno auth middleware blocks.

        An agno ``JWTMiddleware`` (an alias of ``AuthMiddleware``) installed via
        ``app.add_middleware(JWTMiddleware, ...)`` on a ``base_app`` carries its own
        ``excluded_route_paths``, which AgentOS cannot amend. If it does not exempt the
        OAuth routes, connector discovery / DCR / the ``/mcp`` challenge 401 before FastMCP
        runs -- and silently, so it reads as a token problem. The AuthMiddleware AgentOS
        installs itself already carries the exemptions (so it is skipped here).

        Only agno's own ``AuthMiddleware`` is inspected. A THIRD-PARTY auth middleware
        (authlib, fastapi-users, a hand-rolled ``BaseHTTPMiddleware`` doing bearer
        validation) is not detected here -- AgentOS can't introspect an arbitrary
        middleware's exemptions -- so if you install one on a ``base_app`` you must exempt
        ``os.mcp_auth_exempt_paths()`` from it yourself. It fails closed either way (a 401
        at discovery, never an open endpoint).
        """
        exempt_paths = self.mcp_auth_exempt_paths()
        if not exempt_paths:
            return
        from agno.os.middleware.jwt import AuthMiddleware, jwt_kwargs_have_key_source

        exempt = set(exempt_paths)
        for mw in getattr(app, "user_middleware", None) or []:
            cls = getattr(mw, "cls", None)
            if not (isinstance(cls, type) and issubclass(cls, AuthMiddleware)):
                continue
            kwargs = getattr(mw, "kwargs", None) or {}
            # A plain security-key / service-account layer (no JWT source) does not
            # 401 an unauthenticated request when no bearer is present the way a
            # JWT-validating one does; only the latter blocks the browser-driven flow.
            if not jwt_kwargs_have_key_source(kwargs):
                continue
            if exempt.issubset(set(kwargs.get("excluded_route_paths") or [])):
                continue  # this middleware already exempts the OAuth routes
            raise ValueError(
                "AgentOS(mcp_auth=...) with a manually-installed agno JWTMiddleware requires the OAuth "
                "flow routes to be exempted from it, or connector discovery (claude.ai / ChatGPT) is blocked "
                "with a 401 before it runs. Add these to your middleware's excluded_route_paths: "
                f"{sorted(exempt)} (get them from os.mcp_auth_exempt_paths() or "
                "agno.os.mcp_auth.mcp_auth_route_paths(provider)). Or let AgentOS manage auth via "
                "authorization=True instead of installing the middleware yourself."
            )

    def _add_auth_middleware(self, fastapi_app: FastAPI, security_key: Optional[str]) -> None:
        """Install the single AgentOS auth layer on the parent app.

        One ``AuthMiddleware`` covers JWTs, service-account tokens, the internal
        service token, and the OS security key across the REST routes AND the mounted
        ``/mcp`` app (Starlette runs parent-app middleware before dispatching to a
        mount), so no auth code lives on the mounted sub-app.

        Called whenever any credential is configured: ``authorization=True`` (JWT),
        an ``OS_SECURITY_KEY``, or a service-account verifier (a db is present).
        """
        from agno.os.middleware.jwt import AuthMiddleware, JWTValidator, build_jwt_middleware_kwargs
        from agno.os.scopes import AgentOSScope

        middleware_kwargs = build_jwt_middleware_kwargs(
            self.authorization_config,
            authorization=self.authorization,
            service_account_verifier=self._get_service_account_verifier(),
        )
        middleware_kwargs["security_key"] = security_key
        algorithm = middleware_kwargs["algorithm"]
        verification_keys = middleware_kwargs["verification_keys"]
        jwks_file = middleware_kwargs["jwks_file"]
        verify_audience = middleware_kwargs["verify_audience"]
        audience = middleware_kwargs.get("audience")
        admin_scope: Optional[str] = middleware_kwargs.get("admin_scope")
        user_isolation = middleware_kwargs.get("user_isolation", False)

        jwt_configured = bool(
            verification_keys or jwks_file or getenv("JWT_VERIFICATION_KEY") or getenv("JWT_JWKS_FILE")
        )
        # Fail fast at app construction (not on the first request) if RBAC was asked for
        # with no way to verify a JWT: otherwise every JWT and anonymous request would fall
        # through unauthenticated, silently serving an OPEN instance. AuthMiddleware enforces
        # the same invariant as a backstop for the manual add_middleware path.
        if self.authorization and not jwt_configured:
            raise ValueError(
                "AgentOS(authorization=True) requires a JWT verification key: set JWT_VERIFICATION_KEY or "
                "JWT_JWKS_FILE (or pass verification_keys / jwks_file via authorization_config). Without one, "
                "JWT and anonymous requests are not authenticated and RBAC is not enforced. For "
                "service-account-only enforcement, use a db without authorization=True."
            )
        log_info("Adding AgentOS auth middleware" + (f" (JWT algorithm: {algorithm})" if jwt_configured else ""))

        # A JWT validator on app.state is only meaningful (and only constructible --
        # it requires a key) when JWT is actually configured. WebSocket JWT auth reads it.
        if jwt_configured:
            fastapi_app.state.jwt_validator = JWTValidator(
                verification_keys=verification_keys,
                jwks_file=jwks_file,
                algorithm=algorithm,
            )
        # Expose audience config + admin scope on app.state so WebSocket auth
        # (which does not flow through HTTP middleware) can honour them.
        fastapi_app.state.jwt_verify_audience = verify_audience
        fastapi_app.state.jwt_audience = audience
        fastapi_app.state.admin_scope = admin_scope or AgentOSScope.ADMIN.value
        # User isolation is opt-in and orthogonal to RBAC. When False (default)
        # JWT/RBAC still apply but the per-user DB wrapper and ownership gates
        # added by the user-scoped-DB work stay dormant.
        fastapi_app.state.user_isolation_enabled = user_isolation

        # Only interfaces that verify the authenticity of their own inbound requests
        # (Slack HMAC, Telegram/WhatsApp webhook secrets -- see
        # BaseInterface.authenticates_own_requests) are excluded from the central auth
        # layer alongside the public routes. Interfaces that do NOT self-authenticate
        # (e.g. A2A) stay behind AuthMiddleware, so enabling authentication protects them
        # too. Passing excluded_route_paths replaces the middleware defaults, so the
        # defaults are repeated here.
        excluded_route_paths: Optional[List[str]] = None
        interface_prefixes: List[str] = []
        if self.interfaces:
            interface_prefixes = [
                f"{interface.prefix}/*"
                for interface in self.interfaces
                if getattr(interface, "authenticates_own_requests", False) and getattr(interface, "prefix", None)
            ]
        # With mcp_auth set, the fastmcp provider owns authentication for the whole MCP
        # surface: the MCP path itself (the provider's RequireAuthMiddleware emits the
        # RFC 9728 challenge) and its OAuth/discovery routes, which browsers and connector
        # backends hit with no agno bearer. Exact paths only, derived from the provider --
        # a hand-typed wildcard here would silently un-authenticate unrelated routes.
        mcp_auth_paths: List[str] = []
        mcp_auth_provider = self._get_mcp_auth_provider()
        if mcp_auth_provider is not None:
            from agno.os.mcp_auth import mcp_auth_route_paths

            mcp_auth_paths = mcp_auth_route_paths(mcp_auth_provider)
        if interface_prefixes or mcp_auth_paths:
            excluded_route_paths = (
                [
                    "/",
                    "/health",
                    "/info",
                    "/docs",
                    "/redoc",
                    "/openapi.json",
                    "/docs/oauth2-redirect",
                ]
                + interface_prefixes
                + mcp_auth_paths
            )

        middleware_kwargs["excluded_route_paths"] = excluded_route_paths

        # Interface routes are authorization-gated by the scope entries each interface
        # declares (Interface.get_scope_mappings), merged here against its ACTUAL mount
        # prefix. This covers operator-configurable prefixes (A2A/AGUI(prefix=...)) and
        # subclasses, which the default scope map (keyed on default prefixes) cannot -- an
        # interface that runs entities but has no scope entry falls through to the
        # unmapped-route default (allow). Self-authenticating interfaces are excluded from
        # the auth layer entirely, so their mappings are irrelevant here.
        interface_mappings: Dict[str, List[str]] = {}
        for interface in self.interfaces:
            if getattr(interface, "authenticates_own_requests", False):
                continue
            interface_mappings.update(interface.get_scope_mappings())
        if interface_mappings:
            # middleware_kwargs carries no scope_mappings today (AuthorizationConfig has no
            # such field); the merge is defensive so that if one is ever threaded through,
            # it wins over interface defaults instead of being clobbered.
            merged = dict(middleware_kwargs.get("scope_mappings") or {})
            interface_mappings.update(merged)
            middleware_kwargs["scope_mappings"] = interface_mappings

        fastapi_app.add_middleware(AuthMiddleware, **middleware_kwargs)

    def get_routes(self) -> List[Any]:
        """Retrieve all routes from the FastAPI app.

        Returns:
            List[Any]: List of routes included in the FastAPI app.
        """
        app = self.get_app()

        return flatten_routes(app.routes)

    def _add_router(self, fastapi_app: FastAPI, router: APIRouter) -> None:
        """Add a router to the FastAPI app, avoiding route conflicts.

        Args:
            router: The APIRouter to add
        """

        conflicts = find_conflicting_routes(fastapi_app, router)
        conflicting_routes = [conflict["route"] for conflict in conflicts]

        if conflicts and self._app_set:
            if self.on_route_conflict == "preserve_base_app":
                # Skip conflicting AgentOS routes, prefer user's existing routes
                for conflict in conflicts:
                    methods_str = ", ".join(conflict["methods"])  # type: ignore
                    log_debug(
                        f"Skipping conflicting AgentOS route: {methods_str} {conflict['path']} - "
                        f"Using existing custom route instead"
                    )

                # Create a new router without the conflicting routes
                filtered_router = APIRouter()
                for route in router.routes:
                    if route not in conflicting_routes:
                        filtered_router.routes.append(route)

                # Use the filtered router if it has any routes left
                if filtered_router.routes:
                    fastapi_app.include_router(filtered_router)

            elif self.on_route_conflict == "preserve_agentos":
                # Log warnings but still add all routes (AgentOS routes will override)
                for conflict in conflicts:
                    methods_str = ", ".join(conflict["methods"])  # type: ignore
                    log_warning(
                        f"Route conflict detected: {methods_str} {conflict['path']} - "
                        f"AgentOS route will override existing custom route"
                    )

                # Remove conflicting routes
                for route in fastapi_app.routes:
                    for conflict in conflicts:
                        if isinstance(route, APIRoute):
                            if route.path == conflict["path"] and list(route.methods) == list(conflict["methods"]):  # type: ignore
                                fastapi_app.routes.pop(fastapi_app.routes.index(route))

                fastapi_app.include_router(router)

            elif self.on_route_conflict == "error":
                conflicting_paths = [conflict["path"] for conflict in conflicts]
                raise ValueError(f"Route conflict detected: {conflicting_paths}")

        else:
            # No conflicts, add router normally
            fastapi_app.include_router(router)

    def _get_telemetry_data(self) -> Dict[str, Any]:
        """Get the telemetry data for the OS"""
        agent_ids = []
        team_ids = []
        workflow_ids = []
        for agent in self.agents or []:
            agent_ids.append(agent.id)
        for team in self.teams or []:
            team_ids.append(team.id)
        for workflow in self.workflows or []:
            workflow_ids.append(workflow.id)
        return {
            "agents": agent_ids,
            "teams": team_ids,
            "workflows": workflow_ids,
            "interfaces": [interface.type for interface in self.interfaces] if self.interfaces else None,
        }

    def _auto_discover_media_storage(self) -> None:
        """Fall back to the first media storage configured on an agent, team or workflow.

        Media offload is configured per agent/team/workflow, so AgentOS itself is usually left
        without a backend. Mirrors how tracing falls back to the first available database.
        """
        if self.media_storage is not None:
            return

        # Collected rather than short-circuited so a mixed tree can be reported.
        found = [
            entity.media_storage
            for group in (self._agents, self._teams, self._workflows)
            for entity in group
            if entity.media_storage
        ]
        if not found:
            return

        self.media_storage = found[0]
        # Compared on backend and bucket so two equivalent instances do not read as a conflict.
        identities = {(getattr(storage, "backend_name", None), getattr(storage, "bucket", None)) for storage in found}
        if len(identities) > 1:
            log_warning(
                "Multiple media storage backends found across the agent tree, serving media with "
                f"{type(self.media_storage).__name__}. Set media_storage on AgentOS to choose explicitly."
            )
        else:
            log_debug(f"Media storage auto-discovered from the agent tree: {type(self.media_storage).__name__}")

    def _auto_discover_databases(self) -> None:
        """Auto-discover and initialize the databases used by all contextual agents, teams and workflows."""

        dbs: Dict[str, List[Union[BaseDb, AsyncBaseDb, RemoteDb]]] = {}
        knowledge_dbs: Dict[
            str, List[Union[BaseDb, AsyncBaseDb, RemoteDb]]
        ] = {}  # Track databases specifically used for knowledge

        for entry in self.agents or []:
            if isinstance(entry, AgentFactory):
                if entry.db:
                    self._register_db_with_validation(dbs, entry.db)
            elif isinstance(entry, Agent):
                if entry.db:
                    self._register_db_with_validation(dbs, entry.db)
                agent_contents_db = getattr(entry.knowledge, "contents_db", None) if entry.knowledge else None
                if agent_contents_db:
                    self._register_db_with_validation(knowledge_dbs, agent_contents_db)
            else:
                # External framework agents (BaseExternalAgent / AgentProtocol)
                agent_db = getattr(entry, "db", None)
                if agent_db:
                    self._register_db_with_validation(dbs, agent_db)

        for team_entry in self.teams or []:
            if isinstance(team_entry, TeamFactory):
                if team_entry.db:
                    self._register_db_with_validation(dbs, team_entry.db)
            elif isinstance(team_entry, Team):
                if team_entry.db:
                    self._register_db_with_validation(dbs, team_entry.db)
                team_contents_db = getattr(team_entry.knowledge, "contents_db", None) if team_entry.knowledge else None
                if team_contents_db:
                    self._register_db_with_validation(knowledge_dbs, team_contents_db)

        for wf_entry in self.workflows or []:
            if isinstance(wf_entry, WorkflowFactory):
                if wf_entry.db:
                    self._register_db_with_validation(dbs, wf_entry.db)
            elif isinstance(wf_entry, Workflow):
                if wf_entry.db:
                    self._register_db_with_validation(dbs, wf_entry.db)

        for knowledge_base in self.knowledge or []:
            if knowledge_base.contents_db:
                self._register_db_with_validation(knowledge_dbs, knowledge_base.contents_db)

        for interface in self.interfaces or []:
            if interface.agent and interface.agent.db:
                self._register_db_with_validation(dbs, interface.agent.db)
            elif interface.team and interface.team.db:
                self._register_db_with_validation(dbs, interface.team.db)

        # Register AgentOS db if provided
        if self.db is not None:
            self._register_db_with_validation(dbs, self.db)

        self.dbs = dbs
        self.knowledge_dbs = knowledge_dbs

        # Initialize all discovered databases
        if self.auto_provision_dbs:
            self._pending_async_db_init = True

    def _initialize_sync_databases(self) -> None:
        """Initialize sync databases."""
        from itertools import chain

        unique_dbs = list(
            {
                id(db): db
                for db in chain(
                    chain.from_iterable(self.dbs.values()), chain.from_iterable(self.knowledge_dbs.values())
                )
            }.values()
        )

        for db in unique_dbs:
            if isinstance(db, AsyncBaseDb):
                continue  # Skip async dbs

            try:
                if hasattr(db, "_create_all_tables") and callable(db._create_all_tables):
                    db._create_all_tables()
            except Exception as e:
                log_warning(f"Failed to initialize {db.__class__.__name__} (id: {db.id}): {str(e)}")

    async def _initialize_async_databases(self) -> None:
        """Initialize async databases."""

        from itertools import chain

        unique_dbs = list(
            {
                id(db): db
                for db in chain(
                    chain.from_iterable(self.dbs.values()), chain.from_iterable(self.knowledge_dbs.values())
                )
            }.values()
        )

        for db in unique_dbs:
            if not isinstance(db, AsyncBaseDb):
                continue  # Skip sync dbs

            try:
                if hasattr(db, "_create_all_tables") and callable(db._create_all_tables):
                    await db._create_all_tables()
            except Exception as e:
                log_warning(f"Failed to initialize async {db.__class__.__name__} (id: {db.id}): {str(e)}")

    async def _close_databases(self) -> None:
        """Close all database connections and release connection pools."""
        from itertools import chain

        if not hasattr(self, "dbs") or not hasattr(self, "knowledge_dbs"):
            return

        unique_dbs = list(
            {
                id(db): db
                for db in chain(
                    chain.from_iterable(self.dbs.values()), chain.from_iterable(self.knowledge_dbs.values())
                )
            }.values()
        )

        for db in unique_dbs:
            try:
                if hasattr(db, "close") and callable(db.close):
                    if isinstance(db, AsyncBaseDb):
                        await db.close()
                    else:
                        db.close()
            except Exception as e:
                log_warning(f"Failed to close {db.__class__.__name__} (id: {db.id}): {str(e)}")

    def _get_db_table_names(self, db: BaseDb) -> Dict[str, str]:
        """Get the table names for a database"""
        table_names = {
            "session_table_name": db.session_table_name,
            "memory_table_name": db.memory_table_name,
            "learnings_table_name": db.learnings_table_name,
            "metrics_table_name": db.metrics_table_name,
            "evals_table_name": db.eval_table_name,
            "knowledge_table_name": db.knowledge_table_name,
        }
        return {k: v for k, v in table_names.items() if v is not None}

    def _register_db_with_validation(
        self,
        registered_dbs: Dict[str, List[Union[BaseDb, AsyncBaseDb, RemoteDb]]],
        db: Union[BaseDb, AsyncBaseDb, RemoteDb],
    ) -> None:
        """Register a database in the contextual OS after validating it is not conflicting with registered databases"""
        if db.id in registered_dbs:
            registered_dbs[db.id].append(db)
        else:
            registered_dbs[db.id] = [db]

    def _auto_discover_knowledge_instances(self) -> None:
        """Auto-discover the knowledge instances used by all contextual agents, teams and workflows."""
        seen_instances: set[int] = set()  # Track by object identity
        knowledge_instances: List[Union[Knowledge, RemoteKnowledge]] = []

        def _add_knowledge_if_not_duplicate(knowledge: Any) -> None:
            """Add knowledge instance if it's not already in the list (by object identity)."""
            # Only handle Knowledge and RemoteKnowledge instances that have contents_db
            contents_db = getattr(knowledge, "contents_db", None)
            if not contents_db:
                return
            # Deduplicate by object identity to allow multiple knowledge instances with the same contents_db
            if id(knowledge) in seen_instances:
                return
            seen_instances.add(id(knowledge))
            # Only append if it's a Knowledge or RemoteKnowledge instance
            if isinstance(knowledge, (Knowledge, RemoteKnowledge)):
                knowledge_instances.append(knowledge)

        for agent in self._agents:
            if agent.knowledge:
                _add_knowledge_if_not_duplicate(agent.knowledge)

        for team in self._teams:
            if team.knowledge:
                _add_knowledge_if_not_duplicate(team.knowledge)

        for knowledge_base in self.knowledge or []:
            _add_knowledge_if_not_duplicate(knowledge_base)

        if self.registry is not None:
            for knowledge_base in self.registry.knowledge or []:
                # Only user-declared registry knowledge feeds the routes.
                # Syncs mirror member- and step-owned knowledge into the
                # registry for name resolution; that is not a grant of
                # route-level exposure -- and the registry, not this OS, keeps
                # the provenance, so a mirror by another AgentOS sharing the
                # registry is excluded here too. Everything not mirrored the
                # user registered, whether at construction or after (resync
                # picks it up).
                if self.registry.knowledge_is_mirrored(knowledge_base):
                    continue
                _add_knowledge_if_not_duplicate(knowledge_base)

        self.knowledge_instances = knowledge_instances

        # Validate that all knowledge instances have unique names
        # Duplicate names cause content isolation issues since linked_to uses the name
        self._validate_knowledge_instance_names()

    def _validate_knowledge_instance_names(self) -> None:
        """Validate that all knowledge instances have unique names.

        Raises:
            ValueError: If duplicate knowledge instance names are detected.
        """
        # Track seen combinations of (name, db_id, table) to detect true duplicates
        # Same name is OK if using different contents_db or different table
        seen_combinations: dict[tuple[str, str, str], str] = {}  # (name, db_id, table) -> description
        duplicates: list[str] = []

        for knowledge in self.knowledge_instances:
            contents_db = getattr(knowledge, "contents_db", None)
            if not contents_db:
                continue

            db_id = getattr(contents_db, "id", None)
            if not db_id:
                continue

            # Get the name (with fallback)
            knowledge_name = getattr(knowledge, "name", None) or f"knowledge_{db_id}"
            table_name = getattr(contents_db, "knowledge_table_name", None) or "unknown"

            # Create unique key based on name + db + table
            key = (knowledge_name, db_id, table_name)

            if key in seen_combinations:
                duplicates.append(f"'{knowledge_name}' in table '{table_name}'")
            else:
                seen_combinations[key] = table_name

        if duplicates:
            unique_duplicates = list(set(duplicates))
            error_msg = (
                f"Duplicate knowledge instances detected:\n"
                f"  {', '.join(unique_duplicates)}\n\n"
                "Each knowledge instance must have a unique combination of (knowledgename, database, table). "
                "To fix this, give each knowledge instance a unique `name` parameter."
            )
            log_error(error_msg)
            raise ValueError(error_msg)

    def _get_session_config(self) -> SessionConfig:
        session_config = self.config.session if self.config and self.config.session else SessionConfig()

        if session_config.dbs is None:
            session_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in session_config.dbs]
        for db_id, dbs in self.dbs.items():
            if db_id not in dbs_with_specific_config:
                # Collect unique table names from all databases with the same id
                unique_tables = list({db.session_table_name for db in dbs if db.session_table_name is not None})
                session_config.dbs.append(
                    DatabaseConfig(
                        db_id=db_id,
                        domain_config=SessionDomainConfig(display_name=db_id),
                        tables=unique_tables,
                    )
                )

        return session_config

    def _get_memory_config(self) -> MemoryConfig:
        memory_config = self.config.memory if self.config and self.config.memory else MemoryConfig()

        if memory_config.dbs is None:
            memory_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in memory_config.dbs]

        for db_id, dbs in self.dbs.items():
            if db_id not in dbs_with_specific_config:
                # Collect unique table names from all databases with the same id
                unique_tables = list({db.memory_table_name for db in dbs if db.memory_table_name is not None})
                memory_config.dbs.append(
                    DatabaseConfig(
                        db_id=db_id,
                        domain_config=MemoryDomainConfig(display_name=db_id),
                        tables=unique_tables,
                    )
                )

        return memory_config

    def _get_learning_config(self) -> LearningConfig:
        learning_config = self.config.learning if self.config and self.config.learning else LearningConfig()

        if learning_config.dbs is None:
            learning_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in learning_config.dbs]

        for db_id, dbs in self.dbs.items():
            if db_id not in dbs_with_specific_config:
                # Collect unique table names from all databases with the same id
                unique_tables = list({db.learnings_table_name for db in dbs if db.learnings_table_name is not None})
                learning_config.dbs.append(
                    DatabaseConfig(
                        db_id=db_id,
                        domain_config=LearningDomainConfig(display_name=db_id),
                        tables=unique_tables,
                    )
                )

        return learning_config

    def _get_knowledge_config(self) -> KnowledgeConfig:
        knowledge_config = self.config.knowledge if self.config and self.config.knowledge else KnowledgeConfig()

        if knowledge_config.dbs is None:
            knowledge_config.dbs = []
        if knowledge_config.knowledge_instances is None:
            knowledge_config.knowledge_instances = []

        # Track seen knowledge IDs to deduplicate
        seen_knowledge_ids: set[str] = set()
        # Collect db_id → table_names from knowledge instances for building dbs below
        discovered_db_tables: Dict[str, set] = {}

        # Build flat list of knowledge instances
        for knowledge in self.knowledge_instances:
            contents_db = getattr(knowledge, "contents_db", None)
            if not contents_db:
                continue

            db_id = getattr(contents_db, "id", None)
            if not db_id:
                continue

            table_name = getattr(contents_db, "knowledge_table_name", None) or "unknown"
            knowledge_name = getattr(knowledge, "name", None) or f"knowledge_{db_id}"
            knowledge_id = _generate_knowledge_id(knowledge_name, db_id, table_name)

            # Collect table names per db_id for building dbs list
            if db_id not in discovered_db_tables:
                discovered_db_tables[db_id] = set()
            discovered_db_tables[db_id].add(table_name)

            # Skip if already processed (deduplicate by knowledge_id)
            if knowledge_id in seen_knowledge_ids:
                continue
            seen_knowledge_ids.add(knowledge_id)

            instance_config = KnowledgeInstanceConfig(
                id=knowledge_id,
                name=knowledge_name,
                description=getattr(knowledge, "description", None),
                db_id=db_id,
                table=table_name,
            )
            knowledge_config.knowledge_instances.append(instance_config)

        # Build KnowledgeDatabaseConfig for each db with its tables (as strings)
        dbs_with_specific_config = [db.db_id for db in knowledge_config.dbs]

        for db_id, table_names in discovered_db_tables.items():
            if db_id not in dbs_with_specific_config:
                knowledge_config.dbs.append(
                    KnowledgeDatabaseConfig(
                        db_id=db_id,
                        domain_config=KnowledgeDomainConfig(display_name=db_id),
                        tables=list(table_names),
                    )
                )

        return knowledge_config

    def _get_metrics_config(self) -> MetricsConfig:
        metrics_config = self.config.metrics if self.config and self.config.metrics else MetricsConfig()

        if metrics_config.dbs is None:
            metrics_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in metrics_config.dbs]

        for db_id, dbs in self.dbs.items():
            if db_id not in dbs_with_specific_config:
                # Collect unique table names from all databases with the same id
                unique_tables = list({db.metrics_table_name for db in dbs if db.metrics_table_name is not None})
                metrics_config.dbs.append(
                    DatabaseConfig(
                        db_id=db_id,
                        domain_config=MetricsDomainConfig(display_name=db_id),
                        tables=unique_tables,
                    )
                )

        return metrics_config

    def _get_evals_config(self) -> EvalsConfig:
        evals_config = self.config.evals if self.config and self.config.evals else EvalsConfig()

        if evals_config.dbs is None:
            evals_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in evals_config.dbs]

        for db_id, dbs in self.dbs.items():
            if db_id not in dbs_with_specific_config:
                # Collect unique table names from all databases with the same id
                unique_tables = list({db.eval_table_name for db in dbs if db.eval_table_name is not None})
                evals_config.dbs.append(
                    DatabaseConfig(
                        db_id=db_id,
                        domain_config=EvalsDomainConfig(display_name=db_id),
                        tables=unique_tables,
                    )
                )

        return evals_config

    def _get_traces_config(self) -> TracesConfig:
        traces_config = self.config.traces if self.config and self.config.traces else TracesConfig()

        if traces_config.dbs is None:
            traces_config.dbs = []

        dbs_with_specific_config = [db.db_id for db in traces_config.dbs]

        # If AgentOS db is explicitly set, only use that database for traces
        if self.db is not None:
            if self.db.id not in dbs_with_specific_config:
                traces_config.dbs.append(
                    DatabaseConfig(
                        db_id=self.db.id,
                        domain_config=TracesDomainConfig(display_name=self.db.id),
                    )
                )
        else:
            # Fall back to all discovered databases
            for db_id in self.dbs.keys():
                if db_id not in dbs_with_specific_config:
                    traces_config.dbs.append(
                        DatabaseConfig(
                            db_id=db_id,
                            domain_config=TracesDomainConfig(display_name=db_id),
                        )
                    )

        return traces_config

    def serve(
        self,
        app: Union[str, FastAPI],
        *,
        host: str = "localhost",
        port: int = 7777,
        reload: bool = False,
        reload_includes: Optional[List[str]] = None,
        reload_excludes: Optional[List[str]] = None,
        workers: Optional[int] = None,
        access_log: bool = False,
        **kwargs,
    ):
        import uvicorn

        host = getenv("AGENT_OS_HOST", host)
        env_port = getenv("AGENT_OS_PORT")
        if env_port is not None:
            port = int(env_port)

        if getenv("AGNO_API_RUNTIME", "").lower() == "stg":
            public_endpoint = "https://os-stg.agno.com/"
        else:
            public_endpoint = "https://os.agno.com/"

        # Create a terminal panel to announce OS initialization and provide useful info
        from rich.align import Align
        from rich.console import Console, Group

        panel_group = [
            Align.center(f"[bold cyan]{public_endpoint}[/bold cyan]"),
            Align.center(f"\n\n[bold dark_orange]OS running on:[/bold dark_orange] http://{host}:{port}"),
        ]
        if self.authorization:
            panel_group.append(
                Align.center("\n\n[bold chartreuse3]:lock: JWT Authorization Enabled[/bold chartreuse3]")
            )
        elif bool(self.settings.os_security_key):
            panel_group.append(Align.center("\n\n[bold chartreuse3]:lock: Security Key Enabled[/bold chartreuse3]"))

        console = Console()
        console.print(
            Panel(
                Group(*panel_group),
                title="AgentOS",
                expand=False,
                border_style="dark_orange",
                box=box.DOUBLE_EDGE,
                padding=(2, 2),
            )
        )

        # Adding *.yaml to reload_includes to reload the app when the yaml config file changes.
        if reload and reload_includes is not None:
            reload_includes = ["*.yaml", "*.yml"]

        uvicorn.run(
            app=app,
            host=host,
            port=port,
            reload=reload,
            reload_includes=reload_includes,
            reload_excludes=reload_excludes,
            workers=workers,
            access_log=access_log,
            lifespan="on",
            **kwargs,
        )
