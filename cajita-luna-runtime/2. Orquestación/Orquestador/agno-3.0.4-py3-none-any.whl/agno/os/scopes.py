"""AgentOS RBAC Scopes

This module defines all available permission scopes for AgentOS RBAC (Role-Based Access Control).

Scope Format:
- Global resource scopes: `resource:action`
- Per-resource scopes: `resource:<resource-id>:action`
- Wildcards: `resource:*:action` for any resource

The AgentOS ID is verified via the JWT `aud` (audience) claim.

Examples:
- `config:read` - Read OS configuration
- `agents:read` - List all agents
- `agents:web-agent:read` - Read specific agent
- `agents:web-agent:run` - Run specific agent
- `agents:*:run` - Run any agent (wildcard)
- `agent_os:admin` - Full access to everything

Backwards compatibility:
- Legacy ``system:*`` scopes are accepted as aliases for ``config:*`` so tokens
  issued before the rename continue to work. Prefer ``config:*`` in new tokens.
"""

import fnmatch
import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple

# Legacy resource name aliases — keep tokens issued before a rename working.
# Keys are the legacy resource names, values are the current names.
LEGACY_RESOURCE_ALIASES: Dict[str, str] = {
    "system": "config",
}


class AgentOSScope(str, Enum):
    """
    Enum of all available AgentOS permission scopes.

    Special Scopes:
    - ADMIN: Grants full access to all endpoints (agent_os:admin)

    Scope format:

    Global Resource Scopes:
    - config:read - OS configuration and model information (legacy alias: system:read)
    - config:write - Administrative writes such as database migrations (legacy alias: system:write)
    - registry:read - Read the code-defined registry (tools, models, databases, etc.)
    - agents:read - List all agents
    - teams:read - List all teams
    - workflows:read - List all workflows
    - sessions:read - View session data
    - sessions:write - Create and update sessions
    - sessions:delete - Delete sessions
    - memories:read - View memories
    - memories:write - Create and update memories
    - memories:delete - Delete memories
    - learnings:read - View learnings
    - learnings:write - Create and update learnings
    - learnings:delete - Delete learnings
    - knowledge:read - View and search knowledge
    - knowledge:write - Add and update knowledge
    - knowledge:delete - Delete knowledge
    - metrics:read - View metrics
    - metrics:write - Refresh metrics
    - evals:read - View evaluation runs
    - evals:write - Create and update evaluation runs
    - evals:delete - Delete evaluation runs
    - traces:read - View traces and trace statistics
    - service_accounts:read - List service accounts
    - service_accounts:write - Mint service account tokens
    - service_accounts:delete - Revoke service account tokens

    Per-Resource Scopes (with resource ID):
    - agents:<agent-id>:read - Read specific agent
    - agents:<agent-id>:run - Run specific agent
    - teams:<team-id>:read - Read specific team
    - teams:<team-id>:run - Run specific team
    - workflows:<workflow-id>:read - Read specific workflow
    - workflows:<workflow-id>:run - Run specific workflow

    Wildcards:
    - agents:*:run - Run any agent
    - teams:*:run - Run any team
    """

    # Special scopes
    ADMIN = "agent_os:admin"


@dataclass
class ParsedScope:
    """Represents a parsed scope with its components."""

    raw: str
    scope_type: str  # "admin", "global", "per_resource", or "unknown"
    resource: Optional[str] = None
    resource_id: Optional[str] = None
    action: Optional[str] = None
    is_wildcard_resource: bool = False

    @property
    def is_global_resource_scope(self) -> bool:
        """Check if this scope targets all resources of a type (no resource_id)."""
        return self.scope_type == "global"

    @property
    def is_per_resource_scope(self) -> bool:
        """Check if this scope targets a specific resource (has resource_id)."""
        return self.scope_type == "per_resource"


def parse_scope(scope: str, admin_scope: Optional[str] = None) -> ParsedScope:
    """
    Parse a scope string into its components.

    Args:
        scope: The scope string to parse
        admin_scope: The scope string that grants admin access (default: "agent_os:admin")

    Returns:
        ParsedScope object with parsed components

    Examples:
        >>> parse_scope("agent_os:admin")
        ParsedScope(raw="agent_os:admin", scope_type="admin")

        >>> parse_scope("system:read")
        ParsedScope(raw="system:read", scope_type="global", resource="system", action="read")

        >>> parse_scope("agents:web-agent:read")
        ParsedScope(raw="...", scope_type="per_resource", resource="agents", resource_id="web-agent", action="read")

        >>> parse_scope("agents:*:run")
        ParsedScope(raw="...", scope_type="per_resource", resource="agents", resource_id="*", action="run", is_wildcard_resource=True)
    """
    effective_admin_scope = admin_scope or AgentOSScope.ADMIN.value
    if scope == effective_admin_scope:
        return ParsedScope(raw=scope, scope_type="admin")

    parts = scope.split(":")

    # Global resource scope: resource:action (2 parts)
    if len(parts) == 2:
        resource = LEGACY_RESOURCE_ALIASES.get(parts[0], parts[0])
        return ParsedScope(
            raw=scope,
            scope_type="global",
            resource=resource,
            action=parts[1],
        )

    # Per-resource scope: resource:<resource-id>:action (3 parts)
    if len(parts) == 3:
        resource_id = parts[1]
        is_wildcard_resource = resource_id == "*"
        resource = LEGACY_RESOURCE_ALIASES.get(parts[0], parts[0])

        return ParsedScope(
            raw=scope,
            scope_type="per_resource",
            resource=resource,
            resource_id=resource_id,
            action=parts[2],
            is_wildcard_resource=is_wildcard_resource,
        )

    # Invalid format
    return ParsedScope(raw=scope, scope_type="unknown")


def split_scope(raw: str) -> Tuple[str, Optional[str], str]:
    """Split a scope string into its wire-format parts: (namespace, sub_namespace, permission).

    This is the parse behind the ``{raw, namespace, sub_namespace, permission}`` payload
    shape shared by every scope-bearing management API (service accounts, RBAC governance),
    so all surfaces render a scope identically for UIs. Legacy namespaces are mapped the
    same way :func:`parse_scope` maps them for enforcement (``system:read`` renders under
    ``config``), so the wire shape never misrepresents the effective permission; ``raw``
    keeps the original string.

        ``agents:read``    -> ("agents", None, "read")
        ``agents:*:run``   -> ("agents", "*", "run")
        ``system:read``    -> ("config", None, "read")
        ``agent_os:admin`` -> ("agent_os", None, "admin")
    """
    parts = raw.split(":")
    if len(parts) == 2:
        return LEGACY_RESOURCE_ALIASES.get(parts[0], parts[0]), None, parts[1]
    if len(parts) >= 3:
        return LEGACY_RESOURCE_ALIASES.get(parts[0], parts[0]), ":".join(parts[1:-1]), parts[-1]
    return (parts[0] if parts else "unknown"), None, "unknown"


def matches_scope(
    user_scope: ParsedScope,
    required_scope: ParsedScope,
    resource_id: Optional[str] = None,
) -> bool:
    """
    Check if a user's scope matches a required scope.

    Args:
        user_scope: The user's parsed scope
        required_scope: The required parsed scope
        resource_id: The specific resource ID being accessed

    Returns:
        True if the user's scope satisfies the required scope

    Examples:
        >>> user = parse_scope("system:read")
        >>> required = parse_scope("system:read")
        >>> matches_scope(user, required)
        True

        >>> user = parse_scope("agents:web-agent:run")
        >>> required = parse_scope("agents:<id>:run")
        >>> matches_scope(user, required, resource_id="web-agent")
        True

        >>> user = parse_scope("agents:*:run")
        >>> required = parse_scope("agents:<id>:run")
        >>> matches_scope(user, required, resource_id="web-agent")
        True
    """
    # Admin always matches
    if user_scope.scope_type == "admin":
        return True

    # Unknown scopes don't match anything
    if user_scope.scope_type == "unknown" or required_scope.scope_type == "unknown":
        return False

    # Resource type must match
    if user_scope.resource != required_scope.resource:
        return False

    # Action must match
    if user_scope.action != required_scope.action:
        return False

    # If required scope has a resource_id, check it
    if required_scope.resource_id:
        # User has wildcard resource access
        if user_scope.is_wildcard_resource:
            return True
        # User has global resource access (no resource_id in user scope)
        if not user_scope.resource_id:
            return True
        # User has specific resource access - must match
        return user_scope.resource_id == resource_id

    # Required scope is global (no resource_id), user scope matches if:
    # - User has global scope (no resource_id), OR
    # - User has wildcard resource scope
    return not user_scope.resource_id or user_scope.is_wildcard_resource


def has_required_scopes(
    user_scopes: List[str],
    required_scopes: List[str],
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
    admin_scope: Optional[str] = None,
) -> bool:
    """
    Check if user has all required scopes.

    Args:
        user_scopes: List of scope strings the user has
        required_scopes: List of scope strings required
        resource_type: Type of resource being accessed ("agents", "teams", "workflows")
        resource_id: Specific resource ID being accessed
        admin_scope: The scope string that grants admin access (default: "agent_os:admin")

    Returns:
        True if user has all required scopes

    Examples:
        >>> has_required_scopes(
        ...     ["agents:read"],
        ...     ["agents:read"],
        ... )
        True

        >>> has_required_scopes(
        ...     ["agents:web-agent:run"],
        ...     ["agents:run"],
        ...     resource_type="agents",
        ...     resource_id="web-agent"
        ... )
        True

        >>> has_required_scopes(
        ...     ["agents:*:run"],
        ...     ["agents:run"],
        ...     resource_type="agents",
        ...     resource_id="any-agent"
        ... )
        True
    """
    if not required_scopes:
        return True

    # Parse user scopes once
    parsed_user_scopes = [parse_scope(scope, admin_scope=admin_scope) for scope in user_scopes]

    # Check for admin scope
    if any(s.scope_type == "admin" for s in parsed_user_scopes):
        return True

    # Check each required scope
    for required_scope_str in required_scopes:
        parts = required_scope_str.split(":")
        if len(parts) == 2:
            resource, action = parts
            # Build the required scope based on context
            if resource_id and resource_type:
                # Per-resource scope required
                full_required_scope = f"{resource_type}:<resource-id>:{action}"
            else:
                # Global resource scope required
                full_required_scope = required_scope_str

            required = parse_scope(full_required_scope, admin_scope=admin_scope)
        else:
            required = parse_scope(required_scope_str, admin_scope=admin_scope)

        scope_matched = False
        for user_scope in parsed_user_scopes:
            if matches_scope(user_scope, required, resource_id=resource_id):
                scope_matched = True
                break

        if not scope_matched:
            return False

    return True


def get_accessible_resource_ids(
    user_scopes: List[str],
    resource_type: str,
    admin_scope: Optional[str] = None,
    action: Optional[str] = None,
) -> Set[str]:
    """
    Get the set of resource IDs the user has access to.

    Args:
        user_scopes: List of scope strings the user has
        resource_type: Type of resource ("agents", "teams", "workflows")
        admin_scope: The scope string that grants admin access (default: "agent_os:admin")
        action: If provided, only consider scopes matching this action (e.g. "run", "read").
                If None, considers scopes with any action (backwards compatible for list filtering).

    Returns:
        Set of resource IDs the user can access. Returns {"*"} for wildcard access.

    Examples:
        >>> get_accessible_resource_ids(
        ...     ["agents:agent-1:read", "agents:agent-2:read"],
        ...     "agents"
        ... )
        {'agent-1', 'agent-2'}

        >>> get_accessible_resource_ids(["agents:*:read"], "agents")
        {'*'}

        >>> get_accessible_resource_ids(["agents:read"], "agents")
        {'*'}

        >>> get_accessible_resource_ids(["admin"], "agents")
        {'*'}

        >>> get_accessible_resource_ids(
        ...     ["agents:agent-1:read"],
        ...     "agents",
        ...     action="run"
        ... )
        set()
    """
    # Actions to match — if action is specified, only match that; otherwise match read/run (legacy)
    allowed_actions = [action] if action else ["read", "run"]

    parsed_scopes = [parse_scope(scope, admin_scope=admin_scope) for scope in user_scopes]

    # Check for admin or global wildcard access
    for scope in parsed_scopes:
        if scope.scope_type == "admin":
            return {"*"}

        # Check if resource type matches
        if scope.resource == resource_type:
            # Global resource scope (no resource_id) grants access to all
            if not scope.resource_id and scope.action in allowed_actions:
                return {"*"}
            # Wildcard resource scope grants access to all
            if scope.is_wildcard_resource and scope.action in allowed_actions:
                return {"*"}

    # Collect specific resource IDs
    accessible_ids: Set[str] = set()
    for scope in parsed_scopes:
        # Check if resource type matches
        if scope.resource == resource_type:
            # Specific resource ID
            if scope.resource_id and not scope.is_wildcard_resource and scope.action in allowed_actions:
                accessible_ids.add(scope.resource_id)

    return accessible_ids


def get_default_scope_mappings() -> Dict[str, List[str]]:
    """
    Get default scope mappings for AgentOS endpoints.

    Returns a dictionary mapping route patterns (with HTTP methods) to required scope templates.
    Format: "METHOD /path/pattern": ["resource:action"]
    """
    mappings: Dict[str, List[str]] = {
        # Config endpoints (legacy scope: system:read)
        "GET /config": ["config:read"],
        "GET /models": ["config:read"],
        # Agent endpoints
        "GET /agents": ["agents:read"],
        "GET /agents/*": ["agents:read"],
        "POST /agents": ["agents:write"],
        "PATCH /agents/*": ["agents:write"],
        "DELETE /agents/*": ["agents:delete"],
        "POST /agents/*/runs": ["agents:run"],
        "POST /agents/*/runs/*/continue": ["agents:run"],
        "POST /agents/*/runs/*/cancel": ["agents:run"],
        # Team endpoints
        "GET /teams": ["teams:read"],
        "GET /teams/*": ["teams:read"],
        "POST /teams": ["teams:write"],
        "PATCH /teams/*": ["teams:write"],
        "DELETE /teams/*": ["teams:delete"],
        "POST /teams/*/runs": ["teams:run"],
        "POST /teams/*/runs/*/continue": ["teams:run"],
        "POST /teams/*/runs/*/cancel": ["teams:run"],
        # Workflow endpoints
        "GET /workflows": ["workflows:read"],
        "GET /workflows/*": ["workflows:read"],
        "POST /workflows": ["workflows:write"],
        "PATCH /workflows/*": ["workflows:write"],
        "DELETE /workflows/*": ["workflows:delete"],
        "POST /workflows/*/runs": ["workflows:run"],
        "POST /workflows/*/runs/*/continue": ["workflows:run"],
        "POST /workflows/*/runs/*/cancel": ["workflows:run"],
        # Session endpoints
        "GET /sessions": ["sessions:read"],
        "GET /sessions/*": ["sessions:read"],
        "POST /sessions": ["sessions:write"],
        "POST /sessions/*/rename": ["sessions:write"],
        "PATCH /sessions/*": ["sessions:write"],
        "DELETE /sessions": ["sessions:delete"],
        "DELETE /sessions/*": ["sessions:delete"],
        # Memory endpoints
        "GET /memories": ["memories:read"],
        "GET /memories/*": ["memories:read"],
        "GET /memory_topics": ["memories:read"],
        "GET /user_memory_stats": ["memories:read"],
        "POST /memories": ["memories:write"],
        "PATCH /memories/*": ["memories:write"],
        "DELETE /memories": ["memories:delete"],
        "DELETE /memories/*": ["memories:delete"],
        "POST /optimize-memories": ["memories:write"],
        # Learning endpoints
        "GET /learnings": ["learnings:read"],
        "GET /learnings/*": ["learnings:read"],
        "POST /learnings": ["learnings:write"],
        "PATCH /learnings/*": ["learnings:write"],
        "DELETE /learnings/*": ["learnings:delete"],
        # Knowledge endpoints
        "GET /knowledge/content": ["knowledge:read"],
        "GET /knowledge/content/*": ["knowledge:read"],
        "GET /knowledge/config": ["knowledge:read"],
        "POST /knowledge/content": ["knowledge:write"],
        "PATCH /knowledge/content/*": ["knowledge:write"],
        "POST /knowledge/search": ["knowledge:read"],
        "DELETE /knowledge/content": ["knowledge:delete"],
        "DELETE /knowledge/content/*": ["knowledge:delete"],
        # Metrics endpoints
        "GET /metrics": ["metrics:read"],
        "POST /metrics/refresh": ["metrics:write"],
        "GET /metrics/refresh/status": ["metrics:read"],
        # Evaluation endpoints
        "GET /eval-runs": ["evals:read"],
        "GET /eval-runs/*": ["evals:read"],
        "POST /eval-runs": ["evals:write"],
        "PATCH /eval-runs/*": ["evals:write"],
        "DELETE /eval-runs": ["evals:delete"],
        # Trace endpoints
        "GET /traces": ["traces:read"],
        "GET /traces/*": ["traces:read"],
        "GET /trace_session_stats": ["traces:read"],
        # Service account endpoints
        "POST /service-accounts": ["service_accounts:write"],
        "GET /service-accounts": ["service_accounts:read"],
        "DELETE /service-accounts/*": ["service_accounts:delete"],
        # Schedule endpoints
        "GET /schedules": ["schedules:read"],
        "GET /schedules/*": ["schedules:read"],
        "POST /schedules": ["schedules:write"],
        "PATCH /schedules/*": ["schedules:write"],
        "DELETE /schedules/*": ["schedules:delete"],
        "POST /schedules/*/enable": ["schedules:write"],
        "POST /schedules/*/disable": ["schedules:write"],
        "POST /schedules/*/trigger": ["schedules:write"],
        "GET /schedules/*/runs": ["schedules:read"],
        "GET /schedules/*/runs/*": ["schedules:read"],
        # Approval endpoints
        "GET /approvals": ["approvals:read"],
        "GET /approvals/count": ["approvals:read"],
        "GET /approvals/*": ["approvals:read"],
        "GET /approvals/*/status": ["approvals:read"],
        "POST /approvals/*/resolve": ["approvals:write"],
        "DELETE /approvals/*": ["approvals:delete"],
        # Trace search
        "POST /traces/search": ["traces:read"],
        # Database migration endpoints (admin-only operations, legacy scope: system:write)
        "POST /databases/all/migrate": ["config:write"],
        "POST /databases/*/migrate": ["config:write"],
        # Additional knowledge endpoints
        "POST /knowledge/remote-content": ["knowledge:write"],
        "GET /knowledge/*/sources": ["knowledge:read"],
        "GET /knowledge/*/sources/*/files": ["knowledge:read"],
        # Registry (read-only)
        "GET /registry": ["registry:read"],
        # Component endpoints (Studio)
        "GET /components": ["components:read"],
        "GET /components/*": ["components:read"],
        "POST /components": ["components:write"],
        "PATCH /components/*": ["components:write"],
        "DELETE /components/*": ["components:delete"],
        "POST /components/*/restore": ["components:delete"],
        "GET /components/*/configs": ["components:read"],
        "GET /components/*/configs/*": ["components:read"],
        "GET /components/*/configs/current": ["components:read"],
        "POST /components/*/configs": ["components:write"],
        "PATCH /components/*/configs/*": ["components:write"],
        "DELETE /components/*/configs/*": ["components:delete"],
        "POST /components/*/configs/*/set-current": ["components:write"],
    }
    return mappings


def get_required_scopes_for_route(scope_mappings: Dict[str, List[str]], method: str, path: str) -> List[str]:
    """
    Look up the required scopes for a method and path in a scope-mappings dict.

    Args:
        scope_mappings: Mapping of "METHOD /path/pattern" to required scope lists
        method: HTTP method (GET, POST, etc.)
        path: Request path

    Returns:
        List of required scopes. Empty list [] means no scopes required (allow access).
        Routes not present in scope_mappings also return [], allowing access.
    """
    route_key = f"{method} {path}"

    # First, try exact match
    if route_key in scope_mappings:
        return scope_mappings[route_key]

    # Then try pattern matching
    for pattern, scopes in scope_mappings.items():
        pattern_method, pattern_path = pattern.split(" ", 1)

        if pattern_method != method:
            continue

        # Convert pattern to fnmatch pattern (replace {param} with *)
        # This handles both /agents/* and /agents/{agent_id} style patterns
        normalized_pattern = pattern_path
        if "{" in normalized_pattern:
            normalized_pattern = re.sub(r"\{[^}]+\}", "*", normalized_pattern)

        if fnmatch.fnmatch(path, normalized_pattern):
            return scopes

    return []


def get_resource_context_from_path(path: str) -> Tuple[Optional[str], Optional[str]]:
    """Extract (resource_type, resource_id) from a path like /agents/my-agent/runs."""
    # Anchor to the first path segment to avoid misclassifying paths like
    # /knowledge/agents/sources as "agents" resources. Only /agents, /teams,
    # /workflows (and /a2a/{family}) own the resource type.
    type_match = re.match(r"^/(?:a2a/)?(agents|teams|workflows)(?:/|$)", path)
    if not type_match:
        return None, None

    resource_type = type_match.group(1)

    id_match = re.match(rf"^/(?:a2a/)?{resource_type}/([^/]+)", path)
    if id_match:
        return resource_type, id_match.group(1)

    return resource_type, None


@dataclass
class RouteScopeCheck:
    """Result of checking a caller's scopes against a route's requirements."""

    allowed: bool
    required_scopes: List[str]
    # Set only for listing endpoints where the caller lacks the global scope but may
    # hold per-resource scopes: the endpoint should filter results to these IDs
    # (possibly an empty set) instead of rejecting with 403.
    accessible_resource_ids: Optional[Set[str]] = None


def check_route_scopes(
    user_scopes: List[str],
    scope_mappings: Dict[str, List[str]],
    method: str,
    path: str,
    admin_scope: Optional[str] = None,
) -> RouteScopeCheck:
    """
    Check a caller's scopes against the scopes required for a route.

    This is the single RBAC decision used for every credential type (JWTs, the internal
    service token, and service account tokens). Listing endpoints get special handling:
    a caller without the global scope is still allowed through, with
    accessible_resource_ids populated so the endpoint returns a filtered (possibly
    empty) list instead of a 403.
    """
    required_scopes = get_required_scopes_for_route(scope_mappings, method, path)
    if not required_scopes:
        return RouteScopeCheck(allowed=True, required_scopes=required_scopes)

    resource_type, resource_id = get_resource_context_from_path(path)

    allowed = has_required_scopes(
        user_scopes,
        required_scopes,
        resource_type=resource_type,
        resource_id=resource_id,
        admin_scope=admin_scope,
    )

    accessible_resource_ids: Optional[Set[str]] = None
    first_required = required_scopes[0]
    required_family = first_required.split(":", 1)[0] if ":" in first_required else None
    if (
        not allowed
        and method == "GET"
        and not resource_id
        and resource_type
        # Only a genuine listing of THIS resource family gets the filtered-access
        # treatment. Requiring the required-scope family to equal resource_type stops a
        # route that requires a foreign scope (e.g. knowledge:read) from being waved
        # through just because its path was classified as agents/teams/workflows.
        and required_family == resource_type
    ):
        # GET listing endpoints always allow access but expose the accessible IDs for
        # filtering, so callers with only per-resource scopes get a filtered list
        # (including an empty one) instead of a 403. Restricted to GET so a non-GET
        # id-less route (e.g. POST /agents) is never silently allowed through. Pass
        # the action from the required scope (e.g. "read" for "agents:read") so the
        # cached IDs only include resources the caller is authorised for under it.
        required_action: Optional[str] = None
        if ":" in first_required:
            required_action = first_required.rsplit(":", 1)[1]
        accessible_resource_ids = get_accessible_resource_ids(
            user_scopes, resource_type, admin_scope=admin_scope, action=required_action
        )
        allowed = True

    return RouteScopeCheck(
        allowed=allowed,
        required_scopes=required_scopes,
        accessible_resource_ids=accessible_resource_ids,
    )


def get_scope_value(scope: AgentOSScope) -> str:
    """
    Get the string value of a scope.

    Args:
        scope: The AgentOSScope enum value

    Returns:
        The string value of the scope

    Example:
        >>> get_scope_value(AgentOSScope.ADMIN)
        'admin'
    """
    return scope.value


def get_all_scopes() -> list[str]:
    """
    Get a list of all available scope strings.

    Returns:
        List of all scope string values

    Example:
        >>> scopes = get_all_scopes()
        >>> 'admin' in scopes
        True
    """
    return [scope.value for scope in AgentOSScope]
