from dataclasses import dataclass
from os import getenv
from typing import Any, Dict, List, Optional, Type, Union

from pydantic import BaseModel

from agno.models.anthropic import Claude as AnthropicClaude
from agno.utils.log import log_debug, log_warning
from agno.utils.models.claude import format_tools_for_model, resolve_http_client, route_sampling_params_to_extra_body

try:
    from anthropic import AnthropicBedrock, AsyncAnthropicBedrock
except ImportError:
    raise ImportError("`anthropic[bedrock]` not installed. Please install using `pip install anthropic[bedrock]`")

try:
    from boto3.session import Session
except ImportError:
    raise ImportError("`boto3` not installed. Please install using `pip install boto3`")


@dataclass
class Claude(AnthropicClaude):
    """
    AWS Bedrock Claude model.

    For more information, see: https://docs.aws.amazon.com/bedrock/latest/userguide/model-parameters-anthropic.html
    """

    id: str = "global.anthropic.claude-sonnet-4-5-20250929-v1:0"
    name: str = "AwsBedrockAnthropicClaude"
    provider: str = "AwsBedrock"

    aws_access_key: Optional[str] = None
    aws_secret_key: Optional[str] = None
    aws_session_token: Optional[str] = None
    aws_region: Optional[str] = None
    api_key: Optional[str] = None
    session: Optional[Session] = None

    client: Optional[AnthropicBedrock] = None  # type: ignore
    async_client: Optional[AsyncAnthropicBedrock] = None  # type: ignore

    def __post_init__(self):
        """Validate model configuration after initialization"""
        super().__post_init__()
        # Overwrite output schema support for AWS Bedrock Claude
        self.supports_native_structured_outputs = False
        self.supports_json_schema_outputs = False

    def _get_client_params(self) -> Dict[str, Any]:
        if self.session:
            # Use get_frozen_credentials() for an atomic snapshot so that
            # a credential refresh between property reads cannot produce a
            # mismatched access-key / secret-key / token tuple.
            resolved = self.session.get_credentials()
            if resolved is None:
                raise ValueError(
                    "boto3 session has no credentials. Check your AWS configuration "
                    "(environment variables, config files, IAM role, etc.)."
                )
            credentials = resolved.get_frozen_credentials()
            client_params: Dict[str, Any] = {
                "aws_access_key": credentials.access_key,
                "aws_secret_key": credentials.secret_key,
                "aws_session_token": credentials.token,
                "aws_region": self.aws_region or self.session.region_name,
            }
        else:
            self.api_key = self.api_key or getenv("AWS_BEDROCK_API_KEY")
            if self.api_key:
                raise ValueError(
                    "AWS_BEDROCK_API_KEY authentication is not currently supported by AnthropicBedrock. "
                    "Use IAM credentials (AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY[/AWS_SESSION_TOKEN]) "
                    "or provide a boto3 session instead."
                )

            self.aws_access_key = self.aws_access_key or getenv("AWS_ACCESS_KEY_ID") or getenv("AWS_ACCESS_KEY")
            self.aws_secret_key = self.aws_secret_key or getenv("AWS_SECRET_ACCESS_KEY") or getenv("AWS_SECRET_KEY")
            self.aws_session_token = self.aws_session_token or getenv("AWS_SESSION_TOKEN")
            self.aws_region = self.aws_region or getenv("AWS_REGION")

            client_params = {
                "aws_secret_key": self.aws_secret_key,
                "aws_access_key": self.aws_access_key,
                "aws_session_token": self.aws_session_token,
                "aws_region": self.aws_region,
            }

            if not (self.aws_access_key and self.aws_secret_key):
                log_warning(
                    "AWS credentials not found. Please set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables or provide a boto3 session."
                )

        if self.timeout is not None:
            client_params["timeout"] = self.timeout

        if self.client_params:
            client_params.update(self.client_params)

        return client_params

    def get_client(self):
        """
        Get the Bedrock client.

        Returns:
            AnthropicBedrock: The Bedrock client.
        """
        # When using a boto3 session, always recreate the client so
        # session.get_credentials() can return rotated credentials
        # (IAM roles, EKS pod identity, instance profiles, STS).
        if not self.session and self.client is not None and not self.client.is_closed():
            return self.client

        client_params = self._get_client_params()

        http_client = resolve_http_client(self.http_client)
        if http_client is not None:
            client_params["http_client"] = http_client
        # When no custom http_client is provided, let the SDK use its own default client.
        # Each model instance gets its own connection, preventing HTTP/2 stream saturation
        # when multiple models (main agent, MemoryManager, etc.) run concurrently.

        # Close the previous client before creating a new one to avoid leaking
        # connection pools when session-based credential refresh forces recreation.
        if self.session and self.client is not None and not self.client.is_closed():
            self.client.close()

        # Use a local variable so concurrent callers on the same model
        # instance cannot overwrite each other's client via self.client.
        client = AnthropicBedrock(
            **client_params,  # type: ignore
        )
        if not self.session:
            self.client = client
        return client

    def get_async_client(self):
        """
        Get the Bedrock async client.

        Returns:
            AsyncAnthropicBedrock: The Bedrock async client.
        """
        # When using a boto3 session, always recreate the client so
        # session.get_credentials() can return rotated credentials.
        if not self.session and self.async_client is not None and not self.async_client.is_closed():
            return self.async_client

        client_params = self._get_client_params()

        http_client = resolve_http_client(self.http_client, is_async=True)
        if http_client is not None:
            client_params["http_client"] = http_client
        # When no custom http_client is provided, let the SDK use its own default client.
        # Each model instance gets its own connection, preventing HTTP/2 stream saturation
        # when multiple models (main agent, MemoryManager, etc.) run concurrently.

        # Close the previous client before creating a new one to avoid leaking
        # connection pools when session-based credential refresh forces recreation.
        if self.session and self.async_client is not None and not self.async_client.is_closed():
            self.async_client.close()

        # Use a local variable so concurrent callers on the same model
        # instance cannot overwrite each other's client via self.async_client.
        async_client = AsyncAnthropicBedrock(
            **client_params,  # type: ignore
        )
        if not self.session:
            self.async_client = async_client
        return async_client

    def get_request_params(
        self,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Generate keyword arguments for API requests.

        Returns:
            Dict[str, Any]: The keyword arguments for API requests.
        """
        # Validate thinking support if thinking is enabled
        if self.thinking:
            self._validate_thinking_support()

        _request_params: Dict[str, Any] = {}
        if self.max_tokens:
            _request_params["max_tokens"] = self.max_tokens
        if self.thinking:
            _request_params["thinking"] = self.thinking
        if self.output_config:
            _request_params["output_config"] = self.output_config
        if self.temperature is not None:
            _request_params["temperature"] = self.temperature
        if self.stop_sequences:
            _request_params["stop_sequences"] = self.stop_sequences
        if self.top_p is not None:
            _request_params["top_p"] = self.top_p
        if self.top_k is not None:
            _request_params["top_k"] = self.top_k
        if self.timeout:
            _request_params["timeout"] = self.timeout

        # Build betas list - include existing betas and add new one if needed
        betas_list = list(self.betas) if self.betas else []

        # Include betas if any are present
        if betas_list:
            _request_params["betas"] = betas_list

        if self.request_params:
            _request_params.update(self.request_params)

        route_sampling_params_to_extra_body(_request_params)

        if _request_params:
            log_debug(f"Calling {self.provider} with request parameters: {_request_params}", log_level=2)
        return _request_params

    def _prepare_request_kwargs(
        self,
        system_message: str,
        tools: Optional[List[Dict[str, Any]]] = None,
        response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
        messages: Optional[List[Any]] = None,
    ) -> Dict[str, Any]:
        """
        Prepare the request keyword arguments for the API call.

        Args:
            system_message (str): The concatenated system messages.
            tools: Optional list of tools
            response_format: Optional response format (Pydantic model or dict)
            messages: Optional list of Message objects for the conversation.

        Returns:
            Dict[str, Any]: The request keyword arguments.
        """
        # Pass response_format and tools to get_request_params for beta header handling
        request_kwargs = self.get_request_params(response_format=response_format, tools=tools).copy()
        system = self._build_system(system_message)
        if system:
            request_kwargs["system"] = system

        # Format tools (this will handle strict mode)
        if tools:
            request_kwargs["tools"] = format_tools_for_model(tools)

        self._apply_cache_tools(request_kwargs)

        if request_kwargs:
            log_debug(f"Calling {self.provider} with request parameters: {request_kwargs}", log_level=2)
        return request_kwargs
