import asyncio
from io import BytesIO
from pathlib import Path
from typing import List, Optional

from agno.knowledge.chunking.fixed import FixedSizeChunking
from agno.knowledge.chunking.strategy import ChunkingStrategy, ChunkingStrategyType
from agno.knowledge.document.base import Document
from agno.knowledge.reader.base import Reader
from agno.knowledge.reader.pdf_reader import PDFReader
from agno.knowledge.reader.text_reader import TextReader
from agno.knowledge.types import ContentType
from agno.utils.log import log_debug, log_error

try:
    from agno.aws.resource.s3.object import S3Object  # type: ignore
except (ModuleNotFoundError, ImportError):
    raise ImportError("`agno-aws` not installed. Please install using `pip install agno-aws`")

try:
    import textract  # noqa: F401
except ImportError:
    raise ImportError("`textract` not installed. Please install it via `pip install textract`.")

try:
    from pypdf import PdfReader as DocumentReader  # noqa: F401
except ImportError:
    raise ImportError("`pypdf` not installed. Please install it via `pip install pypdf`.")


class S3Reader(Reader):
    """Reader for S3 files"""

    def __init__(self, chunking_strategy: Optional[ChunkingStrategy] = None, **kwargs):
        if chunking_strategy is None:
            chunk_size = kwargs.get("chunk_size", 5000)
            chunking_strategy = FixedSizeChunking(chunk_size=chunk_size)
        super().__init__(chunking_strategy=chunking_strategy, **kwargs)

    @classmethod
    def get_supported_chunking_strategies(cls) -> List[ChunkingStrategyType]:
        """Get the list of supported chunking strategies for S3 readers."""
        return [
            ChunkingStrategyType.CODE_CHUNKER,
            ChunkingStrategyType.FIXED_SIZE_CHUNKER,
            ChunkingStrategyType.AGENTIC_CHUNKER,
            ChunkingStrategyType.DOCUMENT_CHUNKER,
            ChunkingStrategyType.RECURSIVE_CHUNKER,
            ChunkingStrategyType.SEMANTIC_CHUNKER,
        ]

    @classmethod
    def get_supported_content_types(cls) -> List[ContentType]:
        return [ContentType.FILE, ContentType.URL, ContentType.TEXT]

    def _inner_reader(self, reader_cls):
        """Build the inner reader, propagating this reader's chunking configuration"""
        return reader_cls(
            chunk=self.chunk,
            chunk_size=self.chunk_size,
            chunking_strategy=self.chunking_strategy,
        )

    def read(self, name: Optional[str], s3_object: S3Object) -> List[Document]:
        try:
            log_debug(f"Reading S3 file: {s3_object.uri}")

            doc_name = name or s3_object.name.split("/")[-1].split(".")[0].replace("/", "_").replace(" ", "_")

            # Read PDF files
            if s3_object.uri.endswith(".pdf"):
                object_resource = s3_object.get_resource()
                object_body = object_resource.get()["Body"]
                return self._inner_reader(PDFReader).read(pdf=BytesIO(object_body.read()), name=doc_name)

            # Read text files
            else:
                obj_name = s3_object.name.split("/")[-1]
                temporary_file = Path("storage").joinpath(obj_name)
                s3_object.download(temporary_file)
                documents = self._inner_reader(TextReader).read(file=temporary_file, name=doc_name)
                temporary_file.unlink()
                return documents

        except Exception as e:
            log_error(f"Error reading: {s3_object.uri}: {str(e)}")

        return []

    async def async_read(self, name: Optional[str], s3_object: S3Object) -> List[Document]:
        """Asynchronously read S3 files by running the synchronous read operation in a thread."""
        return await asyncio.to_thread(self.read, name, s3_object)
