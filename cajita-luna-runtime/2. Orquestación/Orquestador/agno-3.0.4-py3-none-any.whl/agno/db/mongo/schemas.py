"""MongoDB collection schemas and related utilities"""

from typing import Any, Dict, List

SESSION_COLLECTION_SCHEMA = [
    {"key": "session_id", "unique": True},
    {"key": "user_id"},
    {"key": "session_type"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "workflow_id"},
    {"key": "created_at"},
    {"key": "updated_at"},
]

RUNS_COLLECTION_SCHEMA = [
    {"key": "run_id", "unique": True},
    {"key": "session_id"},
    {"key": "run_type"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "workflow_id"},
    {"key": "user_id"},
    {"key": "parent_run_id"},
    {"key": "status"},
    {"key": "created_at"},
    {"key": "updated_at"},
    # Compound index: ordered fetch of runs per session
    {"key": [("session_id", 1), ("run_index", 1)]},
]

MEMORY_COLLECTION_SCHEMA = [
    {"key": "memory_id", "unique": True},
    {"key": "user_id"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "topics"},
    {"key": "input"},
    {"key": "feedback"},
    {"key": "created_at"},
    {"key": "updated_at"},
]

EVAL_COLLECTION_SCHEMA = [
    {"key": "run_id", "unique": True},
    {"key": "eval_type"},
    {"key": "eval_input"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "workflow_id"},
    {"key": "model_id"},
    {"key": "user_id"},
    {"key": "created_at"},
    {"key": "updated_at"},
]

KNOWLEDGE_COLLECTION_SCHEMA = [
    {"key": "id", "unique": True},
    {"key": "name"},
    {"key": "description"},
    {"key": "type"},
    {"key": "status"},
    {"key": "status_message"},
    {"key": "metadata"},
    {"key": "size"},
    {"key": "linked_to"},
    {"key": "access_count"},
    {"key": "created_at"},
    {"key": "updated_at"},
    {"key": "external_id"},
]

METRICS_COLLECTION_SCHEMA = [
    {"key": "id", "unique": True},
    {"key": "date"},
    {"key": "aggregation_period"},
    # Empty-string sentinel for "no owner", matching the SQL adapters where NULL would break
    # the unique key below; get_metrics maps it back to None
    {"key": "user_id"},
    {"key": "created_at"},
    {"key": "updated_at"},
    # user_id joined the unique key with per-user aggregation. Collections created before that
    # keep the old (date, aggregation_period) unique index, which index creation drops.
    {"key": [("user_id", 1), ("date", 1), ("aggregation_period", 1)], "unique": True},
]

TRACE_COLLECTION_SCHEMA = [
    {"key": "trace_id", "unique": True},
    {"key": "name"},
    {"key": "status"},
    {"key": "run_id"},
    {"key": "session_id"},
    {"key": "user_id"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "workflow_id"},
    {"key": "start_time"},
    {"key": "end_time"},
    {"key": "created_at"},
]

SPAN_COLLECTION_SCHEMA = [
    {"key": "span_id", "unique": True},
    {"key": "trace_id"},
    {"key": "parent_span_id"},
    {"key": "name"},
    {"key": "span_kind"},
    {"key": "status_code"},
    {"key": "start_time"},
    {"key": "end_time"},
    {"key": "created_at"},
]

LEARNINGS_COLLECTION_SCHEMA = [
    {"key": "learning_id", "unique": True},
    {"key": "learning_type"},
    {"key": "namespace"},
    {"key": "user_id"},
    {"key": "agent_id"},
    {"key": "team_id"},
    {"key": "workflow_id"},
    {"key": "session_id"},
    {"key": "entity_id"},
    {"key": "entity_type"},
    {"key": "created_at"},
    {"key": "updated_at"},
]

SCHEDULES_COLLECTION_SCHEMA = [
    {"key": "id", "unique": True},
    # Not unique on its own: name uniqueness is per owner, enforced by the router.
    {"key": "name"},
    {"key": "enabled"},
    {"key": "next_run_at"},
    {"key": "locked_by"},
    {"key": "locked_at"},
    {"key": "user_id"},
    # Control-plane marker and component target: nullable fields need no
    # migration in Mongo, only these lookup indexes.
    {"key": "managed_by"},
    {"key": "target_id"},
    {"key": "created_at"},
    {"key": "updated_at"},
    {"key": [("enabled", 1), ("next_run_at", 1)]},
    # Scoped list / claim queries filter on user_id first
    {"key": [("user_id", 1), ("enabled", 1), ("next_run_at", 1)]},
    # DB backstop for the router's check-then-insert race: names are unique per
    # owner. Unlike SQL, Mongo treats missing/null user_id as a single value, so
    # one compound unique index covers both owned and unowned buckets.
    {"key": [("user_id", 1), ("name", 1)], "unique": True, "name": "uq_user_name"},
]

SCHEDULE_RUNS_COLLECTION_SCHEMA = [
    {"key": "id", "unique": True},
    {"key": "schedule_id"},
    {"key": "status"},
    {"key": "triggered_at"},
    {"key": "completed_at"},
    # Denormalised from the parent schedule so run queries scope per user without a join
    {"key": "user_id"},
    {"key": "created_at"},
]


def get_collection_indexes(collection_type: str) -> List[Dict[str, Any]]:
    """Get the index definitions for a specific collection type."""
    index_definitions = {
        "sessions": SESSION_COLLECTION_SCHEMA,
        "runs": RUNS_COLLECTION_SCHEMA,
        "memories": MEMORY_COLLECTION_SCHEMA,
        "metrics": METRICS_COLLECTION_SCHEMA,
        "evals": EVAL_COLLECTION_SCHEMA,
        "knowledge": KNOWLEDGE_COLLECTION_SCHEMA,
        "traces": TRACE_COLLECTION_SCHEMA,
        "spans": SPAN_COLLECTION_SCHEMA,
        "learnings": LEARNINGS_COLLECTION_SCHEMA,
        "schedules": SCHEDULES_COLLECTION_SCHEMA,
        "schedule_runs": SCHEDULE_RUNS_COLLECTION_SCHEMA,
    }

    indexes = index_definitions.get(collection_type)
    if not indexes:
        raise ValueError(f"Unknown collection type: {collection_type}")

    return indexes  # type: ignore[return-value]
