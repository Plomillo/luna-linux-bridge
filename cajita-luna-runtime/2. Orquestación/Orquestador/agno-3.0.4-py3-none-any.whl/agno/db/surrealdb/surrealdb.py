import time
from datetime import date, datetime, timedelta, timezone
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Sequence, Tuple, Union

if TYPE_CHECKING:
    from agno.tracing.schemas import Span, Trace

from agno.db.base import BaseDb, SessionType
from agno.db.postgres.utils import (
    get_dates_to_calculate_metrics_for,
)
from agno.db.schemas import UserMemory
from agno.db.schemas.evals import EvalFilterType, EvalRunRecord, EvalType
from agno.db.schemas.knowledge import KnowledgeRow
from agno.db.surrealdb import utils
from agno.db.surrealdb.metrics import (
    bulk_upsert_metrics,
    calculate_date_metrics,
    desurrealize_metric,
    fetch_all_sessions_data,
    get_all_sessions_for_metrics_calculation,
    get_metrics_calculation_starting_date,
)
from agno.db.surrealdb.models import (
    TableType,
    deserialize_eval_run_record,
    deserialize_knowledge_row,
    deserialize_user_memories,
    deserialize_user_memory,
    desurrealize_eval_run_record,
    desurrealize_run_row,
    desurrealize_session,
    desurrealize_user_memory,
    get_schema,
    get_session_type,
    serialize_eval_run_record,
    serialize_knowledge_row,
    serialize_run_row,
    serialize_session,
    serialize_user_memory,
)
from agno.db.surrealdb.queries import COUNT_QUERY, WhereClause, order_limit_start
from agno.db.surrealdb.utils import build_client
from agno.db.utils import (
    HISTORY_SKIP_STATUSES,
    build_single_run_row,
    deserialize_run,
    deserialize_session,
    deserialize_sessions,
    drop_legacy_metrics,
    filter_context_runs,
    merge_runs_table_with_legacy_blob,
)
from agno.run.agent import RunOutput
from agno.run.base import RunStatus
from agno.run.team import TeamRunOutput
from agno.run.workflow import WorkflowRunOutput
from agno.session import Session
from agno.utils.log import log_debug, log_error, log_info
from agno.utils.string import generate_id

try:
    from surrealdb import BlockingHttpSurrealConnection, BlockingWsSurrealConnection, RecordID
except ImportError:
    raise ImportError("The `surrealdb` package is not installed. Please install it via `pip install surrealdb`.")


class SurrealDb(BaseDb):
    def __init__(
        self,
        client: Optional[Union[BlockingWsSurrealConnection, BlockingHttpSurrealConnection]],
        db_url: str,
        db_creds: dict[str, str],
        db_ns: str,
        db_db: str,
        session_table: Optional[str] = None,
        runs_table: Optional[str] = None,
        memory_table: Optional[str] = None,
        metrics_table: Optional[str] = None,
        eval_table: Optional[str] = None,
        knowledge_table: Optional[str] = None,
        traces_table: Optional[str] = None,
        spans_table: Optional[str] = None,
        id: Optional[str] = None,
    ):
        """
        Interface for interacting with a SurrealDB database.

        Args:
            client: A blocking connection, either HTTP or WS
            db_url: The URL of the SurrealDB database.
            db_creds: The credentials for the SurrealDB database.
            db_ns: The namespace for the SurrealDB database.
            db_db: The database name for the SurrealDB database.
            session_table: The name of the session table.
            memory_table: The name of the memory table.
            metrics_table: The name of the metrics table.
            eval_table: The name of the eval table.
            knowledge_table: The name of the knowledge table.
            traces_table: The name of the traces table.
            spans_table: The name of the spans table.
            id: The ID of the database.
        """
        if id is None:
            base_seed = db_url
            seed = f"{base_seed}#{db_db}"
            id = generate_id(seed)

        super().__init__(
            id=id,
            session_table=session_table,
            runs_table=runs_table,
            memory_table=memory_table,
            metrics_table=metrics_table,
            eval_table=eval_table,
            knowledge_table=knowledge_table,
            traces_table=traces_table,
            spans_table=spans_table,
        )
        self._client = client
        self._db_url = db_url
        self._db_creds = db_creds
        self._db_ns = db_ns
        self._db_db = db_db
        self._users_table_name: str = "agno_users"
        self._agents_table_name: str = "agno_agents"
        self._teams_table_name: str = "agno_teams"
        self._workflows_table_name: str = "agno_workflows"

    @property
    def client(self) -> Union[BlockingWsSurrealConnection, BlockingHttpSurrealConnection]:
        if self._client is None:
            self._client = build_client(self._db_url, self._db_creds, self._db_ns, self._db_db)
        return self._client

    @property
    def table_names(self) -> dict[TableType, str]:
        return {
            "agents": self._agents_table_name,
            "evals": self.eval_table_name,
            "knowledge": self.knowledge_table_name,
            "memories": self.memory_table_name,
            "runs": self.runs_table_name,
            "sessions": self.session_table_name,
            "spans": self.span_table_name,
            "teams": self._teams_table_name,
            "traces": self.trace_table_name,
            "users": self._users_table_name,
            "workflows": self._workflows_table_name,
        }

    def table_exists(self, table_name: str) -> bool:
        """Check if a table with the given name exists in the SurrealDB database.

        Args:
            table_name: Name of the table to check

        Returns:
            bool: True if the table exists in the database, False otherwise
        """
        response = self._query_one("INFO FOR DB", {}, dict)
        if response is None:
            raise Exception("Failed to retrieve database information")
        return table_name in response.get("tables", [])

    def _create_table(self, table_type: TableType, table_name: str):
        query = get_schema(table_type, table_name)
        self.client.query(query)

    def _get_table(self, table_type: TableType, create_table_if_not_found: bool = True):
        if table_type == "sessions":
            table_name = self.session_table_name
        elif table_type == "runs":
            table_name = self.runs_table_name
        elif table_type == "memories":
            table_name = self.memory_table_name
        elif table_type == "knowledge":
            table_name = self.knowledge_table_name
        elif table_type == "users":
            table_name = self._users_table_name
        elif table_type == "agents":
            table_name = self._agents_table_name
        elif table_type == "teams":
            table_name = self._teams_table_name
        elif table_type == "workflows":
            table_name = self._workflows_table_name
        elif table_type == "evals":
            table_name = self.eval_table_name
        elif table_type == "metrics":
            table_name = self.metrics_table_name
        elif table_type == "traces":
            table_name = self.trace_table_name
        elif table_type == "spans":
            # Ensure traces table exists before spans (for foreign key-like relationship)
            if create_table_if_not_found:
                self._get_table("traces", create_table_if_not_found=True)
            table_name = self.span_table_name
        else:
            raise NotImplementedError(f"Unknown table type: {table_type}")

        if create_table_if_not_found and not self.table_exists(table_name):
            self._create_table(table_type, table_name)

        return table_name

    def get_latest_schema_version(self, table_name: str = "") -> Optional[str]:
        """Get the schema version stamped for the given table.

        Defaults to "2.0.0" when nothing is stamped so the MigrationManager
        runs migrations instead of skipping the table.
        """
        result = self.client.query(
            "SELECT version FROM ONLY $record",
            {"record": RecordID(self.versions_table_name, table_name)},
        )
        if isinstance(result, dict) and result.get("version"):
            return str(result["version"])
        return "2.0.0"

    def upsert_schema_version(self, table_name: str = "", version: str = "") -> None:
        """Record the schema version stamp for the given table."""
        self.client.query(
            "UPSERT ONLY $record CONTENT $content",
            {
                "record": RecordID(self.versions_table_name, table_name),
                "content": {"table_name": table_name, "version": version, "updated_at": int(time.time())},
            },
        )

    def _query(
        self,
        query: str,
        vars: dict[str, Any],
        record_type: type[utils.RecordType],
    ) -> Sequence[utils.RecordType]:
        return utils.query(self.client, query, vars, record_type)

    def _query_one(
        self,
        query: str,
        vars: dict[str, Any],
        record_type: type[utils.RecordType],
    ) -> Optional[utils.RecordType]:
        return utils.query_one(self.client, query, vars, record_type)

    def _count(self, table: str, where_clause: str, where_vars: dict[str, Any], group_by: Optional[str] = None) -> int:
        total_count_query = COUNT_QUERY.format(
            table=table,
            where_clause=where_clause,
            group_clause="GROUP ALL" if group_by is None else f"GROUP BY {group_by}",
            group_fields="" if group_by is None else f", {group_by}",
        )
        count_result = self._query_one(total_count_query, where_vars, dict)
        total_count = count_result.get("count") if count_result else 0
        assert isinstance(total_count, int), f"Expected int, got {type(total_count)}"
        total_count = int(total_count)
        return total_count

    # --- Runs ---

    def _get_session_runs_data(self, session_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Return raw run_data dicts for a session, ordered by run_index then created_at.

        When ``limit`` is set, push the "most recent N context-relevant runs" filter
        down to the DB: drop member sub-runs (``parent_run_id`` set), drop terminal-skip
        statuses, order newest-first and take ``limit`` rows, then reverse back to
        chronological order. SurrealDB uses ``IS NONE`` for null checks (not ``IS NULL``),
        and the ``status IS NONE OR`` guard keeps runs with no status from being dropped
        by ``NOT IN $skip``.
        """
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return []
        if limit is not None:
            rows_raw = self._query(
                f"SELECT *, run_index ?? 0 AS _ri, created_at ?? 0 AS _ca FROM {runs_table} "
                "WHERE session_id = $sid "
                "AND parent_run_id IS NONE AND (status IS NONE OR status NOT IN $skip) "
                "ORDER BY _ri DESC, _ca DESC LIMIT $lim",
                {"sid": session_id, "skip": HISTORY_SKIP_STATUSES, "lim": limit},
                dict,
            )
            rows = [desurrealize_run_row(r) for r in rows_raw]
            run_data = [r["run_data"] for r in rows if "run_data" in r]
            run_data.reverse()
            return run_data
        rows_raw = self._query(
            f"SELECT *, run_index ?? 0 AS _ri, created_at ?? 0 AS _ca FROM {runs_table} "
            "WHERE session_id = $sid ORDER BY _ri ASC, _ca ASC",
            {"sid": session_id},
            dict,
        )
        rows = [desurrealize_run_row(r) for r in rows_raw]
        return [r["run_data"] for r in rows if "run_data" in r]

    def _get_sessions_runs_data(self, session_ids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        if not session_ids:
            return {}
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for sid in session_ids:
            grouped[sid] = self._get_session_runs_data(sid)
        return grouped

    def upsert_run(
        self,
        run: Union[RunOutput, TeamRunOutput, WorkflowRunOutput, Dict[str, Any]],
        session_id: str,
        user_id: Optional[str] = None,
        run_index: Optional[int] = None,
    ) -> None:
        """Upsert a single run row into the runs table (O(1) operation).

        Optimized for updating existing runs (e.g., status changes in HITL or
        background mode) without re-upserting all runs in the session.

        For new runs, ``run_index`` should be provided or will be read from
        ``run_data``. For updates to existing runs, ``run_index`` is preserved
        from the original insert.

        Args:
            run: The run object or dictionary to upsert.
            session_id: The session ID this run belongs to.
            user_id: Optional user ID to associate with the run.
            run_index: Optional run index for new runs.

        Raises:
            ValueError: If the run has no run_id.
            Exception: If an error occurs during upsert.
        """
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=True)
            if runs_table is None:
                return

            row = build_single_run_row(
                run=run,
                session_id=session_id,
                user_id=user_id,
                run_index=run_index,
            )

            # Preserve the original run_index if the record already exists
            existing = self._query_one(
                "SELECT * FROM ONLY $record",
                {"record": RecordID(runs_table, row["run_id"])},
                dict,
            )
            if existing is not None and "run_index" in existing:
                row["run_index"] = existing["run_index"]

            content = serialize_run_row(row, runs_table)
            self._query_one(
                "UPSERT ONLY $record CONTENT $content",
                {"record": RecordID(runs_table, row["run_id"]), "content": content},
                dict,
            )
        except Exception as e:
            log_error(f"Exception upserting run into runs table: {str(e)}")
            raise e

    def _delete_session_runs(self, session_id: str) -> int:
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return 0
        result = self.client.query(
            f"DELETE FROM {runs_table} WHERE session_id = $sid RETURN BEFORE",
            {"sid": session_id},
        )
        if isinstance(result, list):
            return len(result)
        return 0

    def cleanup_legacy_runs_field(self, force: bool = False) -> bool:
        """Unset the legacy ``runs`` field from session records."""
        try:
            sessions_table = self._get_table("sessions", create_table_if_not_found=False)
        except Exception:
            return False

        sessions_raw = self._query(f"SELECT * FROM {sessions_table}", {}, dict)
        if not sessions_raw:
            return False

        if not force:
            pending = sum(1 for s in sessions_raw if s.get("runs"))
            if pending > 0:
                raise RuntimeError(
                    f"Refusing to unset {sessions_table}.runs: {pending} session(s) still have "
                    "non-null `runs` content. Run MigrationManager(db).up() first, or pass force=True."
                )

        self.client.query(f"UPDATE {sessions_table} UNSET runs", {})
        log_info(f"Unset runs on session records in {sessions_table}")
        return True

    def get_run(
        self, run_id: str, deserialize: Optional[bool] = True
    ) -> Optional[Union[RunOutput, TeamRunOutput, WorkflowRunOutput, Dict[str, Any]]]:
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return None
        raw = self._query_one(
            "SELECT * FROM ONLY $record",
            {"record": RecordID(runs_table, run_id)},
            dict,
        )
        if raw is None:
            return None
        row = desurrealize_run_row(raw)
        if not deserialize:
            return row
        return deserialize_run(row.get("run_type"), row["run_data"])

    def get_runs(
        self,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
        status: Optional[RunStatus] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        deserialize: Optional[bool] = True,
    ) -> Union[List[Union[RunOutput, TeamRunOutput, WorkflowRunOutput]], Tuple[List[Dict[str, Any]], int]]:
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return [] if deserialize else ([], 0)

        where = WhereClause()
        if session_id is not None:
            where = where.and_("session_id", session_id)
        if user_id is not None:
            where = where.and_("user_id", user_id)
        if agent_id is not None:
            where = where.and_("agent_id", agent_id)
        if team_id is not None:
            where = where.and_("team_id", team_id)
        if workflow_id is not None:
            where = where.and_("workflow_id", workflow_id)
        if status is not None:
            status_value = status.value if isinstance(status, RunStatus) else status
            where = where.and_("status", status_value)

        where_clause, where_vars = where.build()
        total_count = self._count(runs_table, where_clause, where_vars)

        order_clause = order_limit_start(sort_by or "run_index", sort_order or "asc", limit, page)
        query = dedent(f"""
            SELECT *
            FROM {runs_table}
            {where_clause}
            {order_clause}
        """)
        rows_raw = self._query(query, where_vars, dict)
        rows = [desurrealize_run_row(r) for r in rows_raw]

        if not deserialize:
            return list(rows), total_count
        return [deserialize_run(r.get("run_type"), r["run_data"]) for r in rows]

    def _scrub_run_ids_from_legacy_blob(self, run_ids: List[str]) -> None:
        """Remove ``run_ids`` from every session record's legacy ``runs`` array.

        Partial-migration hygiene: SurrealDB v3 keeps the pre-migration ``runs``
        array on the session record as backup. Deleting from the runs table
        alone leaves that array intact, and the read path's
        ``merge_runs_table_with_legacy_blob`` resurrects the ghost.
        """
        if not run_ids:
            return
        try:
            sessions_table = self._get_table("sessions", create_table_if_not_found=False)
            self.client.query(
                f"UPDATE {sessions_table} SET runs = array::filter(runs, |$r| $r.run_id NOT IN $rids) "
                f"WHERE runs IS NOT NONE AND array::any(runs, |$r| $r.run_id IN $rids)",
                {"rids": list(run_ids)},
            )
        except Exception:
            # Best-effort; the primary delete already succeeded.
            pass

    def delete_run(self, run_id: str) -> bool:
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return False
        res = self.client.delete(RecordID(runs_table, run_id))
        self._scrub_run_ids_from_legacy_blob([run_id])
        return bool(res)

    def delete_runs(self, run_ids: List[str]) -> None:
        if not run_ids:
            return
        try:
            runs_table = self._get_table("runs", create_table_if_not_found=False)
        except Exception:
            return
        records = [RecordID(runs_table, rid) for rid in run_ids]
        params: Dict[str, Any] = {"records": records}
        self.client.query(
            f"DELETE FROM {runs_table} WHERE id IN $records",
            params,
        )
        self._scrub_run_ids_from_legacy_blob(run_ids)

    # --- Sessions ---
    def clear_sessions(self) -> None:
        """Delete all session rows from the database.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("sessions")
        _ = self.client.delete(table)

    def delete_session(self, session_id: str, user_id: Optional[str] = None) -> bool:
        table = self._get_table(table_type="sessions")
        if table is None:
            return False
        if user_id is not None:
            res = self.client.query(
                f"DELETE FROM {table} WHERE id = $record AND user_id = $user_id RETURN BEFORE",
                {"record": RecordID(table, session_id), "user_id": user_id},
            )
            deleted = isinstance(res, list) and len(res) > 0
        else:
            res = self.client.delete(RecordID(table, session_id))
            deleted = bool(res)
        if deleted:
            try:
                self._delete_session_runs(session_id)
            except Exception as e:
                log_error(f"Failed to cascade-delete runs for session {session_id}: {str(e)}")
        return deleted

    def delete_sessions(self, session_ids: list[str], user_id: Optional[str] = None) -> None:
        table = self._get_table(table_type="sessions")
        if table is None:
            return

        records = [RecordID(table, id) for id in session_ids]
        query = f"DELETE FROM {table} WHERE id IN $records"
        params: Dict[str, Any] = {"records": records}
        if user_id is not None:
            query += " AND user_id = $user_id"
            params["user_id"] = user_id
        self.client.query(query, params)
        # Cascade-delete runs for each session
        for sid in session_ids:
            try:
                self._delete_session_runs(sid)
            except Exception as e:
                log_error(f"Failed to cascade-delete runs for session {sid}: {str(e)}")

    def get_session(
        self,
        session_id: str,
        session_type: Optional[SessionType] = None,
        user_id: Optional[str] = None,
        deserialize: Optional[bool] = True,
        runs_limit: Optional[int] = None,
    ) -> Optional[Union[Session, Dict[str, Any]]]:
        r"""
        Read a session from the database.

        Args:
            session_id (str): ID of the session to read.
            session_type (Optional[SessionType]): Type of session to get. If None, the type is inferred.
            user_id (Optional[str]): User ID to filter by. Defaults to None.
            deserialize (Optional[bool]): Whether to deserialize the session. Defaults to True.

        Returns:
            Optional[Union[Session, Dict[str, Any]]]:
                - When deserialize=True: Session object
                - When deserialize=False: Session dictionary

        Raises:
            Exception: If an error occurs during retrieval.
        """
        sessions_table = self._get_table("sessions")
        record = RecordID(sessions_table, session_id)
        where = WhereClause()
        if user_id is not None:
            where = where.and_("user_id", user_id)

        where_clause, where_vars = where.build()
        query = dedent(f"""
            SELECT *
            FROM ONLY $record
            {where_clause}
        """)
        vars = {"record": record, **where_vars}
        raw = self._query_one(query, vars, dict)
        if raw is None:
            return None

        desurrealized = desurrealize_session(raw)

        # Attach runs from the runs table, merged with any legacy `runs` blob.
        try:
            legacy_runs = desurrealized.get("runs")
            if runs_limit is not None and not legacy_runs:
                # Fully migrated: push "most recent N" down to the DB (indexed).
                desurrealized["runs"] = self._get_session_runs_data(session_id, limit=runs_limit)
            else:
                # Full load + merge. Also the un-migrated fallback: the legacy blob
                # holds the whole history in one column, so "last N" can't be pushed
                # to SQL — load all, merge, then filter+slice to match the migrated path.
                runs_data = self._get_session_runs_data(session_id)
                merged = merge_runs_table_with_legacy_blob(runs_data, legacy_runs)
                if runs_limit is not None:
                    merged = filter_context_runs(merged)[-runs_limit:]
                desurrealized["runs"] = merged
        except Exception as e:
            log_error(f"Failed to load runs for session {session_id}: {str(e)}")

        if not deserialize:
            return desurrealized

        return deserialize_session(session_type, desurrealized)

    def get_sessions(
        self,
        session_type: Optional[SessionType] = None,
        user_id: Optional[str] = None,
        component_id: Optional[str] = None,
        session_name: Optional[str] = None,
        start_timestamp: Optional[int] = None,
        end_timestamp: Optional[int] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        deserialize: Optional[bool] = True,
    ) -> Union[List[Session], Tuple[List[Dict[str, Any]], int]]:
        r"""
        Get all sessions in the given table. Can filter by user_id and entity_id.

        Args:
            session_type (SessionType): The type of session to get.
            user_id (Optional[str]): The ID of the user to filter by.
            component_id (Optional[str]): The ID of the agent / team / workflow to filter by.
            session_name (Optional[str]): The name of the session to filter by.
            start_timestamp (Optional[int]): The start timestamp to filter by.
            end_timestamp (Optional[int]): The end timestamp to filter by.
            limit (Optional[int]): The maximum number of sessions to return. Defaults to None.
            page (Optional[int]): The page number to return. Defaults to None.
            sort_by (Optional[str]): The field to sort by. Defaults to None.
            sort_order (Optional[str]): The sort order. Defaults to None.
            deserialize (Optional[bool]): Whether to serialize the sessions. Defaults to True.

        Returns:
            Union[List[Session], Tuple[List[Dict], int]]:
                - When deserialize=True: List of Session objects
                - When deserialize=False: Tuple of (session dictionaries, total count)

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table = self._get_table("sessions")
        # users_table = self._get_table("users", False) # Not used, commenting out for now.
        agents_table = self._get_table("agents", False)
        teams_table = self._get_table("teams", False)
        workflows_table = self._get_table("workflows", False)

        # -- Filters
        where = WhereClause()

        # session_type — filter by which RecordID link is present
        if session_type == SessionType.AGENT:
            if where._conditions:
                where._conditions.append("AND")
            where._conditions.append("agent IS NOT NONE")
        elif session_type == SessionType.TEAM:
            if where._conditions:
                where._conditions.append("AND")
            where._conditions.append("team IS NOT NONE")
        elif session_type == SessionType.WORKFLOW:
            if where._conditions:
                where._conditions.append("AND")
            where._conditions.append("workflow IS NOT NONE")

        # user_id
        if user_id is not None:
            where = where.and_("user_id", user_id)

        # component_id
        if component_id is not None:
            if session_type == SessionType.AGENT:
                where = where.and_("agent", RecordID(agents_table, component_id))
            elif session_type == SessionType.TEAM:
                where = where.and_("team", RecordID(teams_table, component_id))
            elif session_type == SessionType.WORKFLOW:
                where = where.and_("workflow", RecordID(workflows_table, component_id))
            elif session_type is None:
                # Filter by component_id across all session type fields
                p_a = f"p{where._param_count}"
                where._params[p_a] = RecordID(agents_table, component_id)
                where._param_count += 1
                p_t = f"p{where._param_count}"
                where._params[p_t] = RecordID(teams_table, component_id)
                where._param_count += 1
                p_w = f"p{where._param_count}"
                where._params[p_w] = RecordID(workflows_table, component_id)
                where._param_count += 1
                or_cond = f"(agent = ${p_a} OR team = ${p_t} OR workflow = ${p_w})"
                if where._conditions:
                    where._conditions.append("AND")
                where._conditions.append(or_cond)

        # session_name
        if session_name is not None:
            where = where.and_("session_name", session_name, "~")

        # start_timestamp
        if start_timestamp is not None:
            where = where.and_("created_at", start_timestamp, ">=")

        # end_timestamp
        if end_timestamp is not None:
            where = where.and_("created_at", end_timestamp, "<=")

        where_clause, where_vars = where.build()

        # Total count
        total_count = self._count(table, where_clause, where_vars)

        # Query
        order_limit_start_clause = order_limit_start(sort_by, sort_order, limit, page)
        query = dedent(f"""
            SELECT *
            FROM {table}
            {where_clause}
            {order_limit_start_clause}
        """)
        sessions_raw = self._query(query, where_vars, dict)
        converted_sessions_raw = [desurrealize_session(session) for session in sessions_raw]

        # Attach runs from the runs table, merged with legacy blob
        if converted_sessions_raw:
            try:
                runs_by_session = self._get_sessions_runs_data(
                    [s["session_id"] for s in converted_sessions_raw if s.get("session_id")]
                )
                for s in converted_sessions_raw:
                    sid = s.get("session_id")
                    if sid:
                        s["runs"] = merge_runs_table_with_legacy_blob(runs_by_session.get(sid, []), s.get("runs"))
            except Exception as e:
                log_error(f"Failed to attach runs to sessions: {str(e)}")

        if not deserialize:
            return list(converted_sessions_raw), total_count

        return deserialize_sessions(session_type, converted_sessions_raw)

    def rename_session(
        self,
        session_id: str,
        session_type: Optional[SessionType],
        session_name: str,
        user_id: Optional[str] = None,
        deserialize: Optional[bool] = True,
    ) -> Optional[Union[Session, Dict[str, Any]]]:
        """
        Rename a session in the database.

        Args:
            session_id (str): The ID of the session to rename.
            session_type (Optional[SessionType]): The type of session to rename.
            session_name (str): The new name for the session.
            user_id (Optional[str]): User ID to filter by. Defaults to None.
            deserialize (Optional[bool]): Whether to deserialize the session. Defaults to True.

        Returns:
            Optional[Union[Session, Dict[str, Any]]]:
                - When deserialize=True: Session object
                - When deserialize=False: Session dictionary

        Raises:
            Exception: If an error occurs during renaming.
        """
        table = self._get_table("sessions")
        vars: Dict[str, Any] = {"record": RecordID(table, session_id), "name": session_name}

        # SurrealDB doesn't store session_type as a field — type is inferred from
        # agent/team/workflow RecordID references. Only filter by user_id here.
        if user_id is not None:
            vars["user_id"] = user_id
            result = self.client.query(
                f"UPDATE {table} SET session_name = $name WHERE id = $record AND user_id = $user_id",
                vars,
            )
            session_raw = (
                result[0] if isinstance(result, list) and len(result) > 0 and isinstance(result[0], dict) else None
            )
        else:
            session_raw = self._query_one("UPDATE ONLY $record SET session_name = $name", vars, dict)

        if session_raw is None:
            return None
        desurrealized = desurrealize_session(session_raw)
        # Attach runs from the runs table, merged with legacy blob
        try:
            runs_data = self._get_session_runs_data(session_id)
            desurrealized["runs"] = merge_runs_table_with_legacy_blob(runs_data, desurrealized.get("runs"))
        except Exception as e:
            log_error(f"Failed to load runs for renamed session {session_id}: {str(e)}")
        if not deserialize:
            return desurrealized
        return deserialize_session(session_type, desurrealized)

    def upsert_session(
        self, session: Session, deserialize: Optional[bool] = True
    ) -> Optional[Union[Session, Dict[str, Any]]]:
        """
        Insert or update a session in the database.

        Args:
            session (Session): The session data to upsert.
            deserialize (Optional[bool]): Whether to deserialize the session. Defaults to True.

        Returns:
            Optional[Union[Session, Dict[str, Any]]]:
                - When deserialize=True: Session object
                - When deserialize=False: Session dictionary

        Raises:
            Exception: If an error occurs during upsert.
        """
        session_type = get_session_type(session)
        table = self._get_table("sessions")

        existing = self.client.query(
            f"SELECT user_id, runs FROM {table} WHERE id = $record",
            {"record": RecordID(table, session.session_id)},
        )
        legacy_runs: Any = None
        if isinstance(existing, list) and len(existing) > 0:
            existing_row = existing[0] if isinstance(existing[0], dict) else {}
            existing_uid = existing_row.get("user_id")
            if existing_uid is not None and existing_uid != session.user_id:
                return None
            # Carry legacy `runs` blob forward: UPSERT CONTENT replaces the whole
            # record, and serialize_session(include_runs=False) omits `runs`, so
            # bare upsert would silently erase pre-v3 history that only lives in
            # the legacy blob (upgrade-without-migration data loss).
            legacy_runs = existing_row.get("runs")

        content = serialize_session(session, self.table_names, include_runs=False)
        if legacy_runs is not None:
            content["runs"] = legacy_runs

        session_raw = self._query_one(
            "UPSERT ONLY $record CONTENT $content",
            {
                "record": RecordID(table, session.session_id),
                "content": content,
            },
            dict,
        )
        if session_raw is None:
            return None

        # Runs are persisted separately via upsert_run by the caller (agent loop).
        desurrealized = desurrealize_session(session_raw)
        # Attach in-memory runs so the caller sees them on the returned session
        desurrealized["runs"] = [r.to_dict() if hasattr(r, "to_dict") else r for r in (session.runs or [])]

        if not deserialize:
            return desurrealized
        return deserialize_session(session_type, desurrealized)

    def upsert_sessions(
        self, sessions: List[Session], deserialize: Optional[bool] = True
    ) -> List[Union[Session, Dict[str, Any]]]:
        """
        Bulk insert or update multiple sessions.

        Args:
            sessions (List[Session]): The list of session data to upsert.
            deserialize (Optional[bool]): Whether to deserialize the sessions. Defaults to True.

        Returns:
            List[Union[Session, Dict[str, Any]]]: List of upserted sessions

        Raises:
            Exception: If an error occurs during bulk upsert.
        """
        if not sessions:
            return []
        session_type = get_session_type(sessions[0])
        table = self._get_table("sessions")
        sessions_raw: List[Dict[str, Any]] = []
        for session in sessions:
            # UPSERT does only work for one record at a time. Read the existing
            # `runs` blob first so we can carry it forward -- otherwise UPSERT
            # CONTENT would wipe any pre-v3 history on the row (see the
            # single-record upsert_session above for the full rationale).
            existing = self.client.query(
                f"SELECT runs FROM {table} WHERE id = $record",
                {"record": RecordID(table, session.session_id)},
            )
            legacy_runs: Any = None
            if isinstance(existing, list) and len(existing) > 0 and isinstance(existing[0], dict):
                legacy_runs = existing[0].get("runs")

            content = serialize_session(session, self.table_names, include_runs=False)
            if legacy_runs is not None:
                content["runs"] = legacy_runs

            session_raw = self._query_one(
                "UPSERT ONLY $record CONTENT $content",
                {
                    "record": RecordID(table, session.session_id),
                    "content": content,
                },
                dict,
            )
            if session_raw:
                sessions_raw.append(session_raw)
        if not deserialize:
            return list(sessions_raw)

        # wrapping with list because of:
        # Type "List[Session]" is not assignable to return type "List[Session | Dict[str, Any]]"
        # Consider switching from "list" to "Sequence" which is covariant
        desurrealized = [desurrealize_session(s) for s in sessions_raw]
        return list(deserialize_sessions(session_type, desurrealized))

    # --- Memory ---
    def clear_memories(self) -> None:
        """Delete all memories from the database.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("memories")
        _ = self.client.delete(table)

    def delete_user_memory(self, memory_id: str, user_id: Optional[str] = None) -> None:
        """Delete a user memory from the database.

        Args:
            memory_id (str): The ID of the memory to delete.
            user_id (Optional[str]): The ID of the user to filter by. Defaults to None.

        Returns:
            bool: True if deletion was successful, False otherwise.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("memories")
        mem_rec_id = RecordID(table, memory_id)
        if user_id is None:
            self.client.delete(mem_rec_id)
        else:
            user_rec_id = RecordID(self._get_table("users"), user_id)
            self.client.query(
                f"DELETE FROM {table} WHERE user = $user AND id = $memory",
                {"user": user_rec_id, "memory": mem_rec_id},
            )

    def delete_user_memories(self, memory_ids: List[str], user_id: Optional[str] = None) -> None:
        """Delete user memories from the database.

        Args:
            memory_ids (List[str]): The IDs of the memories to delete.
            user_id (Optional[str]): The ID of the user to filter by. Defaults to None.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("memories")
        records = [RecordID(table, memory_id) for memory_id in memory_ids]
        if user_id is None:
            _ = self.client.query(f"DELETE FROM {table} WHERE id IN $records", {"records": records})  # type: ignore[dict-item]
        else:
            user_rec_id = RecordID(self._get_table("users"), user_id)
            _ = self.client.query(
                f"DELETE FROM {table} WHERE id IN $records AND user = $user",
                {"records": records, "user": user_rec_id},  # type: ignore[dict-item]
            )

    def get_all_memory_topics(self, user_id: Optional[str] = None) -> List[str]:
        """Get all memory topics from the database.

        Args:
            user_id (Optional[str]): The ID of the user to filter by. Defaults to None.

        Returns:
            List[str]: List of memory topics.
        """
        table = self._get_table("memories")
        vars: dict[str, Any] = {}

        # Query
        if user_id is None:
            query = dedent(f"""
                RETURN (
                    SELECT
                        array::flatten(topics) as topics
                    FROM ONLY {table}
                    GROUP ALL
                ).topics.distinct();
            """)
        else:
            query = dedent(f"""
                RETURN (
                    SELECT
                        array::flatten(topics) as topics
                    FROM ONLY {table}
                    WHERE user = $user
                    GROUP ALL
                ).topics.distinct();
            """)
            vars["user"] = RecordID(self._get_table("users"), user_id)

        result = self._query(query, vars, str)
        return list(result)

    def get_user_memory(
        self, memory_id: str, deserialize: Optional[bool] = True, user_id: Optional[str] = None
    ) -> Optional[Union[UserMemory, Dict[str, Any]]]:
        """Get a memory from the database.

        Args:
            memory_id (str): The ID of the memory to get.
            deserialize (Optional[bool]): Whether to serialize the memory. Defaults to True.
            user_id (Optional[str]): The ID of the user to filter by. Defaults to None.

        Returns:
            Optional[Union[UserMemory, Dict[str, Any]]]:
                - When deserialize=True: UserMemory object
                - When deserialize=False: UserMemory dictionary

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table_name = self._get_table("memories")
        record = RecordID(table_name, memory_id)
        vars = {"record": record}

        if user_id is None:
            query = "SELECT * FROM ONLY $record"
        else:
            query = "SELECT * FROM ONLY $record WHERE user = $user"
            vars["user"] = RecordID(self._get_table("users"), user_id)

        result = self._query_one(query, vars, dict)
        if result is None or not deserialize:
            return result
        return deserialize_user_memory(result)

    def get_user_memories(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        topics: Optional[List[str]] = None,
        search_content: Optional[str] = None,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        deserialize: Optional[bool] = True,
    ) -> Union[List[UserMemory], Tuple[List[Dict[str, Any]], int]]:
        """Get all memories from the database as UserMemory objects.

        Args:
            user_id (Optional[str]): The ID of the user to filter by.
            agent_id (Optional[str]): The ID of the agent to filter by.
            team_id (Optional[str]): The ID of the team to filter by.
            topics (Optional[List[str]]): The topics to filter by.
            search_content (Optional[str]): The content to search for.
            limit (Optional[int]): The maximum number of memories to return.
            page (Optional[int]): The page number.
            sort_by (Optional[str]): The column to sort by.
            sort_order (Optional[str]): The order to sort by.
            deserialize (Optional[bool]): Whether to serialize the memories. Defaults to True.


        Returns:
            Union[List[UserMemory], Tuple[List[Dict[str, Any]], int]]:
                - When deserialize=True: List of UserMemory objects
                - When deserialize=False: Tuple of (memory dictionaries, total count)

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table = self._get_table("memories")
        where = WhereClause()
        if user_id is not None:
            rec_id = RecordID(self._get_table("users"), user_id)
            where.and_("user", rec_id)
        if agent_id is not None:
            rec_id = RecordID(self._get_table("agents"), agent_id)
            where.and_("agent", rec_id)
        if team_id is not None:
            rec_id = RecordID(self._get_table("teams"), team_id)
            where.and_("team", rec_id)
        if topics is not None:
            where.and_("topics", topics, "CONTAINSANY")
        if search_content is not None:
            where.and_("memory", search_content, "~")
        where_clause, where_vars = where.build()

        # Total count
        total_count = self._count(table, where_clause, where_vars)

        # Query
        order_limit_start_clause = order_limit_start(sort_by, sort_order, limit, page)
        query = dedent(f"""
            SELECT *
            FROM {table}
            {where_clause}
            {order_limit_start_clause}
        """)
        result = self._query(query, where_vars, dict)
        if deserialize:
            return deserialize_user_memories(result)
        return [desurrealize_user_memory(x) for x in result], total_count

    def get_user_memory_stats(
        self,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        user_id: Optional[str] = None,
    ) -> Tuple[List[Dict[str, Any]], int]:
        """Get user memories stats.

        Args:
            limit (Optional[int]): The maximum number of user stats to return.
            page (Optional[int]): The page number.
            user_id (Optional[str]): The ID of the user to filter by. Defaults to None.

        Returns:
            Tuple[List[Dict[str, Any]], int]: A list of dictionaries containing user stats and total count.

        Example:
        (
            [
                {
                    "user_id": "123",
                    "total_memories": 10,
                    "last_memory_updated_at": 1714560000,
                },
            ],
            total_count: 1,
        )
        """
        memories_table_name = self._get_table("memories")
        where = WhereClause()

        if user_id is None:
            where.and_("!!user", True, "=")  # this checks that user is not falsy
        else:
            where.and_("user", RecordID(self._get_table("users"), user_id), "=")

        where_clause, where_vars = where.build()
        # Group
        group_clause = "GROUP BY user"
        # Order
        order_limit_start_clause = order_limit_start("last_memory_updated_at", "DESC", limit, page)
        # Total count
        total_count = (
            self._query_one(f"(SELECT user FROM {memories_table_name} GROUP BY user).map(|$x| $x.user).len()", {}, int)
            or 0
        )
        # Query
        query = dedent(f"""
            SELECT
                user,
                count(id) AS total_memories,
                time::max(updated_at) AS last_memory_updated_at
            FROM {memories_table_name}
            {where_clause}
            {group_clause}
            {order_limit_start_clause}
        """)
        result = self._query(query, where_vars, dict)

        # deserialize dates and RecordIDs
        for row in result:
            row["user_id"] = row["user"].id
            del row["user"]
            row["last_memory_updated_at"] = row["last_memory_updated_at"].timestamp()
            row["last_memory_updated_at"] = int(row["last_memory_updated_at"])

        return list(result), total_count

    def upsert_user_memory(
        self, memory: UserMemory, deserialize: Optional[bool] = True
    ) -> Optional[Union[UserMemory, Dict[str, Any]]]:
        """Upsert a user memory in the database.

        Args:
            memory (UserMemory): The user memory to upsert.
            deserialize (Optional[bool]): Whether to serialize the memory. Defaults to True.

        Returns:
            Optional[Union[UserMemory, Dict[str, Any]]]:
                - When deserialize=True: UserMemory object
                - When deserialize=False: UserMemory dictionary

        Raises:
            Exception: If an error occurs during upsert.
        """
        table = self._get_table("memories")
        user_table = self._get_table("users")
        if memory.memory_id:
            record = RecordID(table, memory.memory_id)
            query = "UPSERT ONLY $record CONTENT $content"
            result = self._query_one(
                query, {"record": record, "content": serialize_user_memory(memory, table, user_table)}, dict
            )
        else:
            query = f"CREATE ONLY {table} CONTENT $content"
            result = self._query_one(query, {"content": serialize_user_memory(memory, table, user_table)}, dict)
        if result is None:
            return None
        elif not deserialize:
            return desurrealize_user_memory(result)
        return deserialize_user_memory(result)

    def upsert_memories(
        self, memories: List[UserMemory], deserialize: Optional[bool] = True
    ) -> List[Union[UserMemory, Dict[str, Any]]]:
        """
        Bulk insert or update multiple memories in the database for improved performance.

        Args:
            memories (List[UserMemory]): The list of memories to upsert.
            deserialize (Optional[bool]): Whether to deserialize the memories. Defaults to True.

        Returns:
            List[Union[UserMemory, Dict[str, Any]]]: List of upserted memories

        Raises:
            Exception: If an error occurs during bulk upsert.
        """
        if not memories:
            return []
        table = self._get_table("memories")
        user_table_name = self._get_table("users")
        raw: list[dict] = []
        for memory in memories:
            if memory.memory_id:
                # UPSERT does only work for one record at a time
                session_raw = self._query_one(
                    "UPSERT ONLY $record CONTENT $content",
                    {
                        "record": RecordID(table, memory.memory_id),
                        "content": serialize_user_memory(memory, table, user_table_name),
                    },
                    dict,
                )
            else:
                session_raw = self._query_one(
                    f"CREATE ONLY {table} CONTENT $content",
                    {"content": serialize_user_memory(memory, table, user_table_name)},
                    dict,
                )
            if session_raw is not None:
                raw.append(session_raw)
        if raw is None or not deserialize:
            return [desurrealize_user_memory(x) for x in raw]
        # wrapping with list because of:
        # Type "List[Session]" is not assignable to return type "List[Session | Dict[str, Any]]"
        # Consider switching from "list" to "Sequence" which is covariant
        return list(deserialize_user_memories(raw))

    # --- Metrics ---
    def get_metrics(
        self,
        starting_date: Optional[date] = None,
        ending_date: Optional[date] = None,
        user_id: Optional[str] = None,
    ) -> Tuple[List[Dict[str, Any]], Optional[int]]:
        """Get all metrics matching the given date range.

        Args:
            starting_date (Optional[date]): The starting date to filter metrics by.
            ending_date (Optional[date]): The ending date to filter metrics by.
            user_id (Optional[str]): If set, only return this user's bucket. Defaults to None (all
                buckets, including the unowned one).

        Returns:
            Tuple[List[dict], Optional[int]]: A tuple containing the metrics and the timestamp of the latest update.

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table = self._get_table("metrics")

        where = WhereClause()

        # starting_date - need to convert date to datetime for comparison
        if starting_date is not None:
            starting_datetime = datetime.combine(starting_date, datetime.min.time()).replace(tzinfo=timezone.utc)
            where = where.and_("date", starting_datetime, ">=")

        # ending_date - need to convert date to datetime for comparison
        if ending_date is not None:
            ending_datetime = datetime.combine(ending_date, datetime.min.time()).replace(tzinfo=timezone.utc)
            where = where.and_("date", ending_datetime, "<=")

        if user_id is not None:
            where = where.and_("user_id", user_id)

        where_clause, where_vars = where.build()

        # Query
        query = dedent(f"""
            SELECT *
            FROM {table}
            {where_clause}
            ORDER BY date ASC
        """)

        results = self._query(query, where_vars, dict)
        # Records written before ownership existed hold a whole day, and only an
        # unscoped read sees them: an owner filter excludes them already
        if user_id is None:
            results = drop_legacy_metrics(results)

        # Get the latest updated_at from all results
        latest_update = None
        if results:
            # Find the maximum updated_at timestamp
            latest_update = max(int(r["updated_at"].timestamp()) for r in results)

            return [desurrealize_metric(r) for r in results], latest_update

        return [], latest_update

    def calculate_metrics(self) -> Optional[List[Dict[str, Any]]]:  # More specific return type
        """Calculate metrics for all dates without complete metrics.

        Returns:
            Optional[List[Dict[str, Any]]]: The calculated metrics.

        Raises:
            Exception: If an error occurs during metrics calculation.
        """
        try:
            table = self._get_table("metrics")  # Removed create_table_if_not_found parameter

            starting_date = get_metrics_calculation_starting_date(self.client, table, self.get_sessions)

            if starting_date is None:
                log_info("No session data found. Won't calculate metrics.")
                return None

            dates_to_process = get_dates_to_calculate_metrics_for(starting_date)
            if not dates_to_process:
                log_info("Metrics already calculated for all relevant dates.")
                return None

            start_timestamp = datetime.combine(dates_to_process[0], datetime.min.time()).replace(tzinfo=timezone.utc)
            end_timestamp = datetime.combine(dates_to_process[-1] + timedelta(days=1), datetime.min.time()).replace(
                tzinfo=timezone.utc
            )

            sessions = get_all_sessions_for_metrics_calculation(
                self.client, self._get_table("sessions"), start_timestamp, end_timestamp
            )

            # Attach runs from the runs table, merged with legacy blob
            if sessions:
                try:
                    sids = [s["session_id"] for s in sessions if s.get("session_id")]
                    runs_by_session = self._get_sessions_runs_data(sids)
                    for s in sessions:
                        sid = s.get("session_id")
                        if sid:
                            s["runs"] = merge_runs_table_with_legacy_blob(runs_by_session.get(sid, []), s.get("runs"))
                except Exception as e:
                    log_error(f"Failed to attach runs to sessions for metrics: {str(e)}")

            all_sessions_data = fetch_all_sessions_data(
                sessions=sessions,  # Added parameter name for clarity
                dates_to_process=dates_to_process,
                start_timestamp=int(start_timestamp.timestamp()),  # This expects int
            )
            if not all_sessions_data:
                log_info("No new session data found. Won't calculate metrics.")
                return None

            metrics_records = []

            for date_to_process in dates_to_process:
                date_key = date_to_process.isoformat()
                sessions_for_date = all_sessions_data.get(date_key, {})

                # Skip dates with no sessions
                if not any(len(sessions) > 0 for sessions in sessions_for_date.values()):
                    continue

                # One record per user_id, plus the empty-string bucket for unowned sessions
                metrics_records.extend(calculate_date_metrics(date_to_process, sessions_for_date))

            results = []  # Initialize before the if block
            if metrics_records:
                results = [desurrealize_metric(r) for r in bulk_upsert_metrics(self.client, table, metrics_records)]

            log_debug("Updated metrics calculations")
            return results

        except Exception as e:
            log_error(f"Exception refreshing metrics: {str(e)}")
            raise e

    # --- Knowledge ---
    def clear_knowledge(self) -> None:
        """Delete all knowledge rows from the database.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("knowledge")
        _ = self.client.delete(table)

    # Unowned knowledge rows have no user_id field at all, so owner scoping tests ``user_id IS NONE``.

    def delete_knowledge_content(self, id: str, user_id: Optional[str] = None):
        """Delete a knowledge row from the database.

        Args:
            id (str): The ID of the knowledge row to delete.
            user_id (Optional[str]): If set, only delete the row if owned by this user. Unowned rows
                are shared content.
        """
        table = self._get_table("knowledge")
        if user_id is None:
            self.client.delete(RecordID(table, id))
            return
        res = self.client.query(
            f"DELETE FROM {table} WHERE id = $record AND user_id = $user_id RETURN BEFORE",
            {"record": RecordID(table, id), "user_id": user_id},
        )
        if not (isinstance(res, list) and len(res) > 0):
            log_debug(f"Skipping delete of knowledge content {id}: not owned by {user_id}")

    def get_knowledge_content(self, id: str, user_id: Optional[str] = None) -> Optional[KnowledgeRow]:
        """Get a knowledge row from the database.

        Args:
            id (str): The ID of the knowledge row to get.
            user_id (Optional[str]): If set, only return the row if owned by this user or unowned.

        Returns:
            Optional[KnowledgeRow]: The knowledge row, or None if it doesn't exist.
        """
        table = self._get_table("knowledge")
        record_id = RecordID(table, id)
        if user_id is None:
            raw = self._query_one("SELECT * FROM ONLY $record_id", {"record_id": record_id}, dict)
            return deserialize_knowledge_row(raw) if raw else None
        raw = self._query_one(
            "SELECT * FROM ONLY $record_id WHERE user_id = $user_id OR user_id IS NONE",
            {"record_id": record_id, "user_id": user_id},
            dict,
        )
        return deserialize_knowledge_row(raw) if raw else None

    def get_knowledge_contents(
        self,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        linked_to: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Tuple[List[KnowledgeRow], int]:
        """Get all knowledge contents from the database.

        Args:
            limit (Optional[int]): The maximum number of knowledge contents to return.
            page (Optional[int]): The page number.
            sort_by (Optional[str]): The column to sort by.
            sort_order (Optional[str]): The order to sort by.
            linked_to (Optional[str]): Filter by linked_to value (knowledge instance name).
            user_id (Optional[str]): If set, only return rows owned by this user or unowned.

        Returns:
            Tuple[List[KnowledgeRow], int]: The knowledge contents and total count.

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table = self._get_table("knowledge")
        where = WhereClause()

        # Apply linked_to filter if provided
        if linked_to is not None:
            where.and_("linked_to", linked_to)

        where_clause, where_vars = where.build()

        # WhereClause only chains AND, so the owner scope is appended raw
        if user_id is not None:
            scope_predicate = "(user_id = $user_id OR user_id IS NONE)"
            if where_clause:
                where_clause = f"{where_clause} AND {scope_predicate}"
            else:
                where_clause = f"WHERE {scope_predicate}"
            where_vars["user_id"] = user_id

        # Total count
        total_count = self._count(table, where_clause, where_vars)

        # Query
        order_limit_start_clause = order_limit_start(sort_by, sort_order, limit, page)
        query = dedent(f"""
            SELECT *
            FROM {table}
            {where_clause}
            {order_limit_start_clause}
        """)
        result = self._query(query, where_vars, dict)
        return [deserialize_knowledge_row(row) for row in result], total_count

    def upsert_knowledge_content(self, knowledge_row: KnowledgeRow) -> Optional[KnowledgeRow]:
        """Upsert knowledge content in the database.

        Args:
            knowledge_row (KnowledgeRow): The knowledge row to upsert.

        Returns:
            Optional[KnowledgeRow]: The upserted knowledge row, or None if the operation fails.
        """
        knowledge_table_name = self._get_table("knowledge")
        record = RecordID(knowledge_table_name, knowledge_row.id)

        # A scoped write must not overwrite a record it does not own
        if knowledge_row.user_id is not None:
            stored = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)
            if stored is not None and stored.get("user_id") != knowledge_row.user_id:
                raise ValueError(f"Knowledge content {knowledge_row.id} not found")

        query = "UPSERT ONLY $record CONTENT $content"
        result = self._query_one(
            query, {"record": record, "content": serialize_knowledge_row(knowledge_row, knowledge_table_name)}, dict
        )
        return deserialize_knowledge_row(result) if result else None

    # --- Evals ---
    def clear_evals(self) -> None:
        """Delete all eval rows from the database.

        Raises:
            Exception: If an error occurs during deletion.
        """
        table = self._get_table("evals")
        _ = self.client.delete(table)

    def create_eval_run(self, eval_run: EvalRunRecord) -> Optional[EvalRunRecord]:
        """Create an EvalRunRecord in the database.

        Args:
            eval_run (EvalRunRecord): The eval run to create.

        Returns:
            Optional[EvalRunRecord]: The created eval run, or None if the operation fails.

        Raises:
            Exception: If an error occurs during creation.
        """
        table = self._get_table("evals")
        rec_id = RecordID(table, eval_run.run_id)
        query = "CREATE ONLY $record CONTENT $content"
        result = self._query_one(
            query, {"record": rec_id, "content": serialize_eval_run_record(eval_run, self.table_names)}, dict
        )
        return deserialize_eval_run_record(result) if result else None

    def delete_eval_runs(self, eval_run_ids: List[str], user_id: Optional[str] = None) -> None:
        """Delete multiple eval runs from the database.

        Args:
            eval_run_ids (List[str]): List of eval run IDs to delete.
            user_id (Optional[str]): If set, only delete runs owned by this user.
        """
        table = self._get_table("evals")
        records = [RecordID(table, id) for id in eval_run_ids]
        query = f"DELETE FROM {table} WHERE id IN $records"
        bindings: Dict[str, Any] = {"records": records}
        if user_id is not None:
            query += " AND user_id = $user_id"
            bindings["user_id"] = user_id
        _ = self.client.query(query, bindings)  # type: ignore[dict-item]

    def get_eval_run(
        self, eval_run_id: str, deserialize: Optional[bool] = True, user_id: Optional[str] = None
    ) -> Optional[Union[EvalRunRecord, Dict[str, Any]]]:
        """Get an eval run from the database.

        Args:
            eval_run_id (str): The ID of the eval run to get.
            deserialize (Optional[bool]): Whether to serialize the eval run. Defaults to True.
            user_id (Optional[str]): If set, only return the run if owned by this user.

        Returns:
            Optional[Union[EvalRunRecord, Dict[str, Any]]]:
                - When deserialize=True: EvalRunRecord object
                - When deserialize=False: EvalRun dictionary

        Raises:
            Exception: If an error occurs during retrieval.
        """
        table = self._get_table("evals")
        record = RecordID(table, eval_run_id)
        result = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)
        if result is not None and user_id is not None and result.get("user_id") != user_id:
            return None
        if not result or not deserialize:
            return desurrealize_eval_run_record(result) if result is not None else None
        return deserialize_eval_run_record(result)

    def get_eval_runs(
        self,
        limit: Optional[int] = None,
        page: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
        model_id: Optional[str] = None,
        filter_type: Optional[EvalFilterType] = None,
        eval_type: Optional[List[EvalType]] = None,
        deserialize: Optional[bool] = True,
        user_id: Optional[str] = None,
    ) -> Union[List[EvalRunRecord], Tuple[List[Dict[str, Any]], int]]:
        """Get all eval runs from the database.

        Args:
            limit (Optional[int]): The maximum number of eval runs to return.
            page (Optional[int]): The page number to return.
            sort_by (Optional[str]): The field to sort by.
            sort_order (Optional[str]): The order to sort by.
            agent_id (Optional[str]): The ID of the agent to filter by.
            team_id (Optional[str]): The ID of the team to filter by.
            workflow_id (Optional[str]): The ID of the workflow to filter by.
            model_id (Optional[str]): The ID of the model to filter by.
            user_id (Optional[str]): If set, only return runs owned by this user.
            eval_type (Optional[List[EvalType]]): The type of eval to filter by.
            filter_type (Optional[EvalFilterType]): The type of filter to apply.
            deserialize (Optional[bool]): Whether to serialize the eval runs. Defaults to True.

        Returns:
            Union[List[EvalRunRecord], Tuple[List[Dict[str, Any]], int]]:
                - When deserialize=True: List of EvalRunRecord objects
                - When deserialize=False: List of eval run dictionaries and the total count

        Raises:
            Exception: If there is an error getting the eval runs.
        """
        table = self._get_table("evals")

        where = WhereClause()
        if user_id is not None:
            where.and_("user_id", user_id)
        if agent_id is not None:
            where.and_("agent", RecordID(self._get_table("agents"), agent_id))
        if team_id is not None:
            where.and_("team", RecordID(self._get_table("teams"), team_id))
        if workflow_id is not None:
            where.and_("workflow", RecordID(self._get_table("workflows"), workflow_id))
        if model_id is not None:
            where.and_("model_id", model_id)
        if eval_type is not None and len(eval_type) > 0:
            where.and_("eval_type", [et.value for et in eval_type], "IN")
        if filter_type is not None:
            if filter_type == EvalFilterType.AGENT:
                where.and_("agent", None, "!=")
            elif filter_type == EvalFilterType.TEAM:
                where.and_("team", None, "!=")
            elif filter_type == EvalFilterType.WORKFLOW:
                where.and_("workflow", None, "!=")
        where_clause, where_vars = where.build()

        # Order
        order_limit_start_clause = order_limit_start(sort_by, sort_order, limit, page)

        # Total count
        total_count = self._count(table, where_clause, where_vars)

        # Query
        query = dedent(f"""
            SELECT *
            FROM {table}
            {where_clause}
            {order_limit_start_clause}
        """)
        result = self._query(query, where_vars, dict)

        if not deserialize:
            return [desurrealize_eval_run_record(x) for x in result], total_count
        return [deserialize_eval_run_record(x) for x in result]

    def rename_eval_run(
        self, eval_run_id: str, name: str, deserialize: Optional[bool] = True, user_id: Optional[str] = None
    ) -> Optional[Union[EvalRunRecord, Dict[str, Any]]]:
        """Update the name of an eval run in the database.

        Args:
            eval_run_id (str): The ID of the eval run to update.
            name (str): The new name of the eval run.
            deserialize (Optional[bool]): Whether to serialize the eval run. Defaults to True.
            user_id (Optional[str]): If set, only rename the run if owned by this user.

        Returns:
            Optional[Union[EvalRunRecord, Dict[str, Any]]]:
                - When deserialize=True: EvalRunRecord object
                - When deserialize=False: EvalRun dictionary

        Raises:
            Exception: If there is an error updating the eval run.
        """
        table = self._get_table("evals")
        record = RecordID(table, eval_run_id)

        # Only rename if owned by this user.
        if user_id is not None:
            existing = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)
            if not existing or existing.get("user_id") != user_id:
                return None

        vars = {"record": record, "name": name}

        # Query
        query = dedent("""
            UPDATE ONLY $record
            SET name = $name
        """)
        raw = self._query_one(query, vars, dict)

        if not raw:
            return None
        if not deserialize:
            return desurrealize_eval_run_record(raw)
        return deserialize_eval_run_record(raw)

    def update_eval_run_user_id(self, eval_run_id: str, user_id: str) -> None:
        """Set the owner (user_id) on an existing eval run.

        Args:
            eval_run_id (str): The ID of the eval run to update.
            user_id (str): The owner to set.
        """
        table = self._get_table("evals")
        record = RecordID(table, eval_run_id)
        _ = self.client.query("UPDATE ONLY $record SET user_id = $user_id", {"record": record, "user_id": user_id})

    # --- Traces ---
    def upsert_trace(self, trace: "Trace") -> None:
        """Create or update a single trace record in the database.

        Args:
            trace: The Trace object to store (one per trace_id).
        """
        try:
            table = self._get_table("traces", create_table_if_not_found=True)
            record = RecordID(table, trace.trace_id)

            # Check if trace exists
            existing = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)

            if existing:
                # workflow (level 3) > team (level 2) > agent (level 1) > child/unknown (level 0)
                def get_component_level(workflow_id: Any, team_id: Any, agent_id: Any, name: str) -> int:
                    is_root_name = ".run" in name or ".arun" in name
                    if not is_root_name:
                        return 0
                    elif workflow_id:
                        return 3
                    elif team_id:
                        return 2
                    elif agent_id:
                        return 1
                    else:
                        return 0

                existing_level = get_component_level(
                    existing.get("workflow_id"),
                    existing.get("team_id"),
                    existing.get("agent_id"),
                    existing.get("name", ""),
                )
                new_level = get_component_level(trace.workflow_id, trace.team_id, trace.agent_id, trace.name)
                should_update_name = new_level > existing_level

                # Parse existing start_time to calculate correct duration
                existing_start_time = existing.get("start_time")
                if isinstance(existing_start_time, datetime):
                    recalculated_duration_ms = int((trace.end_time - existing_start_time).total_seconds() * 1000)
                else:
                    recalculated_duration_ms = trace.duration_ms

                # Build update query
                update_fields = [
                    "end_time = $end_time",
                    "duration_ms = $duration_ms",
                    "status = $status",
                ]
                update_vars: Dict[str, Any] = {
                    "record": record,
                    "end_time": trace.end_time,
                    "duration_ms": recalculated_duration_ms,
                    "status": trace.status,
                }

                if should_update_name:
                    update_fields.append("name = $name")
                    update_vars["name"] = trace.name

                # Preserve existing non-null context values: only fill in fields
                # that the existing row left blank. Otherwise a later upsert from
                # a child span (e.g. a post-hook agent's run with a different
                # session_id) would overwrite the trace's already-correct context.
                if existing.get("run_id") is None and trace.run_id is not None:
                    update_fields.append("run_id = $run_id")
                    update_vars["run_id"] = trace.run_id
                if existing.get("session_id") is None and trace.session_id is not None:
                    update_fields.append("session_id = $session_id")
                    update_vars["session_id"] = trace.session_id
                if existing.get("user_id") is None and trace.user_id is not None:
                    update_fields.append("user_id = $user_id")
                    update_vars["user_id"] = trace.user_id
                if existing.get("agent_id") is None and trace.agent_id is not None:
                    update_fields.append("agent_id = $agent_id")
                    update_vars["agent_id"] = trace.agent_id
                if existing.get("team_id") is None and trace.team_id is not None:
                    update_fields.append("team_id = $team_id")
                    update_vars["team_id"] = trace.team_id
                if existing.get("workflow_id") is None and trace.workflow_id is not None:
                    update_fields.append("workflow_id = $workflow_id")
                    update_vars["workflow_id"] = trace.workflow_id

                update_query = f"UPDATE ONLY $record SET {', '.join(update_fields)}"
                self._query_one(update_query, update_vars, dict)
            else:
                # Create new trace
                trace_dict = trace.to_dict()
                trace_dict.pop("total_spans", None)
                trace_dict.pop("error_count", None)

                # Convert datetime fields
                if isinstance(trace_dict.get("start_time"), str):
                    trace_dict["start_time"] = datetime.fromisoformat(trace_dict["start_time"].replace("Z", "+00:00"))
                if isinstance(trace_dict.get("end_time"), str):
                    trace_dict["end_time"] = datetime.fromisoformat(trace_dict["end_time"].replace("Z", "+00:00"))
                if isinstance(trace_dict.get("created_at"), str):
                    trace_dict["created_at"] = datetime.fromisoformat(trace_dict["created_at"].replace("Z", "+00:00"))

                self._query_one(
                    "CREATE ONLY $record CONTENT $content",
                    {"record": record, "content": trace_dict},
                    dict,
                )

        except Exception as e:
            log_error(f"Error creating trace: {str(e)}")

    def get_trace(
        self,
        trace_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ):
        """Get a single trace by trace_id or other filters.

        Args:
            trace_id: The unique trace identifier.
            run_id: Filter by run ID (returns first match).

        Returns:
            Optional[Trace]: The trace if found, None otherwise.

        Note:
            If multiple filters are provided, trace_id takes precedence.
            For other filters, the most recent trace is returned.
        """
        try:
            table = self._get_table("traces", create_table_if_not_found=False)
            spans_table = self._get_table("spans", create_table_if_not_found=False)

            if trace_id:
                record = RecordID(table, trace_id)
                trace_data = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)
            elif run_id:
                query = dedent(f"""
                    SELECT * FROM {table}
                    WHERE run_id = $run_id
                    ORDER BY start_time DESC
                    LIMIT 1
                """)
                trace_data = self._query_one(query, {"run_id": run_id}, dict)
            else:
                log_debug("get_trace called without any filter parameters")
                return None

            if not trace_data:
                return None

            # Calculate total_spans and error_count
            id_obj = trace_data.get("id")
            trace_id_val = trace_data.get("trace_id") or (id_obj.id if id_obj is not None else None)
            if trace_id_val:
                count_query = f"SELECT count() as total FROM {spans_table} WHERE trace_id = $trace_id GROUP ALL"
                count_result = self._query_one(count_query, {"trace_id": trace_id_val}, dict)
                trace_data["total_spans"] = count_result.get("total", 0) if count_result else 0

                error_query = f"SELECT count() as total FROM {spans_table} WHERE trace_id = $trace_id AND status_code = 'ERROR' GROUP ALL"
                error_result = self._query_one(error_query, {"trace_id": trace_id_val}, dict)
                trace_data["error_count"] = error_result.get("total", 0) if error_result else 0

            # Deserialize
            return self._deserialize_trace(trace_data)

        except Exception as e:
            log_error(f"Error getting trace: {str(e)}")
            return None

    def get_traces(
        self,
        run_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
        status: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = 20,
        page: Optional[int] = 1,
    ) -> tuple[List, int]:
        """Get traces matching the provided filters with pagination.

        Args:
            run_id: Filter by run ID.
            session_id: Filter by session ID.
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            team_id: Filter by team ID.
            workflow_id: Filter by workflow ID.
            status: Filter by status (OK, ERROR, UNSET).
            start_time: Filter traces starting after this datetime.
            end_time: Filter traces ending before this datetime.
            limit: Maximum number of traces to return per page.
            page: Page number (1-indexed).

        Returns:
            tuple[List[Trace], int]: Tuple of (list of matching traces, total count).
        """
        try:
            table = self._get_table("traces", create_table_if_not_found=False)
            spans_table = self._get_table("spans", create_table_if_not_found=False)

            # Build where clause
            where = WhereClause()
            if run_id:
                where.and_("run_id", run_id)
            if session_id:
                where.and_("session_id", session_id)
            if user_id is not None:
                where.and_("user_id", user_id)
            if agent_id:
                where.and_("agent_id", agent_id)
            if team_id:
                where.and_("team_id", team_id)
            if workflow_id:
                where.and_("workflow_id", workflow_id)
            if status:
                where.and_("status", status)
            if start_time:
                where.and_("start_time", start_time, ">=")
            if end_time:
                where.and_("end_time", end_time, "<=")

            where_clause, where_vars = where.build()

            # Total count
            total_count = self._count(table, where_clause, where_vars)

            # Query with pagination
            order_limit_start_clause = order_limit_start("start_time", "DESC", limit, page)
            query = dedent(f"""
                SELECT * FROM {table}
                {where_clause}
                {order_limit_start_clause}
            """)
            traces_raw = self._query(query, where_vars, dict)

            # Add total_spans and error_count to each trace
            result_traces = []
            for trace_data in traces_raw:
                id_obj = trace_data.get("id")
                trace_id_val = trace_data.get("trace_id") or (id_obj.id if id_obj is not None else None)
                if trace_id_val:
                    count_query = f"SELECT count() as total FROM {spans_table} WHERE trace_id = $trace_id GROUP ALL"
                    count_result = self._query_one(count_query, {"trace_id": trace_id_val}, dict)
                    trace_data["total_spans"] = count_result.get("total", 0) if count_result else 0

                    error_query = f"SELECT count() as total FROM {spans_table} WHERE trace_id = $trace_id AND status_code = 'ERROR' GROUP ALL"
                    error_result = self._query_one(error_query, {"trace_id": trace_id_val}, dict)
                    trace_data["error_count"] = error_result.get("total", 0) if error_result else 0

                result_traces.append(self._deserialize_trace(trace_data))

            return result_traces, total_count

        except Exception as e:
            log_error(f"Error getting traces: {str(e)}")
            return [], 0

    def get_trace_stats(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: Optional[int] = 20,
        page: Optional[int] = 1,
        group_by: Literal["session", "agent", "team", "workflow", "endpoint"] = "session",
    ) -> tuple[List[Dict[str, Any]], int]:
        """Get trace statistics grouped by session.

        Args:
            user_id: Filter by user ID.
            agent_id: Filter by agent ID.
            team_id: Filter by team ID.
            workflow_id: Filter by workflow ID.
            start_time: Filter sessions with traces created after this datetime.
            end_time: Filter sessions with traces created before this datetime.
            limit: Maximum number of sessions to return per page.
            page: Page number (1-indexed).
            group_by: Only the default "session" grouping is supported by this backend.

        Returns:
            tuple[List[Dict], int]: Tuple of (list of session stats dicts, total count).
                Each dict contains: session_id, user_id, agent_id, team_id, workflow_id, total_traces,
                first_trace_at, last_trace_at.
        """
        if group_by != "session":
            raise NotImplementedError(
                f"get_trace_stats with group_by={group_by!r} is not supported by {self.__class__.__name__}. "
                "Only the default 'session' grouping is available."
            )

        try:
            table = self._get_table("traces", create_table_if_not_found=False)

            # Build where clause
            where = WhereClause()
            where.and_("!!session_id", True, "=")  # Ensure session_id is not null
            if user_id is not None:
                where.and_("user_id", user_id)
            if agent_id:
                where.and_("agent_id", agent_id)
            if team_id:
                where.and_("team_id", team_id)
            if workflow_id:
                where.and_("workflow_id", workflow_id)
            if start_time:
                where.and_("created_at", start_time, ">=")
            if end_time:
                where.and_("created_at", end_time, "<=")

            where_clause, where_vars = where.build()

            # Get total count of unique sessions
            count_query = dedent(f"""
                SELECT count() as total FROM (
                    SELECT session_id FROM {table}
                    {where_clause}
                    GROUP BY session_id
                ) GROUP ALL
            """)
            count_result = self._query_one(count_query, where_vars, dict)
            total_count = count_result.get("total", 0) if count_result else 0

            # Query with aggregation
            order_limit_start_clause = order_limit_start("last_trace_at", "DESC", limit, page)
            query = dedent(f"""
                SELECT
                    session_id,
                    array::first(user_id) AS user_id,
                    array::first(agent_id) AS agent_id,
                    array::first(team_id) AS team_id,
                    array::first(workflow_id) AS workflow_id,
                    count() AS total_traces,
                    time::min(created_at) AS first_trace_at,
                    time::max(created_at) AS last_trace_at
                FROM {table}
                {where_clause}
                GROUP BY session_id
                {order_limit_start_clause}
            """)
            results = self._query(query, where_vars, dict)

            # Convert datetime objects
            stats_list = []
            for row in results:
                stat = dict(row)
                if isinstance(stat.get("first_trace_at"), datetime):
                    pass  # Keep as datetime
                if isinstance(stat.get("last_trace_at"), datetime):
                    pass  # Keep as datetime
                stats_list.append(stat)

            return stats_list, total_count

        except Exception as e:
            log_error(f"Error getting trace stats: {str(e)}")
            return [], 0

    def _deserialize_trace(self, trace_data: dict) -> "Trace":
        """Helper to deserialize a trace record from SurrealDB."""
        from agno.tracing.schemas import Trace

        # Handle RecordID for id field
        if isinstance(trace_data.get("id"), RecordID):
            if "trace_id" not in trace_data or not trace_data["trace_id"]:
                trace_data["trace_id"] = trace_data["id"].id
            del trace_data["id"]

        # Convert datetime to ISO string for Trace.from_dict
        for field in ["start_time", "end_time", "created_at"]:
            if isinstance(trace_data.get(field), datetime):
                trace_data[field] = trace_data[field].isoformat()

        return Trace.from_dict(trace_data)

    # --- Spans ---
    def create_span(self, span: "Span") -> None:
        """Create a single span in the database.

        Args:
            span: The Span object to store.
        """
        try:
            table = self._get_table("spans", create_table_if_not_found=True)
            record = RecordID(table, span.span_id)

            span_dict = span.to_dict()

            # Convert datetime fields
            if isinstance(span_dict.get("start_time"), str):
                span_dict["start_time"] = datetime.fromisoformat(span_dict["start_time"].replace("Z", "+00:00"))
            if isinstance(span_dict.get("end_time"), str):
                span_dict["end_time"] = datetime.fromisoformat(span_dict["end_time"].replace("Z", "+00:00"))
            if isinstance(span_dict.get("created_at"), str):
                span_dict["created_at"] = datetime.fromisoformat(span_dict["created_at"].replace("Z", "+00:00"))

            self._query_one(
                "CREATE ONLY $record CONTENT $content",
                {"record": record, "content": span_dict},
                dict,
            )

        except Exception as e:
            log_error(f"Error creating span: {str(e)}")

    def create_spans(self, spans: List) -> None:
        """Create multiple spans in the database as a batch.

        Args:
            spans: List of Span objects to store.
        """
        if not spans:
            return

        try:
            table = self._get_table("spans", create_table_if_not_found=True)

            for span in spans:
                record = RecordID(table, span.span_id)
                span_dict = span.to_dict()

                # Convert datetime fields
                if isinstance(span_dict.get("start_time"), str):
                    span_dict["start_time"] = datetime.fromisoformat(span_dict["start_time"].replace("Z", "+00:00"))
                if isinstance(span_dict.get("end_time"), str):
                    span_dict["end_time"] = datetime.fromisoformat(span_dict["end_time"].replace("Z", "+00:00"))
                if isinstance(span_dict.get("created_at"), str):
                    span_dict["created_at"] = datetime.fromisoformat(span_dict["created_at"].replace("Z", "+00:00"))

                self._query_one(
                    "CREATE ONLY $record CONTENT $content",
                    {"record": record, "content": span_dict},
                    dict,
                )

        except Exception as e:
            log_error(f"Error creating spans batch: {str(e)}")

    def get_span(self, span_id: str):
        """Get a single span by its span_id.

        Args:
            span_id: The unique span identifier.

        Returns:
            Optional[Span]: The span if found, None otherwise.
        """
        try:
            table = self._get_table("spans", create_table_if_not_found=False)
            record = RecordID(table, span_id)

            span_data = self._query_one("SELECT * FROM ONLY $record", {"record": record}, dict)
            if not span_data:
                return None

            return self._deserialize_span(span_data)

        except Exception as e:
            log_error(f"Error getting span: {str(e)}")
            return None

    def get_spans(
        self,
        trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        limit: Optional[int] = 1000,
    ) -> List:
        """Get spans matching the provided filters.

        Args:
            trace_id: Filter by trace ID.
            parent_span_id: Filter by parent span ID.
            limit: Maximum number of spans to return.

        Returns:
            List[Span]: List of matching spans.
        """
        try:
            table = self._get_table("spans", create_table_if_not_found=False)

            # Build where clause
            where = WhereClause()
            if trace_id:
                where.and_("trace_id", trace_id)
            if parent_span_id:
                where.and_("parent_span_id", parent_span_id)

            where_clause, where_vars = where.build()

            # Query
            limit_clause = f"LIMIT {limit}" if limit else ""
            query = dedent(f"""
                SELECT * FROM {table}
                {where_clause}
                ORDER BY start_time ASC
                {limit_clause}
            """)
            spans_raw = self._query(query, where_vars, dict)

            return [self._deserialize_span(s) for s in spans_raw]

        except Exception as e:
            log_error(f"Error getting spans: {str(e)}")
            return []

    def _deserialize_span(self, span_data: dict) -> "Span":
        """Helper to deserialize a span record from SurrealDB."""
        from agno.tracing.schemas import Span

        # Handle RecordID for id field
        if isinstance(span_data.get("id"), RecordID):
            if "span_id" not in span_data or not span_data["span_id"]:
                span_data["span_id"] = span_data["id"].id
            del span_data["id"]

        # Convert datetime to ISO string for Span.from_dict
        for field in ["start_time", "end_time", "created_at"]:
            if isinstance(span_data.get(field), datetime):
                span_data[field] = span_data[field].isoformat()

        return Span.from_dict(span_data)

    # -- Learning methods (stubs) --
    def get_learning(
        self,
        learning_type: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        session_id: Optional[str] = None,
        namespace: Optional[str] = None,
        entity_id: Optional[str] = None,
        entity_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        raise NotImplementedError("Learning methods not yet implemented for SurrealDb")

    def upsert_learning(
        self,
        id: str,
        learning_type: str,
        content: Dict[str, Any],
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        session_id: Optional[str] = None,
        namespace: Optional[str] = None,
        entity_id: Optional[str] = None,
        entity_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        raise NotImplementedError("Learning methods not yet implemented for SurrealDb")

    def delete_learning(self, id: str) -> bool:
        raise NotImplementedError("Learning methods not yet implemented for SurrealDb")

    def get_learnings(
        self,
        learning_type: Optional[str] = None,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        team_id: Optional[str] = None,
        session_id: Optional[str] = None,
        namespace: Optional[str] = None,
        entity_id: Optional[str] = None,
        entity_type: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError("Learning methods not yet implemented for SurrealDb")
