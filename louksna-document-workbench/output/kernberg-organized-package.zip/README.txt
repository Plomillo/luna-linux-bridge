Louksna Document Workbench — reading package

Contents:
- Trastornos_de_personalidad_severos_organizado.pdf: source layout with inferred navigation bookmarks.
- Trastornos_de_personalidad_severos_edicion_lectura.pdf: reflowed academic reading copy with contents, legible typography and source-page references.
- source-inspection.json: original page inventory and SHA-256.
- order-analysis-source.json, order-application-report.json and order-analysis-final.json: evidence behind page-order handling.
- organization-report.json and academic-edition-report.json: output checks and editorial limitations.
- SHA256SUMS.txt: SHA-256 checksums for payload files.

The original PDF remains on the source branch and is not overwritten. Pages move only when folios establish a complete, unique, contiguous order; otherwise the report requires manual review and no page is moved.
The reading copy changes pagination and is not a facsimile. Translation accuracy and clinical terminology are not certified; human review remains necessary.
