Louksna Document Workbench — organized PDF package

Contents:
- Trastornos_de_personalidad_severos_organizado.pdf: source pages retained in original order, with navigation bookmarks.
- organization-report.json: provenance and structural/content invariance evidence.
- source-inspection.json: source page inventory and SHA-256.
- SHA256SUMS.txt: SHA-256 checksums for packaged files.

The original PDF is not included as a second duplicate. Page order, geometry and extracted page text were checked.
Bookmarks are inferred heuristically and should be reviewed. Existing machine-translation quality is not certified.
