/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 *   SPDX-License-Identifier: Apache-2.0
 */

package rdfconnection.examples;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdfconnection.RDFConnection;

/*
 * Example of a connection performing a remote query.
 * (assumes sparql.org is up and running)
 */
public class RDFConnectionExample3 {
    public static void main(String ...args) {
        Query query = QueryFactory.create("SELECT * { <http://example.org/book/book1> ?p ?o }");
        String queryService = "http://sparql.org/books/query";

        // Query service, no update, no graph store protocol.
        try ( RDFConnection conn = RDFConnection.connect(queryService) ) {
            conn.queryResultSet(query, ResultSetFormatter::out);
        }
    }
}
